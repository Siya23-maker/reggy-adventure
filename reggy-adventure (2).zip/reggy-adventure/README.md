# REGGY Registration Adventure — Emeris University

A playable 3D campus game for the expo table. Visitors play **Siya** (Siyabonga Ngcukana), a new student, walk around Emeris University,
meet people, and let **REGGY** guide them through registration step by step. Everything is simulated:
fictional names, IDs, documents and payments. No internet, accounts or real data needed.

## Launch at the expo (no install)

1. Open `dist/index.html` in **Google Chrome** or **Microsoft Edge** (double-click it, or drag it into the browser).
2. Press **F** (or the ⛶ button) for full screen.
3. Click **Start your registration**.

Kiosk mode (full screen, no browser bars, recommended for the table):

```
# Windows
"C:\Program Files\Google\Chrome\Application\chrome.exe" --kiosk --start-fullscreen "file:///C:/path/to/dist/index.html"
# macOS
open -a "Google Chrome" --args --kiosk "file:///path/to/dist/index.html"
```

Older or low-power PC? Add `?quality=low` to the address (turns off shadows):
`file:///C:/path/to/dist/index.html?quality=low`

`dist/index.html` is a single self-contained file (three.js, code, styles and all textures are generated or inlined),
so it runs completely offline.

## Deploy on GitHub Pages

The repo includes `.github/workflows/deploy.yml`, which builds the game and publishes `dist/` to GitHub Pages on every push to `main`.

1. Create an empty GitHub repository (for example `reggy-adventure`) and push this folder to its `main` branch.
2. In the repository: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Push (or run the workflow from the **Actions** tab). The site appears at `https://<your-username>.github.io/<repo-name>/`.

The build uses relative paths, so it works under any repository name.

## Develop / rebuild

Requires Node.js 18+.

```
npm install
npm run dev      # live development server at http://localhost:5173
npm run build    # rebuilds dist/index.html
npm start        # build + serve at http://localhost:4173
```

## Controls

| Action | Keys |
|---|---|
| Walk | W A S D or arrow keys (hold Shift to jog) |
| Turn / zoom camera | Drag with the mouse · scroll wheel |
| Interact, talk, scan | E (or the on-screen button) · number keys pick dialogue options |
| See who someone is / chat | Click the person |
| Open REGGY phone | R or the REGGY button (bottom right) |
| Guide me | G or 🧭 Guide me — explains the way, offers *Take me there* |
| Reset camera | C or 🎥 |
| Sound on/off | M or 🔊 |
| Full screen | F or ⛶ |
| Pause / menu | Esc or ⏸ — Resume, Controls, *I'm stuck*, scenarios, **Restart for next visitor** |

The game auto-resets to the start screen after ~2.5 minutes without input (with a 20-second “Still there?” warning).

## People on campus

| Who | Role |
|---|---|
| **Siya** (you) | Lean, dark-skinned new student in the orange hoodie. Full name Siyabonga Ngcukana — “SEE-yah”, surname with a soft “c” click |
| **Jess** | **Runner** — manages the advisor waiting room. Her tablet shows who checked in, their seat, time in/called/out and how to say each name (🔊). She walks to the student’s seat and greets them by their preferred name, then hands them to the advisor |
| **Naledi** | **Student Advisor** — stays in the consultation room and does the actual advising |
| **Faatimaah** (hijab), **Mieke** | Students — Faatimaah finishes her consultation as the game starts; Mieke is waiting |
| **Hector** (bodybuilder, specs), **Antonio** (grumpy), **Alex** | Students — waiting, or arriving and scanning in |

Click anyone to see their profile (name, how to say it with 🔊, programme, time in / called / out) and chat with them. The camera turns to show their face.
The waiting-room screen and Jess’s runner tablet show the live queue. The campus clock starts at 10:05 and runs 6× faster so queue times move during a short demo.
Name sounds use the browser’s built-in voice (works offline on Windows/macOS Chrome & Edge).

## The journey (new student, ~3–5 minutes)

Arrive → scan the REGGY QR stand → identify (demo ID `EMR-2026-0417`, create a profile, or “no ID”) →
say how your name is pronounced → book student advisor **Naledi** → check in at the glowing seat → Jess the runner reads your name from her tablet, greets you correctly and walks you to Naledi →
5-second consultation → leave the room → upload the missing qualification certificate in *My documents*
(or get help at Document Assistance) → Registration verifies documents (Uploaded → Verified) →
add proof of payment → Finance verifies it → celebration and summary.

Other scenarios (start screen or pause menu → *Try another scenario*):

* **Missing documents** — two documents missing; one must be certified in person at Document Assistance.
* **Returning student** — documents on file; no advisor and no fee verification (configured in `src/state.js`).

## Where things live

* `src/state.js` — the single workflow state model and scenario configuration (steps, documents, fee rules).
* `src/main.js` — game loop, player/camera, NPCs, interactions, journey transitions, guidance, HUD.
* `src/ui.js` — REGGY phone screens (pure render functions).
* `src/world.js` — the 3D campus, signs, live screens and named locations.
* `src/characters.js` — stylised characters and animation.
* `src/nav.js` — collisions and path-finding used by route guidance and NPCs.
