@echo off
REM Opens the REGGY Registration Adventure full-screen (kiosk) in Chrome, falling back to Edge.
set "PAGE=%~dp0dist\index.html"
set "URL=file:///%PAGE:\=/%"
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --kiosk --start-fullscreen --autoplay-policy=no-user-gesture-required "%URL%"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --kiosk --start-fullscreen --autoplay-policy=no-user-gesture-required "%URL%"
) else (
  start "" msedge --kiosk "%URL%" --edge-kiosk-type=fullscreen
)
