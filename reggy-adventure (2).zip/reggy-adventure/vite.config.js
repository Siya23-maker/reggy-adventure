import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// `npm run build` produces dist/index.html — one self-contained file that runs offline.
export default defineConfig({
  base: './',
  plugins: [viteSingleFile()],
  server: { host: true, port: 5173 },
  preview: { host: true, port: 4173 },
  build: { chunkSizeWarningLimit: 2000 },
});
