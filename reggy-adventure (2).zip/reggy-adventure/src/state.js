// Single source of truth for the REGGY registration workflow.
// Dialogue, appointments, documents, notifications, objectives and route guidance all read from here.

export const SCENARIOS = {
  new: {
    id: 'new', title: 'New student', blurb: 'First-time registration: advisor, documents, registration and fees.',
    demoId: 'EMR-2026-0417', student: { name: 'Siyabonga Ngcukana', programme: 'Bachelor of Business Administration', type: 'New student' },
    advisor: true, fee: true,
    documents: [
      { id: 'idcopy', name: 'ID / passport copy', status: 'Uploaded' },
      { id: 'qual', name: 'Qualification certificate', status: 'Missing', how: 'phone' },
      { id: 'residence', name: 'Proof of residence', status: 'Uploaded' },
    ],
  },
  missing: {
    id: 'missing', title: 'Missing documents', blurb: 'Advisor already met — two documents still missing. One needs help at Document Assistance.',
    demoId: 'EMR-2026-0533', student: { name: 'Siyabonga Ngcukana', programme: 'Diploma in Information Technology', type: 'New student' },
    advisor: false, advisorDoneEarlier: true, fee: true,
    documents: [
      { id: 'idcopy', name: 'Certified ID copy', status: 'Missing', how: 'desk' },
      { id: 'qual', name: 'Qualification certificate', status: 'Missing', how: 'phone' },
      { id: 'residence', name: 'Proof of residence', status: 'Uploaded' },
    ],
  },
  returning: {
    id: 'returning', title: 'Returning student', blurb: 'Second-year student: documents on file, no fee verification needed.',
    demoId: 'EMR-2025-0128', student: { name: 'Siyabonga Ngcukana', programme: 'Bachelor of Science in Engineering', type: 'Returning student (Year 2)' },
    advisor: false, fee: false,
    documents: [
      { id: 'idcopy', name: 'ID / passport copy', status: 'Verified' },
      { id: 'qual', name: 'Academic record (Year 1)', status: 'Verified' },
      { id: 'residence', name: 'Proof of residence', status: 'Verified' },
    ],
  },
};

// Ordered steps. Each step: objective text, destination key (or null), milestone id.
export const STEP_INFO = {
  arrive:       { m: 'checkin',  obj: 'Walk to the REGGY stand and scan the QR code.', dest: 'qrStand' },
  identify:     { m: 'checkin',  obj: 'Tell REGGY who you are.', dest: null },
  book:         { m: 'advisor',  obj: 'Book your student advisor appointment in REGGY.', dest: null },
  goWaiting:    { m: 'advisor',  obj: 'Go to the waiting area and check in at your seat.', dest: 'waitSeat' },
  waiting:      { m: 'advisor',  obj: 'Relax — Jess, the runner, will collect you shortly.', dest: null },
  escort:       { m: 'advisor',  obj: 'Follow Jess to the consultation room.', dest: 'consultApproach' },
  consult:      { m: 'advisor',  obj: 'Consultation in progress…', dest: null },
  leaveRoom:    { m: 'advisor',  obj: 'Head back out of the consultation room.', dest: 'roomExit' },
  docs:         { m: 'docs',     obj: 'Complete your documents in REGGY.', dest: null },
  registration: { m: 'reg',      obj: 'Go to Registration and show your documents.', dest: 'registration' },
  feeUpload:    { m: 'fee',      obj: 'Add your proof of payment in REGGY.', dest: null },
  finance:      { m: 'fee',      obj: 'Visit Finance to verify your fee payment.', dest: 'finance' },
  complete:     { m: 'done',     obj: 'Registration complete — explore the campus!', dest: null },
};

export const MILESTONES = [
  { id: 'checkin', label: 'Check in with REGGY' },
  { id: 'advisor', label: 'Meet your student advisor' },
  { id: 'docs', label: 'Complete your documents' },
  { id: 'reg', label: 'Registration verification' },
  { id: 'fee', label: 'Fee verification' },
  { id: 'done', label: 'Registration complete' },
];

export function stepsFor(sc) {
  const s = ['arrive', 'identify'];
  if (sc.advisor) s.push('book', 'goWaiting', 'waiting', 'escort', 'consult', 'leaveRoom');
  if (sc.documents.some(d => d.status === 'Missing')) s.push('docs');
  s.push('registration');
  if (sc.fee) s.push('feeUpload', 'finance');
  s.push('complete');
  return s;
}

export function createState(scenarioId = 'new') {
  const sc = SCENARIOS[scenarioId] || SCENARIOS.new;
  return {
    scenario: sc.id,
    steps: stepsFor(sc),
    step: 'arrive',
    identified: false,
    student: null,
    appointment: null, // {advisor, time, status, ref}
    documents: sc.documents.map(d => ({ ...d })),
    payment: sc.fee ? { status: 'Not uploaded' } : null,
    regStatus: 'Not started',
    notifications: [],
    unread: 0,
    optionalDest: null,
    flags: {},
    startedAt: performance.now(),
  };
}

export const scenarioOf = (st) => SCENARIOS[st.scenario];
export const stepIndex = (st, s = st.step) => st.steps.indexOf(s);
export const isPast = (st, s) => stepIndex(st, s) !== -1 && stepIndex(st) > stepIndex(st, s);
export const reached = (st, s) => stepIndex(st, s) !== -1 && stepIndex(st) >= stepIndex(st, s);

export function milestoneStatus(st, id) {
  const sc = scenarioOf(st);
  if (id === 'advisor' && !sc.advisor) return sc.advisorDoneEarlier ? 'done-earlier' : 'skipped';
  if (id === 'docs' && !st.steps.includes('docs')) return 'done-earlier';
  if (id === 'fee' && !sc.fee) return 'skipped';
  const cur = STEP_INFO[st.step].m;
  const order = MILESTONES.map(m => m.id);
  if (st.step === 'complete') return 'done';
  const ci = order.indexOf(cur), mi = order.indexOf(id);
  return mi < ci ? 'done' : mi === ci ? 'current' : 'todo';
}

export function missingDocs(st) { return st.documents.filter(d => d.status === 'Missing'); }

export function objective(st) {
  const base = STEP_INFO[st.step];
  let obj = base.obj, dest = base.dest;
  if (st.step === 'docs') {
    const miss = missingDocs(st);
    const phone = miss.find(d => d.how === 'phone');
    const desk = miss.find(d => d.how === 'desk');
    if (desk && !phone) { obj = `Visit Document Assistance to certify your ${desk.name.toLowerCase()}.`; dest = 'docAssist'; }
    else if (phone) obj = `Upload your ${phone.name.toLowerCase()} in REGGY › My documents.`;
  }
  if (st.step === 'registration' && st.scenario === 'returning') obj = 'Go to Registration to confirm your Year 2 modules.';
  if (st.optionalDest && !dest) dest = st.optionalDest;
  return { obj, dest };
}
