// Collision boxes + grid A* pathfinding on the XZ plane.
export const colliders = []; // {minX,maxX,minZ,maxZ, tag}

export function addCollider(minX, maxX, minZ, maxZ, tag = '') {
  const c = { minX, maxX, minZ, maxZ, tag, enabled: true };
  colliders.push(c);
  return c;
}

// Push a circle (x,z,r) out of all colliders. Returns corrected {x,z}.
export function resolveCircle(x, z, r) {
  for (let iter = 0; iter < 3; iter++) {
    let moved = false;
    for (const c of colliders) {
      if (!c.enabled) continue;
      const cx = Math.max(c.minX, Math.min(x, c.maxX));
      const cz = Math.max(c.minZ, Math.min(z, c.maxZ));
      const dx = x - cx, dz = z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 1e-8) {
          const d = Math.sqrt(d2);
          x = cx + (dx / d) * r;
          z = cz + (dz / d) * r;
        } else {
          // centre inside the box: push out along the shallowest axis
          const pens = [
            [x - c.minX + r, -1, 0], [c.maxX - x + r, 1, 0],
            [z - c.minZ + r, 0, -1], [c.maxZ - z + r, 0, 1],
          ].sort((a, b) => a[0] - b[0]);
          x += pens[0][1] * pens[0][0];
          z += pens[0][2] * pens[0][0];
        }
        moved = true;
      }
    }
    if (!moved) break;
  }
  return { x, z };
}

export function blocked(x, z, r) {
  for (const c of colliders) {
    if (!c.enabled) continue;
    if (x > c.minX - r && x < c.maxX + r && z > c.minZ - r && z < c.maxZ + r) return true;
  }
  return false;
}

// ---------- Grid ----------
const CELL = 0.5;
const MINX = -32, MAXX = 32, MINZ = -18, MAXZ = 38;
const W = Math.round((MAXX - MINX) / CELL), H = Math.round((MAXZ - MINZ) / CELL);
let grid = null; // 1 = blocked

export function buildGrid(r = 0.42) {
  grid = new Uint8Array(W * H);
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const x = MINX + (i + 0.5) * CELL, z = MINZ + (j + 0.5) * CELL;
    grid[j * W + i] = blocked(x, z, r) ? 1 : 0;
  }
}

const toCell = (x, z) => [
  Math.max(0, Math.min(W - 1, Math.floor((x - MINX) / CELL))),
  Math.max(0, Math.min(H - 1, Math.floor((z - MINZ) / CELL))),
];
const toWorld = (i, j) => [MINX + (i + 0.5) * CELL, MINZ + (j + 0.5) * CELL];

function nearestFree(i, j) {
  if (!grid[j * W + i]) return [i, j];
  for (let rad = 1; rad < 20; rad++) {
    for (let dj = -rad; dj <= rad; dj++) for (let di = -rad; di <= rad; di++) {
      if (Math.max(Math.abs(di), Math.abs(dj)) !== rad) continue;
      const ni = i + di, nj = j + dj;
      if (ni < 0 || nj < 0 || ni >= W || nj >= H) continue;
      if (!grid[nj * W + ni]) return [ni, nj];
    }
  }
  return [i, j];
}

export function nearestWalkable(x, z) {
  const [i, j] = nearestFree(...toCell(x, z));
  const [wx, wz] = toWorld(i, j);
  return { x: wx, z: wz };
}

function lineFree(x0, z0, x1, z1) {
  const d = Math.hypot(x1 - x0, z1 - z0);
  const n = Math.ceil(d / (CELL * 0.5));
  for (let k = 0; k <= n; k++) {
    const t = n ? k / n : 0;
    const [i, j] = toCell(x0 + (x1 - x0) * t, z0 + (z1 - z0) * t);
    if (grid[j * W + i]) return false;
  }
  return true;
}

// Returns an array of {x,z} waypoints (excluding start), or [] if none.
export function findPath(sx, sz, tx, tz) {
  if (!grid) buildGrid();
  const [si, sj] = nearestFree(...toCell(sx, sz));
  const [ti, tj] = nearestFree(...toCell(tx, tz));
  const N = W * H;
  const g = new Float32Array(N).fill(Infinity);
  const came = new Int32Array(N).fill(-1);
  const closed = new Uint8Array(N);
  const heap = []; // [f, idx]
  const push = (f, idx) => {
    heap.push([f, idx]);
    let k = heap.length - 1;
    while (k > 0) { const p = (k - 1) >> 1; if (heap[p][0] <= heap[k][0]) break; [heap[p], heap[k]] = [heap[k], heap[p]]; k = p; }
  };
  const pop = () => {
    const top = heap[0], last = heap.pop();
    if (heap.length) {
      heap[0] = last; let k = 0;
      for (;;) {
        const l = 2 * k + 1, r = l + 1; let m = k;
        if (l < heap.length && heap[l][0] < heap[m][0]) m = l;
        if (r < heap.length && heap[r][0] < heap[m][0]) m = r;
        if (m === k) break; [heap[m], heap[k]] = [heap[k], heap[m]]; k = m;
      }
    }
    return top;
  };
  const start = sj * W + si, goal = tj * W + ti;
  g[start] = 0; push(0, start);
  const h = (i, j) => { const dx = Math.abs(i - ti), dz = Math.abs(j - tj); return (dx + dz) + (Math.SQRT2 - 2) * Math.min(dx, dz); };
  let found = false, iter = 0;
  while (heap.length && iter++ < 60000) {
    const [, cur] = pop();
    if (cur === goal) { found = true; break; }
    if (closed[cur]) continue;
    closed[cur] = 1;
    const ci = cur % W, cj = (cur / W) | 0;
    for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) {
      if (!di && !dj) continue;
      const ni = ci + di, nj = cj + dj;
      if (ni < 0 || nj < 0 || ni >= W || nj >= H) continue;
      const nidx = nj * W + ni;
      if (grid[nidx] || closed[nidx]) continue;
      if (di && dj && (grid[cj * W + ni] || grid[nj * W + ci])) continue;
      const ng = g[cur] + (di && dj ? Math.SQRT2 : 1);
      if (ng < g[nidx]) { g[nidx] = ng; came[nidx] = cur; push(ng + h(ni, nj), nidx); }
    }
  }
  if (!found) return [];
  const cells = [];
  for (let c = goal; c !== -1 && c !== start; c = came[c]) cells.push(c);
  cells.reverse();
  const pts = cells.map(c => { const [x, z] = toWorld(c % W, (c / W) | 0); return { x, z }; });
  pts[pts.length - 1] = { x: tx, z: tz };
  // string-pull smoothing
  const out = [];
  let ax = sx, az = sz, k = 0;
  while (k < pts.length) {
    let far = k;
    for (let m = pts.length - 1; m > k; m--) if (lineFree(ax, az, pts[m].x, pts[m].z)) { far = m; break; }
    out.push(pts[far]); ax = pts[far].x; az = pts[far].z; k = far + 1;
  }
  return out;
}
