// Tiny synthesised sound kit (no audio files needed, works offline).
let ctx = null, master = null, muted = false, ambient = null;

export function initAudio() {
  if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
  try {
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain(); master.gain.value = muted ? 0 : 0.5; master.connect(ctx.destination);
    startAmbient();
  } catch { ctx = null; }
}
export function setMuted(m) { muted = m; if (master) master.gain.setTargetAtTime(m ? 0 : 0.5, ctx.currentTime, 0.05); }
export const isMuted = () => muted;

function tone(freq, t0, dur, { type = 'sine', vol = 0.2, attack = 0.01, slide = 0 } = {}) {
  if (!ctx || muted) return;
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, ctx.currentTime + t0);
  if (slide) o.frequency.linearRampToValueAtTime(freq + slide, ctx.currentTime + t0 + dur);
  g.gain.setValueAtTime(0, ctx.currentTime + t0);
  g.gain.linearRampToValueAtTime(vol, ctx.currentTime + t0 + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t0 + dur);
  o.connect(g); g.connect(master); o.start(ctx.currentTime + t0); o.stop(ctx.currentTime + t0 + dur + 0.05);
}

export const sfx = {
  click: () => tone(880, 0, 0.06, { type: 'triangle', vol: 0.08 }),
  chime: () => { tone(988, 0, 0.35, { vol: 0.12 }); tone(1319, 0.1, 0.5, { vol: 0.1 }); },
  scan: () => { for (let i = 0; i < 6; i++) tone(1200 + i * 90, i * 0.12, 0.08, { type: 'square', vol: 0.03 }); tone(1760, 0.8, 0.25, { vol: 0.1 }); },
  success: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.09, 0.4, { type: 'triangle', vol: 0.12 })),
  fanfare: () => [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) => tone(f, i * 0.12, 0.5, { type: 'triangle', vol: 0.12 })),
  error: () => { tone(330, 0, 0.18, { type: 'triangle', vol: 0.1 }); tone(262, 0.15, 0.25, { type: 'triangle', vol: 0.1 }); },
  upload: () => tone(500, 0, 0.6, { type: 'sine', vol: 0.06, slide: 700 }),
  step: () => tone(120 + Math.random() * 30, 0, 0.05, { type: 'triangle', vol: 0.025 }),
  talk: () => tone(400 + Math.random() * 200, 0, 0.05, { type: 'sine', vol: 0.03 }),
};

function startAmbient() {
  // soft warm pad, very quiet
  const g = ctx.createGain(); g.gain.value = 0.018; g.connect(master);
  [196, 247, 294].forEach((f, i) => {
    const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = f;
    const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 0.07 + i * 0.03; lg.gain.value = 1.5;
    lfo.connect(lg); lg.connect(o.frequency); o.connect(g); o.start(); lfo.start();
  });
  ambient = g;
}
