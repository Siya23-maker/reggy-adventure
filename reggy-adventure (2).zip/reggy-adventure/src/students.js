// Named people on campus: looks, how to say their names, queue timings and chat content.
// All names, details and times are fictional demo data.

export const SIYA = {
  full: 'Siyabonga Ngcukana', first: 'Siya', say: 'SEE-yah', speak: 'See yah',
  surnameSay: 'n-click-oo-KAH-nah', surnameTip: 'the “c” is a soft tongue click, like a gentle “tsk”',
  look: { skin: '#4a2c1c', hair: '#0d0d0f', hairStyle: 'short', top: '#f2a33a', bottom: '#1f2a3a', shoes: '#ffffff', backpack: '#0b2a4a', lanyard: '#16c7e8', build: 'lean', scale: 1.04 },
};

// Advisor sits in the consultation room; Jess (the runner) brings students to her.
export const NALEDI = {
  name: 'Naledi Mokoena', first: 'Naledi', say: 'nah-LEH-dee', speak: 'nah leh dee', role: 'Student Advisor',
  look: { skin: '#7a4a2e', hair: '#141010', hairStyle: 'bun', top: '#2f9e8f', bottom: '#1f2a3a', shoes: '#222', lanyard: '#16c7e8' },
};

// Seat ids match world.seats indices: row A = front (0-5), row B = back (6-11). Siya always gets B6 (index 11).
export const seatName = (i) => (i < 6 ? 'A' : 'B') + ((i % 6) + 1);

// Minutes after midnight (09:35 → 575). Negative "arrive" = already on campus when the visit starts.
export const STUDENTS = [
  {
    id: 'faatimaah', name: 'Faatimaah Abdullah', first: 'Faatimaah', gender: 'female',
    say: 'fah-TEE-mah ab-DOO-lah', speak: 'fah tee mah', programme: 'BSc Nursing', from: 'Cape Town',
    look: { skin: '#c68b62', hair: '#2f9e8f', hairStyle: 'hijab', top: '#f6e6c8', bottom: '#5b4636', shoes: '#ffffff', backpack: '#e5534b', build: 'curvy' },
    start: 'consult', timeIn: 575, timeCalled: 598, seat: null, doneSpot: { x: -2.8, z: -7.6, rot: Math.PI }, doneLabel: 'At Registration',
    color: '#2f9e8f',
  },
  {
    id: 'antonio', name: 'Antonio Bianchi', first: 'Antonio', gender: 'male',
    say: 'an-TOH-nee-oh bee-AHN-kee', speak: 'an toh nee oh', programme: 'BCom Accounting', from: 'Durban',
    look: { skin: '#e0ac86', hair: '#2b1d16', hairStyle: 'short', top: '#6b7280', bottom: '#1f2937', shoes: '#222', face: 'grumpy' },
    start: 'waiting', timeIn: 580, seat: 1, doneSpot: { x: -13.2, z: -11.2, rot: Math.PI }, doneLabel: 'In the lounge',
    color: '#6b7280',
  },
  {
    id: 'hector', name: 'Hector Ramírez', first: 'Hector', gender: 'male',
    say: 'EK-tor rah-MEE-res (silent H)', speak: 'ek tor', programme: 'BSc Sport Science', from: 'Johannesburg',
    look: { skin: '#c68b62', hair: '#111111', hairStyle: 'short', top: '#e5534b', bottom: '#2d3748', shoes: '#ffffff', build: 'muscle', glasses: true, scale: 1.07 },
    start: 'waiting', timeIn: 592, seat: 4, doneSpot: { x: -17.4, z: -6.6, rot: -Math.PI / 2 }, doneLabel: 'At the vending machine',
    color: '#e5534b',
  },
  {
    id: 'mieke', name: 'Mieke van der Merwe', first: 'Mieke', gender: 'female',
    say: 'MEE-kuh fun-der-MEER-vuh', speak: 'mee kuh', programme: 'BA Media & Communication', from: 'Stellenbosch',
    look: { skin: '#f1c7a5', hair: '#e7c87a', hairStyle: 'long', top: '#ff7aa2', bottom: '#24609a', shoes: '#ffffff', build: 'curvy', earrings: true },
    start: 'waiting', timeIn: 598, seat: 6, doneSpot: { x: 14.6, z: 6.8, rot: Math.PI / 2 }, doneLabel: 'At Finance',
    color: '#ff7aa2',
  },
  {
    id: 'alex', name: 'Alex Morgan', first: 'Alex', gender: 'male',
    say: 'AL-iks', speak: 'al ix', programme: 'Diploma in IT', from: 'Gqeberha',
    look: { skin: '#f1c7a5', hair: '#7a4b2a', hairStyle: 'curly', top: '#4caf7a', bottom: '#2d3748', shoes: '#e5534b', backpack: '#0b2a4a' },
    start: 'arriving', timeIn: null, seat: 8, doneSpot: { x: 2.4, z: 25, rot: 0 }, doneLabel: 'Outside on the plaza',
    color: '#4caf7a',
  },
];

// Short ambient lines while they wait (shown as speech bubbles when Siya is near).
export const AMBIENT = {
  antonio: ['Forty minutes. FORTY. 😤', 'Who designed these chairs?', '*sigh* …at least the screen shows where I am.'],
  hector: ['Waiting room = rest between sets 💪', 'Anyone seen a protein bar machine?', 'My glasses keep fogging up 🤓'],
  mieke: ['Ooh, the screen spells my name right! ✨', 'Love the cyan here — so on brand.', 'Selfie with the REGGY stand later? 📸'],
  faatimaah: ['REGGY reminded me to bring my certified ID 🙏', 'Registration next — almost done!'],
  alex: ['Scanning in… beep!', 'Guide me saved me twice already 😅'],
};

const callReply = {
  antonio: 'Finally. …Thanks for saying it right, at least.',
  hector: 'That’s me! And you got the silent H — respect! 💪',
  mieke: 'Yes! Nobody ever says Mieke right — thank you! 😊',
  faatimaah: 'That’s me, thank you!',
  alex: 'Cool, that’s me!',
};
export const replyWhenCalled = (id) => callReply[id] || 'That’s me!';

// Chat trees: greet(status) + topics. Answers can depend on status.
export function chatFor(s, ctx) {
  const st = s.status;
  const done = st === 'Done';
  const T = {
    faatimaah: {
      greet: done ? `Hi ${ctx.me}! I just finished with Naledi — now Registration. How’s your day going?` : `Hi ${ctx.me}! I’m in with the advisor, can’t talk long. 😊`,
      topics: [
        ['How’s everything going?', 'Honestly smoother than I expected. REGGY told me exactly what to bring, so no second trip from Cape Town!'],
        ['What are you studying?', 'BSc Nursing. My mom’s a nurse — I’ve wanted this since I was little. 💙'],
        ['Any tips for me?', 'Upload your documents before Registration. “Uploaded” isn’t “Verified” — the officer checks them in person.'],
        ['How do I say your name?', 'fah-TEE-mah — the double “aa” is a long “ah”. Thanks for asking! 🙏'],
      ],
    },
    antonio: {
      greet: done ? `Oh. Hi. It’s ${ctx.me}, right? …Fine, that actually went okay.` : `What. Oh — sorry. I’ve been waiting since 09:40. I’m not a morning person.`,
      topics: [
        ['How’s everything going?', done ? 'Naledi sorted my modules in ten minutes. Annoyingly efficient. 😒' : 'Slow. But the screen shows my place in the queue, so… less slow than last year.'],
        ['What are you studying?', 'Accounting. I like numbers. Numbers don’t make you wait.'],
        ['Why so grumpy?', 'Three hours of sleep and no coffee. The vending machine ate my coins. 😤'],
        ['How do I say your name?', 'an-TOH-nee-oh. Not “Antony”. Jess got it right first time — I’ll give her that.'],
      ],
    },
    hector: {
      greet: done ? `${ctx.me}! My advisor sorted me out — time for a snack. How’s it going?` : `Hey ${ctx.me}! Just resting between sets. 💪 How’s registration treating you?`,
      topics: [
        ['How’s everything going?', 'Registration is like leg day — painful, but worth it after. REGGY’s keeping me on track.'],
        ['What are you studying?', 'Sport Science! Gonna be a strength coach. Want a free programme? 😄'],
        ['Nice glasses!', 'Thanks! Without them I’d bench-press the vending machine by accident. 🤓'],
        ['How do I say your name?', 'EK-tor — the H is silent! Most people say “Hec-tor” with a hard H. Jess nailed it.'],
      ],
    },
    mieke: {
      greet: done ? `Hiii ${ctx.me}! Done with my advisor, off to Finance next. How are you finding everything?` : `Hi ${ctx.me}! Love your hoodie. Are you new here too?`,
      topics: [
        ['How’s everything going?', 'Honestly so good! The waiting screen even shows how to say my name. That never happens. ✨'],
        ['What are you studying?', 'Media & Communication — I want to run campaigns for brands like REGGY one day. 📸'],
        ['Where are you from?', 'Stellenbosch! First time living away from home. Bit scary, very exciting.'],
        ['How do I say your name?', 'MEE-kuh — like “meek” plus “uh”. Not “Mike”! And van der Merwe is fun-der-MEER-vuh. 😄'],
      ],
    },
    alex: {
      greet: `Hey ${ctx.me}! What’s up?`,
      topics: [
        ['How’s everything going?', 'Pretty chill. Scanned the REGGY code, sat down, done. Jess will call me.'],
        ['What are you studying?', 'Diploma in IT. I already want to know how REGGY works under the hood. 🤖'],
        ['Any tips?', 'Tap 🧭 Guide me if you’re lost. I walked into the vending machine twice before I found it.'],
        ['How do I say your name?', 'Just AL-iks. Easy one! Unlike yours, probably — did you add yours in REGGY?'],
      ],
    },
  }[s.id];
  return T;
}

export const GENERIC_NAMES = ['Lerato', 'Thabo', 'Aisha', 'Ravi', 'Chloe', 'Kwame', 'Zanele', 'Omar', 'Priya', 'Liam', 'Nomsa', 'Yusuf', 'Sara', 'Bongani', 'Emma', 'Karim', 'Lindiwe', 'Musa', 'Ana', 'Tariq'];
export const GENERIC_PROGRAMMES = ['BCom Marketing', 'BSc Computer Science', 'LLB Law', 'BA Psychology', 'Diploma in Hospitality', 'BEng Civil', 'BSc Biology', 'BA Fine Art'];
export const GENERIC_LINES = [
  'Busy day! Everyone’s registering at once.', 'I’m heading to Registration — wish me luck!', 'The REGGY stand outside is so handy.',
  'Have you tried the coffee here? Don’t.', 'First week nerves… you too?', 'I love how calm it is with REGGY — last year was chaos.',
];
