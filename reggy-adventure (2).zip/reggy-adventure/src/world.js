import * as THREE from 'three';
import { addCollider } from './nav.js';
import { mat } from './characters.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export const UNI = 'Emeris University';

// Named locations used by the journey, NPCs and route guidance.
export const P = {
  start: { x: 0, z: 29 },
  qrStand: { x: 3.8, z: 20.5 }, qrApproach: { x: 2.4, z: 21.2 },
  reception: { x: -9, z: 11.6 }, receptionist: { x: -9, z: 8.8 },
  advisorDesk: { x: 9, z: 11.6 }, jessHome: { x: 9, z: 8.8 },
  waitSeat: { x: 3.2, z: 4.0 }, waitApproach: { x: 3.2, z: 2.8 },
  consultDoor: { x: 11, z: -8 }, roomExit: { x: 9.3, z: -8 },
  consultStudentChair: { x: 16, z: -8.55 }, consultApproach: { x: 16, z: -7.6 },
  consultJessChair: { x: 16, z: -11.45 }, consultJessStand: { x: 14.6, z: -8.2 },
  registration: { x: 0, z: -10.7 }, regOfficer: { x: 0, z: -13.2 },
  finance: { x: 15.6, z: 4 }, financeOfficer: { x: 18.6, z: 4 },
  docAssist: { x: -15.4, z: 0.5 }, docStaff: { x: -18.6, z: 0.5 },
  lostStudent: { x: -4.4, z: 22.2 },
  plaza: { x: 0, z: 24 },
};
// Room bounds for logic
export const ROOM = { minX: 11.2, maxX: 20, minZ: -16, maxZ: -4.2 };
export const BUILDING = { minX: -20, maxX: 20, minZ: -16, maxZ: 16 };

export const ZONES = [
  { name: 'Reception', x: -9, z: 10, w: 7, d: 4, color: '#f6c56a' },
  { name: 'Advisor', x: 9, z: 10, w: 6, d: 4, color: '#8fd3a8' },
  { name: 'Waiting', x: 0, z: 2.8, w: 9, d: 5, color: '#7fb5ff' },
  { name: 'Consultation', x: 15.6, z: -10, w: 8.8, d: 11.8, color: '#c7a6ff' },
  { name: 'Registration', x: 0, z: -12.5, w: 17, d: 5, color: '#16c7e8' },
  { name: 'Finance', x: 17.6, z: 4, w: 4.8, d: 7, color: '#ff9f80' },
  { name: 'Documents', x: -17.2, z: 0.5, w: 5.6, d: 6, color: '#ffd166' },
  { name: 'REGGY', x: 3.8, z: 20.5, w: 3, d: 3, color: '#16c7e8' },
];

const NAVY = '#0b2a4a', CYAN = '#16c7e8';

function box(parent, w, h, d, color, x, y, z, { collide = false, shadow = true, material } = {}) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material || mat(color));
  m.position.set(x, y, z);
  m.castShadow = shadow; m.receiveShadow = true;
  parent.add(m);
  if (collide) addCollider(x - w / 2, x + w / 2, z - d / 2, z + d / 2);
  return m;
}
function cyl(parent, rt, rb, h, color, x, y, z, seg = 16, opts = {}) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), opts.material || mat(color));
  m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; parent.add(m);
  if (opts.collide) addCollider(x - rb, x + rb, z - rb, z + rb);
  return m;
}

// ---------- canvas textures ----------
function canvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  t.userData = { canvas: c, ctx: g };
  return t;
}
function roundRect(g, x, y, w, h, r) {
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
const FONT = '"Segoe UI", "Helvetica Neue", Arial, sans-serif';

export function makeLabel(text, { icon = '', bg = NAVY, fg = '#fff', accent = CYAN, scale = 1 } = {}) {
  const pad = 26, fs = 46;
  const tmp = document.createElement('canvas').getContext('2d');
  tmp.font = `700 ${fs}px ${FONT}`;
  const tw = tmp.measureText(text).width + (icon ? 62 : 0);
  const W = Math.ceil(tw + pad * 2), H = 92;
  const tex = canvasTex(W, H + 14, (g) => {
    g.fillStyle = 'rgba(0,0,0,0.18)'; roundRect(g, 4, 10, W - 8, H, 26); g.fill();
    g.fillStyle = bg; roundRect(g, 2, 2, W - 4, H - 4, 24); g.fill();
    g.fillStyle = accent; roundRect(g, 2, H - 14, W - 4, 10, 5); g.fill();
    g.font = `700 ${fs}px ${FONT}`; g.textBaseline = 'middle'; g.fillStyle = fg;
    let x = pad;
    if (icon) { g.font = `${fs - 4}px ${FONT}`; g.fillText(icon, x, H / 2 - 4); x += 62; g.font = `700 ${fs}px ${FONT}`; }
    g.fillText(text, x, H / 2 - 4);
  });
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthWrite: false, transparent: true }));
  const s = 0.0068 * scale;
  sp.scale.set(W * s, (H + 14) * s, 1);
  sp.renderOrder = 10;
  return sp;
}

function tileTexture() {
  const t = canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = '#efe4d2'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      const v = 228 + ((i * 7 + j * 13) % 5) * 3;
      g.fillStyle = `rgb(${v + 8},${v - 2},${v - 20})`; g.fillRect(i * 128 + 2, j * 128 + 2, 124, 124);
    }
    g.strokeStyle = 'rgba(150,120,90,0.25)'; g.lineWidth = 3;
    for (let i = 0; i <= 4; i++) { g.beginPath(); g.moveTo(i * 128, 0); g.lineTo(i * 128, h); g.stroke(); g.beginPath(); g.moveTo(0, i * 128); g.lineTo(w, i * 128); g.stroke(); }
  });
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(10, 8);
  return t;
}
function pavingTexture() {
  const t = canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = '#d9cdb8'; g.fillRect(0, 0, w, h);
    for (let j = 0; j < 8; j++) for (let i = 0; i < 4; i++) {
      const off = (j % 2) * 32; const v = 200 + ((i * 31 + j * 17) % 7) * 4;
      g.fillStyle = `rgb(${v + 14},${v + 4},${v - 14})`; g.fillRect(i * 64 + off + 2, j * 32 + 2, 60, 28);
    }
  });
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(4, 6);
  return t;
}
function grassTexture() {
  const t = canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = '#7fbf5e'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 1400; i++) {
      const v = Math.random();
      g.fillStyle = v > 0.5 ? 'rgba(98,170,72,0.5)' : 'rgba(150,205,110,0.45)';
      g.fillRect(Math.random() * w, Math.random() * h, 2, 3);
    }
  });
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(30, 30);
  return t;
}
function qrTexture() {
  return canvasTex(256, 320, (g) => {
    g.fillStyle = NAVY; g.fillRect(0, 0, 256, 320);
    g.fillStyle = CYAN; g.font = `800 34px ${FONT}`; g.textAlign = 'center'; g.fillText('REGGY', 128, 44);
    g.fillStyle = '#fff'; g.font = `600 17px ${FONT}`; g.fillText('Scan to start registration', 128, 70);
    g.fillStyle = '#fff'; roundRect(g, 38, 88, 180, 180, 12); g.fill();
    g.fillStyle = NAVY;
    let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 21; i++) for (let j = 0; j < 21; j++) if (rnd() > 0.52) g.fillRect(50 + i * 7.5, 100 + j * 7.5, 7.5, 7.5);
    for (const [fx, fy] of [[50, 100], [50 + 14 * 7.5, 100], [50, 100 + 14 * 7.5]]) {
      g.fillStyle = NAVY; g.fillRect(fx, fy, 52, 52); g.fillStyle = '#fff'; g.fillRect(fx + 7.5, fy + 7.5, 37, 37); g.fillStyle = NAVY; g.fillRect(fx + 15, fy + 15, 22, 22);
    }
    g.fillStyle = CYAN; g.font = `700 16px ${FONT}`; g.fillText('Emeris University', 128, 296);
  });
}

// ---------- world ----------
export function buildWorld(scene) {
  const world = { fadeMeshes: [], doors: [], screens: {}, stand: null, highlights: {}, animated: [] };
  const root = new THREE.Group(); scene.add(root);

  // sky & fog
  scene.background = new THREE.Color('#bfe3f5');
  scene.fog = new THREE.Fog('#cfe8f5', 55, 120);

  // lights
  const hemi = new THREE.HemisphereLight('#e8f4ff', '#b89870', 1.25); scene.add(hemi);
  const sun = new THREE.DirectionalLight('#ffe6c2', 2.3);
  sun.position.set(22, 34, 18); sun.target.position.set(0, 0, 4);
  sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -36, right: 36, top: 36, bottom: -36, near: 5, far: 90 });
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.03; sun.shadow.radius = 4;
  scene.add(sun, sun.target);
  const fill = new THREE.DirectionalLight('#bcd6ff', 0.35); fill.position.set(-20, 18, -10); scene.add(fill);

  // ground
  const grass = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ map: grassTexture(), roughness: 1 }));
  grass.rotation.x = -Math.PI / 2; grass.position.y = -0.02; grass.receiveShadow = true; root.add(grass);
  const plaza = new THREE.Mesh(new THREE.PlaneGeometry(20, 22), new THREE.MeshStandardMaterial({ map: pavingTexture(), roughness: 0.95 }));
  plaza.rotation.x = -Math.PI / 2; plaza.position.set(0, -0.005, 27); plaza.receiveShadow = true; root.add(plaza);
  const walk = new THREE.Mesh(new THREE.PlaneGeometry(48, 3), new THREE.MeshStandardMaterial({ map: pavingTexture(), roughness: 0.95 }));
  walk.rotation.x = -Math.PI / 2; walk.position.set(0, -0.006, 17.6); walk.receiveShadow = true; root.add(walk);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 32), new THREE.MeshStandardMaterial({ map: tileTexture(), roughness: 0.6 }));
  floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0.005, 0); floor.receiveShadow = true; root.add(floor);
  // world boundary (keep visitors on campus)
  addCollider(-34, -31, -20, 40); addCollider(31, 34, -20, 40); addCollider(-34, 34, 37, 40);

  // rugs
  const rug = (x, z, w, d, color) => { const r = box(root, w, 0.02, d, color, x, 0.015, z, { shadow: false }); r.castShadow = false; return r; };
  rug(0, 2.8, 9.5, 5.2, '#1d4f80'); rug(0, 2.8, 9.0, 4.7, '#24609a');
  rug(15.6, -10, 6.5, 4.5, '#d9c7f0');
  rug(-14.5, -12.5, 8, 5, '#e2b892');

  // ---------- walls ----------
  const wallM = (c = '#f6f1e8') => new THREE.MeshStandardMaterial({ color: c, roughness: 0.85, transparent: true, opacity: 1 });
  const fadeable = (m, group) => { m.userData.fadeGroup = group; world.fadeMeshes.push(m); return m; };
  function wall(x1, z1, x2, z2, h, group, color = '#f6f1e8', y0 = 0, collide = true) {
    const t = 0.3, w = Math.abs(x2 - x1) || t, d = Math.abs(z2 - z1) || t;
    const m = box(root, w, h, d, null, (x1 + x2) / 2, y0 + h / 2, (z1 + z2) / 2, { collide, material: wallM(color) });
    // trim cap
    const cap = box(root, w + 0.06, 0.12, d + 0.06, null, m.position.x, y0 + h + 0.06, m.position.z, { material: new THREE.MeshStandardMaterial({ color: '#c99a6b', transparent: true }) });
    fadeable(m, group); fadeable(cap, group);
    return m;
  }
  const H = 3.4;
  wall(-20, -16, 20, -16, H, 'north');
  wall(-20, -16, -20, 16, H, 'west');
  wall(20, -16, 20, 16, H, 'east');
  // front facade (taller, warm stone)
  const FH = 5.2;
  wall(-20, 16, -3, 16, FH, 'front', '#f3e6d0');
  wall(3, 16, 20, 16, FH, 'front', '#f3e6d0');
  const lintel = wall(-3, 16, 3, 16, FH - 3.3, 'front', '#f3e6d0', 3.3, false);
  // facade stripe & sign
  const stripe = box(root, 40.4, 0.5, 0.2, null, 0, FH - 0.6, 16.2, { material: new THREE.MeshStandardMaterial({ color: NAVY, transparent: true }) }); fadeable(stripe, 'front');
  const signTex = canvasTex(1024, 160, (g) => {
    g.clearRect(0, 0, 1024, 160);
    g.fillStyle = NAVY; g.font = `800 92px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('EMERIS UNIVERSITY', 512, 72);
    g.fillStyle = CYAN; g.fillRect(352, 132, 320, 8);
  });
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(12, 1.9), new THREE.MeshBasicMaterial({ map: signTex, transparent: true }));
  sign.position.set(0, 4.15, 16.22); root.add(sign); fadeable(sign, 'front');
  // crest
  const crestTex = canvasTex(256, 256, (g) => {
    g.fillStyle = NAVY; g.beginPath(); g.moveTo(128, 10); g.lineTo(236, 50); g.lineTo(220, 170); g.lineTo(128, 246); g.lineTo(36, 170); g.lineTo(20, 50); g.closePath(); g.fill();
    g.fillStyle = CYAN; g.font = `800 120px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('E', 128, 128);
  });
  for (const sx of [-8.5, 8.5]) {
    const c = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 1.4), new THREE.MeshBasicMaterial({ map: crestTex, transparent: true }));
    c.position.set(sx, 3.6, 16.22); root.add(c); fadeable(c, 'front');
  }
  // facade windows
  const glassM = () => new THREE.MeshStandardMaterial({ color: '#9fd4ee', roughness: 0.15, metalness: 0.2, emissive: '#3a6f8a', emissiveIntensity: 0.25, transparent: true });
  for (const x of [-16, -11.5, 11.5, 16]) {
    const g = box(root, 3, 2, 0.08, null, x, 1.9, 16.2, { material: glassM(), shadow: false }); fadeable(g, 'front');
    const fr = box(root, 3.2, 0.12, 0.14, null, x, 0.85, 16.22, { material: new THREE.MeshStandardMaterial({ color: '#c99a6b', transparent: true }) }); fadeable(fr, 'front');
  }
  // interior windows
  for (const x of [-12, -4, 4, 12]) { const g = box(root, 3, 1.6, 0.06, null, x, 2, -15.8, { material: glassM(), shadow: false }); fadeable(g, 'north'); }
  for (const z of [-10, 8]) { const g = box(root, 0.06, 1.6, 3, null, -19.8, 2, z, { material: glassM(), shadow: false }); fadeable(g, 'west'); }
  for (const z of [-10, 8]) { const g = box(root, 0.06, 1.6, 3, null, 19.8, 2, z, { material: glassM(), shadow: false }); fadeable(g, 'east'); }

  // portico
  for (const x of [-4, 4]) {
    fadeable(cyl(root, 0.32, 0.36, 4.6, null, x, 2.3, 17.4, 20, { collide: true, material: new THREE.MeshStandardMaterial({ color: '#fbf4e6', transparent: true }) }), 'front');
    cyl(root, 0.48, 0.48, 0.3, '#e6d3b3', x, 0.15, 17.4, 20);
  }
  const canopy = box(root, 9.4, 0.35, 3, null, 0, 4.75, 17.2, { material: new THREE.MeshStandardMaterial({ color: '#fbf4e6', transparent: true }) }); fadeable(canopy, 'front');
  fadeable(box(root, 9.6, 0.12, 3.1, null, 0, 4.98, 17.2, { material: new THREE.MeshStandardMaterial({ color: NAVY, transparent: true }) }), 'front');
  // steps
  box(root, 8, 0.08, 1.4, '#e8dcc6', 0, 0.04, 16.9, { shadow: false });

  // entrance doors (sliding glass)
  for (const side of [-1, 1]) {
    const d = box(root, 2.9, 3.1, 0.08, null, side * 1.5, 1.6, 16.05, { material: new THREE.MeshStandardMaterial({ color: '#a9dcf0', transparent: true, opacity: 0.45, roughness: 0.1, metalness: 0.3 }), shadow: false });
    world.doors.push({ mesh: d, axis: 'x', closed: side * 1.5, open: side * 4.3, cx: 0, cz: 16, r: 4.5, t: 0 });
  }

  // ---------- consultation room ----------
  wall(11, -16, 11, -9, H, 'room');
  wall(11, -7, 11, -4, H, 'room');
  wall(11, -9, 11, -7, 0.7, 'room', '#f6f1e8', H - 0.7, false);
  wall(11, -4, 20, -4, H, 'roomS');
  const roomDoor = box(root, 0.08, 2.6, 2, null, 11, 1.3, -8, { material: new THREE.MeshStandardMaterial({ color: '#b98b5e', transparent: true }) });
  fadeable(roomDoor, 'room');
  world.doors.push({ mesh: roomDoor, axis: 'z', closed: -8, open: -10.1, cx: 11, cz: -8, r: 3.2, t: 0 });
  // glass strip on south wall
  { const g = box(root, 5, 1.2, 0.06, null, 15.5, 2.0, -3.82, { material: glassM(), shadow: false }); fadeable(g, 'roomS'); }
  // room furniture
  box(root, 2.4, 0.08, 1.3, '#b98b5e', 16, 0.78, -10, { collide: true });
  cyl(root, 0.08, 0.12, 0.76, '#5b4636', 16, 0.38, -10, 10);
  chair(root, 16, -11.45, 0, '#5b7fb3');
  chair(root, 16, -8.55, Math.PI, '#5b7fb3');
  box(root, 0.5, 0.35, 0.3, '#ffffff', 15.6, 0.97, -10.2); // laptop base
  { const lid = box(root, 0.5, 0.32, 0.03, '#2b3a55', 15.6, 1.12, -10.38); lid.rotation.x = -0.2; }
  bookshelf(root, 19.4, -13, Math.PI / 2);
  plant(root, 19.2, -5, 1.1); plant(root, 12, -15.2, 0.9);
  // whiteboard
  { const wb = box(root, 0.05, 1.3, 2.8, '#ffffff', 19.8, 1.9, -9.6, { shadow: false }); wb.material = new THREE.MeshStandardMaterial({ map: canvasTex(512, 256, (g) => { g.fillStyle = '#fff'; g.fillRect(0, 0, 512, 256); g.strokeStyle = CYAN; g.lineWidth = 6; g.font = `700 34px ${FONT}`; g.fillStyle = NAVY; g.fillText('Your path:', 30, 60); g.font = `500 28px ${FONT}`; ['1  Meet advisor', '2  Documents', '3  Registration', '4  Fees'].forEach((s, i) => g.fillText(s, 50, 105 + i * 36)); }), roughness: 0.4 }); wb.rotation.y = 0; }

  // ---------- reception ----------
  counter(root, -9, 10, 5, 1.0, '#ffffff', '#f6c56a');
  deskProps(root, -10.2, 9.9); deskProps(root, -7.8, 9.9);
  chair(root, -9, 8.4, 0, '#36506e');
  backPanel(root, -9, 7.2, 6, '#f6c56a', 'Reception');
  // ---------- advisor desk ----------
  counter(root, 9, 10, 3.2, 1.0, '#ffffff', '#8fd3a8');
  deskProps(root, 9, 9.9);
  chair(root, 9, 8.4, 0, '#36506e');
  backPanel(root, 9, 7.2, 4.5, '#8fd3a8', 'Advisor Services');
  chair(root, 8.3, 11.9, Math.PI, '#7c9cc4'); // visitor chairs (decor, no collide)

  // ---------- waiting area ----------
  world.seats = [];
  for (const [rz, n] of [[1.5, 6], [4.0, 6]]) {
    box(root, 7.6, 0.08, 0.6, '#5b4636', 0, 0.42, rz, { collide: true });
    for (let i = 0; i < n; i++) {
      const x = -3 + i * 1.24;
      const s = box(root, 0.95, 0.12, 0.55, '#2f7fc1', x, 0.5, rz);
      box(root, 0.95, 0.55, 0.1, '#2f7fc1', x, 0.85, rz + 0.3);
      world.seats.push({ x, z: rz, mesh: s });
    }
    for (const lx of [-3.6, 3.6]) box(root, 0.1, 0.42, 0.5, '#3c3c46', lx, 0.21, rz);
  }
  // player's seat highlight ring
  {
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.55, 0.75, 40), new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity: 0.0, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI / 2; ring.position.set(P.waitSeat.x, 0.03, P.waitSeat.z); root.add(ring);
    world.highlights.seat = ring;
  }
  plant(root, -4.5, 0.4, 1.2); plant(root, 4.6, 0.4, 1.2); plant(root, -4.5, 5.4, 1); plant(root, 4.6, 5.4, 1);
  // REGGY live display
  {
    const tex = canvasTex(768, 432, () => {});
    const stand = box(root, 0.3, 1.6, 0.3, '#3c3c46', 0, 0.8, -1.9, { collide: true });
    const scr = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.8, 0.12), [mat('#1b1b24'), mat('#1b1b24'), mat('#1b1b24'), mat('#1b1b24'), new THREE.MeshBasicMaterial({ map: tex }), mat('#1b1b24')]);
    scr.position.set(0, 2.3, -1.9); scr.castShadow = true; root.add(scr);
    world.screens.live = tex;
    void stand;
  }

  // ---------- registration counters ----------
  counter(root, 0, -12, 17, 0.9, '#ffffff', CYAN);
  for (const x of [-8.5, -2.5, 2.5, 8.5]) box(root, 0.08, 0.9, 0.9, null, x, 1.55, -12, { material: new THREE.MeshStandardMaterial({ color: '#cdeef7', transparent: true, opacity: 0.4 }), shadow: false });
  for (const x of [-5, 0, 5]) { deskProps(root, x, -12.1); chair(root, x, -13.7, 0, '#36506e'); }
  for (const [i, x] of [-5, 0, 5].entries()) {
    const n = makeLabel(`Counter ${i + 1}`, { scale: 0.55, bg: '#ffffff', fg: NAVY }); n.position.set(x, 2.35, -12); root.add(n);
  }
  backPanel(root, 0, -15.4, 14, CYAN, 'Registration', true);
  {
    const tex = canvasTex(768, 256, () => {});
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 1.4), new THREE.MeshBasicMaterial({ map: tex }));
    scr.position.set(0, 2.6, -15.75); root.add(scr);
    world.screens.reg = tex;
  }
  // queue rope posts
  for (const x of [-5, 5]) for (const z of [-9.5, -7]) cyl(root, 0.05, 0.08, 0.95, '#c9a227', x - 0.9, 0.47, z, 10);

  // ---------- finance ----------
  { // counter along z, facing -x
    const c = box(root, 0.9, 1.0, 6, '#ffffff', 17.4, 0.5, 4, { collide: true });
    box(root, 0.98, 0.08, 6.08, '#ff9f80', 17.4, 1.04, 4); void c;
    box(root, 0.06, 0.8, 6, null, 17.0, 1.5, 4, { material: new THREE.MeshStandardMaterial({ color: '#cdeef7', transparent: true, opacity: 0.35 }), shadow: false });
    deskProps(root, 17.6, 4, -Math.PI / 2); deskProps(root, 17.6, 2, -Math.PI / 2);
    chair(root, 19, 4, -Math.PI / 2, '#36506e'); chair(root, 19, 2, -Math.PI / 2, '#36506e');
    backPanel(root, 19.75, 4, 6, '#ff9f80', 'Finance', false, -Math.PI / 2);
    const fl = new THREE.Mesh(new THREE.SphereGeometry(0.12, 16, 12), new THREE.MeshStandardMaterial({ color: '#ff9f80', emissive: '#ff9f80', emissiveIntensity: 0.6 }));
    fl.position.set(17.4, 1.3, 4.9); fl.userData.dynamic = true; root.add(fl); world.highlights.financeLight = fl;
  }
  // ---------- document assistance ----------
  {
    box(root, 1.0, 0.95, 3.4, '#ffffff', -17.1, 0.47, 0.5, { collide: true });
    box(root, 1.08, 0.08, 3.48, '#ffd166', -17.1, 0.99, 0.5);
    const scanner = box(root, 0.55, 0.18, 0.7, '#e7e7ea', -17.1, 1.12, 1.4);
    const scanLight = box(root, 0.5, 0.02, 0.6, null, -17.1, 1.22, 1.4, { material: new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity: 0.2 }), shadow: false });
    world.highlights.scanner = scanLight; void scanner;
    deskProps(root, -17.2, -0.3, Math.PI / 2);
    chair(root, -18.9, 0.5, Math.PI / 2, '#36506e');
    backPanel(root, -19.75, 0.5, 5, '#ffd166', 'Document Help', false, Math.PI / 2);
    for (let i = 0; i < 3; i++) box(root, 0.24, 0.02, 0.32, '#ffffff', -17.0, 1.04 + i * 0.02, -0.6 + i * 0.05);
  }
  // ---------- lounge NW ----------
  sofa(root, -14.5, -13.6, 0); sofa(root, -17.6, -11.2, Math.PI / 2);
  box(root, 1.6, 0.4, 0.9, '#b98b5e', -14.5, 0.2, -11.6, { collide: true });
  bookshelf(root, -11, -15.4, 0); bookshelf(root, -19.4, -14.2, Math.PI / 2);
  box(root, 1, 2, 0.8, '#d6404c', -19.3, 1, -6.6, { collide: true }); // vending machine
  box(root, 0.7, 1.2, 0.05, '#bfe9f5', -18.88, 1.2, -6.6).rotation.y = Math.PI / 2;
  plant(root, -10.5, -6.5, 1.2); plant(root, -19, -4.5, 1.1);
  // lockers SW
  for (let i = 0; i < 6; i++) box(root, 0.7, 2, 0.6, i % 2 ? '#2f7fc1' : '#3a8fd4', -18.8 + i * 0.72, 1, 15.4, { collide: true });
  plant(root, -13, 15.1, 1); plant(root, 13, 15.1, 1); plant(root, 19.1, 15.1, 1.2); plant(root, 19.1, -2.5, 1); plant(root, -19.1, 4.4, 1);
  // noticeboard
  {
    const nb = new THREE.Mesh(new THREE.PlaneGeometry(3, 1.6), new THREE.MeshStandardMaterial({ map: canvasTex(384, 205, (g) => {
      g.fillStyle = '#c9a06b'; g.fillRect(0, 0, 384, 205);
      const cols = ['#fff7c2', '#c8f0ff', '#ffd6d6', '#d7f7d0', '#ffffff'];
      for (let i = 0; i < 9; i++) { g.fillStyle = cols[i % 5]; g.fillRect(14 + (i % 3) * 124, 12 + Math.floor(i / 3) * 64, 104, 54); g.fillStyle = '#7a7a7a'; for (let l = 0; l < 3; l++) g.fillRect(24 + (i % 3) * 124, 28 + Math.floor(i / 3) * 64 + l * 10, 70 - l * 12, 3); }
    }) }));
    nb.position.set(16, 1.9, 15.83); nb.rotation.y = Math.PI; root.add(nb); fadeable(nb, 'front');
  }
  // ceiling lamps (decor rings, emissive)
  for (const [x, z] of [[-9, 10], [9, 10], [0, 3], [0, -9], [-9, -3], [9, -3], [16, 4], [-16, 0.5]]) {
    const l = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.08, 24), new THREE.MeshStandardMaterial({ color: '#fff7e0', emissive: '#ffe9b0', emissiveIntensity: 0.9 }));
    l.position.set(x, 3.6, z); root.add(l);
  }
  const warm = new THREE.PointLight('#ffd9a0', 6, 16, 1.6); warm.position.set(0, 3, 2); scene.add(warm);
  const warm2 = new THREE.PointLight('#ffd9a0', 4, 14, 1.6); warm2.position.set(15.5, 2.8, -10); scene.add(warm2);

  // ---------- outdoors ----------
  // REGGY stand
  {
    const g = new THREE.Group(); g.position.set(P.qrStand.x, 0, P.qrStand.z); g.rotation.y = -0.35; root.add(g);
    box(g, 1.3, 0.14, 0.9, NAVY, 0, 0.07, 0);
    box(g, 0.24, 1.25, 0.24, '#e9eef5', 0, 0.75, 0);
    const head = new THREE.Group(); head.position.set(0, 1.55, 0.05); head.rotation.x = -0.35; g.add(head);
    box(head, 1.05, 1.3, 0.14, NAVY, 0, 0, 0);
    const screenMat = new THREE.MeshBasicMaterial({ map: qrTexture() });
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.92, 1.15), screenMat); scr.position.z = 0.075; head.add(scr);
    const top = box(head, 1.05, 0.1, 0.16, null, 0, 0.7, 0, { material: new THREE.MeshStandardMaterial({ color: CYAN, emissive: CYAN, emissiveIntensity: 0.8 }) }); top.userData.dynamic = true;
    const ring = new THREE.Mesh(new THREE.RingGeometry(1.1, 1.35, 48), new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity: 0.55, side: THREE.DoubleSide }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.02; g.add(ring);
    const beam = new THREE.Mesh(new THREE.ConeGeometry(0.7, 1.6, 24, 1, true), new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false }));
    beam.position.set(0, 0.8, 0.9); beam.rotation.x = -Math.PI / 2 - 0.35; beam.rotation.x = Math.PI * 0.62; g.add(beam);
    addCollider(P.qrStand.x - 0.6, P.qrStand.x + 0.6, P.qrStand.z - 0.5, P.qrStand.z + 0.5);
    world.stand = { group: g, ring, beam, top, screenMat };
  }
  // trees, bushes, lamps, benches
  for (const [x, z, s] of [[-12, 22, 1.2], [-17, 27, 1.4], [-24, 21, 1.3], [12, 22, 1.2], [17, 28, 1.4], [24, 21, 1.1], [-9, 32, 1.1], [10, 33, 1.2], [-25, 31, 1.5], [26, 32, 1.3], [-28, 10, 1.4], [28, 8, 1.3], [-28, -6, 1.5], [28, -8, 1.4]]) tree(root, x, z, s);
  for (const [x, z] of [[-7.5, 19.8], [7.5, 19.8], [-14, 19.6], [14, 19.6], [-20, 19.6], [20, 19.6]]) bush(root, x, z);
  for (const [x, z] of [[-6, 23], [6, 23], [-6, 31], [6, 31]]) lamp(root, x, z);
  bench(root, -9, 25, Math.PI / 2); bench(root, 9, 25.5, -Math.PI / 2); bench(root, -9, 29.5, Math.PI / 2);
  // flower beds
  for (const [x, z] of [[-6.2, 27], [6.2, 27]]) {
    box(root, 1.2, 0.35, 6, '#c9b08e', x, 0.17, z, { collide: true });
    for (let i = 0; i < 10; i++) { const f = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), mat(['#ff7aa2', '#ffd166', '#ffffff', '#c084fc'][i % 4])); f.position.set(x + (Math.random() - 0.5) * 0.7, 0.45, z - 2.6 + i * 0.58); root.add(f); }
  }
  // flags
  for (const [x, c] of [[-10.5, NAVY], [10.5, CYAN]]) {
    cyl(root, 0.06, 0.08, 7, '#d9dde3', x, 3.5, 19.2, 10, { collide: true });
    const fl = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 1.1, 8, 2), new THREE.MeshStandardMaterial({ color: c, side: THREE.DoubleSide }));
    fl.position.set(x + 0.95, 6.3, 19.2); fl.userData.dynamic = true; root.add(fl);
    world.animated.push((t) => { const p = fl.geometry.attributes.position; for (let i = 0; i < p.count; i++) { const px = p.getX(i) + 0.9; p.setZ(i, Math.sin(t * 3 + px * 3) * 0.08 * px); } p.needsUpdate = true; });
  }
  // campus monument sign
  {
    box(root, 4.2, 1.1, 0.7, '#e7dccb', -13, 0.55, 30.5, { collide: true });
    const t = canvasTex(512, 128, (g) => { g.fillStyle = '#e7dccb'; g.fillRect(0, 0, 512, 128); g.fillStyle = NAVY; g.font = `800 52px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('EMERIS', 256, 46); g.font = `600 30px ${FONT}`; g.fillStyle = '#0d8fab'; g.fillText('U N I V E R S I T Y', 256, 96); });
    const pl = new THREE.Mesh(new THREE.PlaneGeometry(3.9, 0.95), new THREE.MeshBasicMaterial({ map: t })); pl.position.set(-13, 0.58, 30.86); pl.rotation.y = 0; root.add(pl);
    const pl2 = pl.clone(); pl2.position.z = 30.14; pl2.rotation.y = Math.PI; root.add(pl2);
  }
  // neighbouring buildings (backdrop)
  for (const [x, z, w, d, h, c] of [[-36, 2, 14, 30, 7, '#e9dcc6'], [36, 2, 14, 30, 6, '#e3d6bf'], [0, -30, 50, 12, 9, '#efe3cf']]) {
    box(root, w, h, d, c, x, h / 2, z);
    box(root, w + 0.3, 0.3, d + 0.3, '#c99a6b', x, h + 0.15, z);
  }

  // ---------- labels ----------
  const labels = [
    ['REGGY Check-in', '📱', P.qrStand.x, 3.3, P.qrStand.z, 1.1],
    ['Reception', '🛎️', -9, 3.6, 10, 1],
    ['Advisor Services · Runner', '🏃', 9, 3.6, 10, 0.9],
    ['Waiting Area', '🪑', 0, 3.75, 3.6, 1],
    ['Consultation Room', '💬', 10.6, 3.85, -8, 0.95],
    ['Registration', '📋', 0, 3.7, -12, 1.1],
    ['Finance Assistance', '💳', 17.2, 3.6, 4, 0.95],
    ['Document Assistance', '📄', -17, 3.6, 0.5, 0.95],
    ['Main Entrance', '🎓', 0, 5.9, 17, 1],
  ];
  world.labels = {};
  for (const [t, ic, x, y, z, s] of labels) { const l = makeLabel(t, { icon: ic, scale: s }); l.position.set(x, y, z); root.add(l); world.labels[t] = l; }

  // ---------- route & marker visuals ----------
  const markerG = new THREE.Group(); scene.add(markerG);
  const diamond = new THREE.Mesh(new THREE.OctahedronGeometry(0.32), new THREE.MeshStandardMaterial({ color: CYAN, emissive: CYAN, emissiveIntensity: 0.8, roughness: 0.3 }));
  diamond.position.y = 2.7; markerG.add(diamond);
  const mring = new THREE.Mesh(new THREE.RingGeometry(0.7, 0.95, 48), new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false }));
  mring.rotation.x = -Math.PI / 2; mring.position.y = 0.04; markerG.add(mring);
  const mbeam = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.4, 8), new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity: 0.35, depthWrite: false }));
  mbeam.position.y = 1.3; markerG.add(mbeam);
  markerG.visible = false;
  world.marker = { group: markerG, diamond, ring: mring };

  const dotGeo = new THREE.CircleGeometry(0.16, 16);
  const dots = new THREE.InstancedMesh(dotGeo, new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity: 0.9, depthWrite: false }), 400);
  dots.count = 0; dots.frustumCulled = false; dots.renderOrder = 2; scene.add(dots);
  world.routeDots = dots;

  mergeStatic(root);
  return world;
}

// Bake static, colour-only meshes into a few vertex-coloured meshes to keep draw calls low.
function mergeStatic(root) {
  root.updateMatrixWorld(true);
  const buckets = new Map();
  const victims = [];
  root.traverse((m) => {
    if (!m.isMesh || m.userData.dynamic || m.userData.fadeGroup) return;
    const mt = m.material;
    if (Array.isArray(mt) || !mt.isMeshStandardMaterial || mt.map || mt.transparent) return;
    const key = [mt.roughness, mt.metalness, mt.flatShading, mt.emissive.getHexString(), mt.emissiveIntensity, m.castShadow].join('|');
    if (!buckets.has(key)) buckets.set(key, { mt, cast: m.castShadow, geos: [] });
    const g = (m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone());
    g.applyMatrix4(m.matrixWorld);
    const n = g.attributes.position.count, col = new Float32Array(n * 3), c = mt.color;
    for (let i = 0; i < n; i++) { col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b; }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'color'].includes(k)) g.deleteAttribute(k);
    if (mt.flatShading) g.computeVertexNormals();
    buckets.get(key).geos.push(g);
    victims.push(m);
  });
  victims.forEach(m => m.parent.remove(m));
  for (const { mt, cast, geos } of buckets.values()) {
    const merged = mergeGeometries(geos, false);
    const material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: mt.roughness, metalness: mt.metalness, flatShading: mt.flatShading, emissive: mt.emissive, emissiveIntensity: mt.emissiveIntensity });
    if (mt.emissiveIntensity > 0 && mt.emissive.getHex() !== 0) material.emissive = mt.emissive.clone();
    const mesh = new THREE.Mesh(merged, material); mesh.castShadow = cast; mesh.receiveShadow = true;
    root.add(mesh);
  }
}

// ---------- props ----------
function chair(p, x, z, ry, color) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry; p.add(g);
  box(g, 0.55, 0.08, 0.55, color, 0, 0.46, 0); box(g, 0.55, 0.6, 0.08, color, 0, 0.78, -0.26);
  cyl(g, 0.04, 0.04, 0.44, '#3c3c46', 0, 0.22, 0, 8);
  box(g, 0.5, 0.04, 0.5, '#3c3c46', 0, 0.02, 0);
  return g;
}
function counter(p, x, z, w, d, color, accent) {
  box(p, w, 1.0, d, color, x, 0.5, z, { collide: true });
  box(p, w + 0.1, 0.08, d + 0.12, accent, x, 1.04, z);
  box(p, w, 0.12, 0.02, accent, x, 0.75, z + d / 2 + 0.01, { shadow: false });
}
function deskProps(p, x, z, ry = 0) {
  const g = new THREE.Group(); g.position.set(x, 1.08, z); g.rotation.y = ry; p.add(g);
  box(g, 0.1, 0.25, 0.08, '#3c3c46', 0, 0.12, -0.15);
  const m = box(g, 0.62, 0.38, 0.04, '#1b1b24', 0, 0.38, -0.15);
  const s = new THREE.Mesh(new THREE.PlaneGeometry(0.56, 0.32), new THREE.MeshBasicMaterial({ color: '#9fe3f3' })); s.position.set(0, 0.38, -0.175); s.rotation.y = Math.PI; g.add(s);
  box(g, 0.4, 0.02, 0.14, '#e9e9ee', 0, 0.01, -0.45);
  void m;
}
function backPanel(p, x, z, w, color, text, tall = false, ry = 0) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry; p.add(g);
  const h = tall ? 1.1 : 0.9;
  const t = canvasTex(1024, 192, (c) => {
    c.fillStyle = '#0b2a4a'; c.fillRect(0, 0, 1024, 192);
    c.fillStyle = color; c.fillRect(0, 168, 1024, 24);
    c.fillStyle = '#fff'; c.font = `800 92px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(text, 512, 84);
  });
  const pl = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.7, h), new THREE.MeshStandardMaterial({ map: t, roughness: 0.6 }));
  pl.position.set(0, 2.55, 0.2); g.add(pl);
  if (!tall && ry === 0) { // free-standing feature wall so the sign doesn't float
    box(g, w * 0.78, 3.2, 0.18, '#f3e6d0', 0, 1.6, 0.05);
    box(g, w * 0.78, 0.25, 0.2, color, 0, 0.12, 0.06);
    addCollider(x - w * 0.39, x + w * 0.39, z - 0.15, z + 0.2);
  }
}
function plant(p, x, z, s = 1) {
  cyl(p, 0.28 * s, 0.22 * s, 0.5 * s, '#c9875a', x, 0.25 * s, z, 14, { collide: true });
  const leafM = mat('#4f9a52');
  for (let i = 0; i < 5; i++) {
    const l = new THREE.Mesh(new THREE.SphereGeometry(0.3 * s, 10, 8), i % 2 ? leafM : mat('#5fb25f'));
    l.position.set(x + Math.cos(i * 1.3) * 0.18 * s, (0.75 + (i % 3) * 0.22) * s, z + Math.sin(i * 1.3) * 0.18 * s);
    l.scale.set(1, 1.3, 1); l.castShadow = true; p.add(l);
  }
}
function tree(p, x, z, s) {
  cyl(p, 0.18 * s, 0.26 * s, 2 * s, '#8b5e3c', x, s, z, 10, { collide: true });
  const cols = ['#5ba854', '#6dbb5e', '#4f9a4a'];
  for (let i = 0; i < 4; i++) {
    const l = new THREE.Mesh(new THREE.IcosahedronGeometry(1.0 * s * (1 - i * 0.12), 1), mat(cols[i % 3], { flatShading: true }));
    l.position.set(x + Math.cos(i * 2.1) * 0.5 * s, (2.4 + i * 0.55) * s, z + Math.sin(i * 2.1) * 0.5 * s);
    l.castShadow = true; p.add(l);
  }
}
function bush(p, x, z) {
  for (let i = 0; i < 3; i++) { const b = new THREE.Mesh(new THREE.IcosahedronGeometry(0.6, 1), mat('#5aa65a', { flatShading: true })); b.position.set(x + (i - 1) * 0.7, 0.45, z); b.castShadow = true; p.add(b); }
  addCollider(x - 1.4, x + 1.4, z - 0.55, z + 0.55);
}
function lamp(p, x, z) {
  cyl(p, 0.06, 0.09, 3.4, '#2e3a4a', x, 1.7, z, 10, { collide: true });
  const l = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 12), new THREE.MeshStandardMaterial({ color: '#fff6dc', emissive: '#ffe2a0', emissiveIntensity: 0.9 }));
  l.position.set(x, 3.5, z); p.add(l);
}
function bench(p, x, z, ry) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry; p.add(g);
  box(g, 2, 0.08, 0.6, '#b98b5e', 0, 0.46, 0); box(g, 2, 0.5, 0.08, '#b98b5e', 0, 0.8, -0.28);
  for (const sx of [-0.85, 0.85]) box(g, 0.08, 0.46, 0.5, '#2e3a4a', sx, 0.23, 0);
  const c = Math.abs(Math.sin(ry)) > 0.5;
  addCollider(x - (c ? 0.35 : 1), x + (c ? 0.35 : 1), z - (c ? 1 : 0.35), z + (c ? 1 : 0.35));
}
function bookshelf(p, x, z, ry) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry; p.add(g);
  box(g, 2, 2.1, 0.45, '#8b5e3c', 0, 1.05, 0);
  const cols = ['#d6404c', '#2f7fc1', '#ffd166', '#5fb25f', '#0b2a4a', '#ff9f80'];
  for (let r = 0; r < 4; r++) for (let i = 0; i < 9; i++) box(g, 0.16, 0.36, 0.3, cols[(i + r * 2) % 6], -0.8 + i * 0.2, 0.3 + r * 0.5, 0.08, { shadow: false });
  const w = Math.abs(Math.sin(ry)) > 0.5;
  addCollider(x - (w ? 0.3 : 1), x + (w ? 0.3 : 1), z - (w ? 1 : 0.3), z + (w ? 1 : 0.3));
}
function sofa(p, x, z, ry) {
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry; p.add(g);
  box(g, 2.4, 0.45, 0.9, '#3d6fa8', 0, 0.25, 0); box(g, 2.4, 0.6, 0.25, '#335e90', 0, 0.7, -0.35);
  for (const sx of [-1.2, 1.2]) box(g, 0.22, 0.65, 0.9, '#335e90', sx, 0.35, 0);
  const w = Math.abs(Math.sin(ry)) > 0.5;
  addCollider(x - (w ? 0.5 : 1.3), x + (w ? 0.5 : 1.3), z - (w ? 1.3 : 0.5), z + (w ? 1.3 : 0.5));
}

// ---------- live screens ----------
export function drawLiveScreen(tex, { title, rows, rowH = 64 }) {
  const { ctx: g, canvas: c } = tex.userData;
  g.fillStyle = '#0b2a4a'; g.fillRect(0, 0, c.width, c.height);
  g.fillStyle = '#16c7e8'; g.fillRect(0, 0, c.width, 70);
  g.fillStyle = '#0b2a4a'; g.font = `800 40px ${FONT}`; g.textBaseline = 'middle'; g.fillText('REGGY', 24, 36);
  g.font = `600 28px ${FONT}`; g.fillText(title, 170, 37);
  const k = rowH / 64;
  rows.forEach((r, i) => {
    const y = 70 + rowH * 0.62 + i * rowH;
    if (y > c.height - 14) return;
    g.fillStyle = r.hi ? 'rgba(22,199,232,0.22)' : 'rgba(255,255,255,0.06)'; g.fillRect(16, y - rowH * 0.44, c.width - 32, rowH * 0.88);
    g.fillStyle = '#fff'; g.font = `700 ${Math.round(30 * k)}px ${FONT}`; g.fillText(r.a, 30, y);
    g.fillStyle = r.color || '#9fe3f3'; g.font = `600 ${Math.round(28 * k)}px ${FONT}`; g.textAlign = 'right'; g.fillText(r.b, c.width - 30, y); g.textAlign = 'left';
  });
  tex.needsUpdate = true;
}
