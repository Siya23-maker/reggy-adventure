import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const matCache = new Map();
export function mat(color, opts = {}) {
  const key = color + JSON.stringify(opts);
  if (!matCache.has(key)) matCache.set(key, new THREE.MeshStandardMaterial({ color, roughness: 0.75, metalness: 0.0, ...opts }));
  return matCache.get(key);
}

function mesh(geo, material, x = 0, y = 0, z = 0) {
  const m = new THREE.Mesh(geo, material);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

const G = {
  thigh: new THREE.CapsuleGeometry(0.085, 0.24, 4, 10),
  shin: new THREE.CapsuleGeometry(0.075, 0.22, 4, 10),
  shoe: new THREE.BoxGeometry(0.14, 0.09, 0.24),
  torso: new THREE.CapsuleGeometry(0.2, 0.28, 6, 14),
  arm: new THREE.CapsuleGeometry(0.06, 0.32, 4, 10),
  hand: new THREE.SphereGeometry(0.065, 10, 8),
  head: new THREE.SphereGeometry(0.25, 24, 18),
  eye: new THREE.SphereGeometry(0.026, 10, 8),
  eyeWhite: new THREE.SphereGeometry(0.04, 12, 10),
  cheek: new THREE.SphereGeometry(0.04, 8, 6),
  neck: new THREE.CylinderGeometry(0.07, 0.08, 0.1, 10),
  pack: new THREE.BoxGeometry(0.32, 0.38, 0.16),
  robe: new THREE.CylinderGeometry(0.2, 0.3, 0.75, 16),
};

/**
 * Stylised chunky character. Faces +Z by default.
 * opts: skin, hair, hairStyle(short|bun|long|curly|hijab|ghutra|bald), top, bottom, shoes,
 *       backpack(color|null), robe(bool), lanyard(color|null), scale
 */
export function makeCharacter(opts = {}) {
  const o = {
    skin: '#e0ac86', hair: '#2b1d16', hairStyle: 'short', top: '#3b82c4', bottom: '#2d3748',
    shoes: '#f4f4f4', backpack: null, robe: false, lanyard: null, scale: 1,
    build: 'normal', glasses: false, face: 'smile', ...opts,
  };
  // body proportions per build
  const B = {
    normal: { sh: 0.27, tx: 1.08, tz: 0.82, arm: 1, leg: 1, hipX: 0.1 },
    lean:   { sh: 0.24, tx: 0.92, tz: 0.72, arm: 0.82, leg: 0.86, hipX: 0.09 },
    muscle: { sh: 0.37, tx: 1.45, tz: 1.05, arm: 1.75, leg: 1.3, hipX: 0.12 },
    curvy:  { sh: 0.25, tx: 0.98, tz: 0.8, arm: 0.92, leg: 1.22, hipX: 0.115 },
  }[o.build] || {};
  const root = new THREE.Group();
  const hips = new THREE.Group(); hips.position.y = 0.66; root.add(hips);
  const skinM = mat(o.skin), topM = mat(o.top), botM = mat(o.bottom), shoeM = mat(o.shoes), hairM = mat(o.hair, { roughness: 0.9 });

  const legs = [];
  for (const side of [-1, 1]) {
    const thigh = new THREE.Group(); thigh.position.set(side * B.hipX, 0, 0); hips.add(thigh);
    const tm = mesh(G.thigh, botM, 0, -0.16, 0); tm.scale.set(B.leg, 1, B.leg); thigh.add(tm);
    const shin = new THREE.Group(); shin.position.y = -0.33; thigh.add(shin);
    shin.add(mesh(G.shin, botM, 0, -0.14, 0));
    shin.add(mesh(G.shoe, shoeM, 0, -0.3, 0.04));
    legs.push({ thigh, shin });
  }
  if (o.robe) {
    const robe = mesh(G.robe, topM, 0, -0.3, 0); hips.add(robe);
    legs.forEach(l => { l.thigh.children[0].visible = false; l.shin.children[0].visible = false; });
    root.userData.robe = robe;
  }

  if (o.build === 'curvy') {
    // fuller hips and glutes (tasteful, stylised)
    const pelvis = mesh(new THREE.SphereGeometry(0.21, 18, 14), botM, 0, -0.02, -0.01); pelvis.scale.set(1.25, 0.8, 1.0); hips.add(pelvis);
    for (const sx of [-1, 1]) { const g = mesh(new THREE.SphereGeometry(0.13, 16, 12), botM, sx * 0.085, -0.06, -0.12); g.scale.set(1, 1.05, 0.95); hips.add(g); }
  }
  const torso = new THREE.Group(); hips.add(torso);
  const body = mesh(G.torso, topM, 0, 0.3, 0); body.scale.set(B.tx, o.build === 'muscle' ? 1.08 : 1, B.tz); torso.add(body);
  if (o.build === 'muscle') {
    // broad chest and traps
    const chest = mesh(new THREE.SphereGeometry(0.24, 16, 12), topM, 0, 0.44, 0.04); chest.scale.set(1.55, 0.75, 1.0); torso.add(chest);
  }
  if (o.build === 'curvy') { const bust = mesh(new THREE.SphereGeometry(0.2, 16, 12), topM, 0, 0.4, 0.03); bust.scale.set(1.05, 0.7, 0.85); torso.add(bust); }
  const neck = mesh(G.neck, skinM, 0, 0.62, 0); if (o.build === 'muscle') neck.scale.set(1.5, 1, 1.5); torso.add(neck);

  const arms = [];
  for (const side of [-1, 1]) {
    const sh = new THREE.Group(); sh.position.set(side * B.sh, 0.5, 0); torso.add(sh);
    const a = mesh(G.arm, o.build === 'muscle' ? skinM : topM, 0, -0.17, 0); a.scale.set(B.arm, 1, B.arm); sh.add(a);
    if (o.build === 'muscle') { const delt = mesh(new THREE.SphereGeometry(0.1, 12, 10), topM, 0, -0.02, 0); delt.scale.set(1.3, 1, 1.3); sh.add(delt); }
    sh.add(mesh(G.hand, skinM, 0, -0.38, 0));
    sh.rotation.z = side * 0.08;
    arms.push(sh);
  }

  const head = new THREE.Group(); head.position.y = 0.88; torso.add(head);
  head.add(mesh(G.head, skinM));
  const eyeM = mat('#1b1b24', { roughness: 0.3 });
  for (const s of [-1, 1]) {
    head.add(mesh(G.eyeWhite, mat('#ffffff', { roughness: 0.4 }), s * 0.085, 0.02, 0.214));
    head.add(mesh(G.eye, eyeM, s * 0.085, 0.015, 0.236));
    const c = mesh(G.cheek, mat('#f19a8f', { roughness: 1, transparent: true, opacity: 0.55 }), s * 0.14, -0.06, 0.2);
    c.castShadow = false; head.add(c);
  }
  buildHair(head, o.hairStyle, hairM, o);
  // mouth & brows
  const darkM = mat('#2a1a14', { roughness: 0.6 });
  if (o.face === 'grumpy') {
    const m = mesh(new THREE.TorusGeometry(0.05, 0.012, 6, 14, Math.PI), darkM, 0, -0.1, 0.225); head.add(m); // frown
    for (const s2 of [-1, 1]) { const br = mesh(new THREE.BoxGeometry(0.08, 0.018, 0.02), darkM, s2 * 0.085, 0.085, 0.228); br.rotation.z = s2 * -0.45; head.add(br); }
  } else {
    const m = mesh(new THREE.TorusGeometry(0.045, 0.011, 6, 14, Math.PI), darkM, 0, -0.07, 0.228); m.rotation.z = Math.PI; head.add(m); // smile
    for (const s2 of [-1, 1]) { const br = mesh(new THREE.BoxGeometry(0.06, 0.014, 0.02), mat(o.hairStyle === 'hijab' ? '#2a1a14' : o.hair), s2 * 0.085, 0.09, 0.225); br.rotation.z = s2 * 0.15; head.add(br); }
  }
  if (o.earrings) for (const s2 of [-1, 1]) head.add(mesh(new THREE.SphereGeometry(0.025, 8, 6), mat('#e8c25a', { metalness: 0.6, roughness: 0.3 }), s2 * 0.245, -0.07, 0.02));
  if (o.glasses) {
    const fm = mat('#111318', { roughness: 0.4 });
    for (const s2 of [-1, 1]) { const r = mesh(new THREE.TorusGeometry(0.058, 0.011, 8, 20), fm, s2 * 0.088, 0.02, 0.238); head.add(r); }
    head.add(mesh(new THREE.BoxGeometry(0.05, 0.012, 0.012), fm, 0, 0.03, 0.245));
    for (const s2 of [-1, 1]) head.add(mesh(new THREE.BoxGeometry(0.012, 0.012, 0.2), fm, s2 * 0.145, 0.03, 0.14));
  }

  if (o.backpack) {
    const p = mesh(G.pack, mat(o.backpack), 0, 0.32, -0.22); torso.add(p);
    const strapM = mat(o.backpack);
    for (const s of [-1, 1]) torso.add(mesh(new THREE.BoxGeometry(0.04, 0.4, 0.04), strapM, s * 0.13, 0.36, 0.17));
  }
  let lanyard = null;
  lanyard = new THREE.Group();
  const cord = mesh(new THREE.TorusGeometry(0.14, 0.012, 6, 20, Math.PI), mat(o.lanyard || '#16c7e8'), 0, 0.56, 0.12);
  cord.rotation.set(Math.PI, 0, 0); cord.rotation.x = Math.PI * 1.15;
  const card = mesh(new THREE.BoxGeometry(0.11, 0.14, 0.015), mat('#ffffff'), 0, 0.38, 0.19);
  const stripe = mesh(new THREE.BoxGeometry(0.11, 0.035, 0.018), mat(o.lanyard || '#16c7e8'), 0, 0.43, 0.19);
  lanyard.add(cord, card, stripe); torso.add(lanyard);
  lanyard.visible = !!o.lanyard;

  root.scale.setScalar(o.scale);
  // Merge each rigid part into one vertex-coloured mesh: ~10 draw calls per character instead of ~30.
  [hips, torso, head, lanyard, ...legs.flatMap(l => [l.thigh, l.shin]), ...arms].forEach(bakeGroup);
  const ch = {
    root, hips, torso, head, legs, arms, lanyard,
    t: Math.random() * 10, walkAmt: 0, pose: 'stand', wave: 0, talk: 0, stamp: 0, crossArms: o.face === 'grumpy',
  };
  return ch;
}

function buildHair(head, style, hairM, o) {
  const add = (geo, x, y, z, sx = 1, sy = 1, sz = 1) => { const m = mesh(geo, hairM, x, y, z); m.scale.set(sx, sy, sz); head.add(m); return m; };
  const cap = new THREE.SphereGeometry(0.265, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.55);
  switch (style) {
    case 'bald': break;
    case 'short': add(cap, 0, 0.02, -0.02, 1, 1, 1.02); break;
    case 'bun':
      add(cap, 0, 0.02, -0.02); add(new THREE.SphereGeometry(0.11, 12, 10), 0, 0.2, -0.2); break;
    case 'long': {
      add(cap, 0, 0.02, -0.02);
      add(new THREE.CapsuleGeometry(0.2, 0.3, 4, 12), 0, -0.18, -0.12, 1.25, 1, 0.6); break;
    }
    case 'curly': {
      const s = new THREE.SphereGeometry(0.1, 10, 8);
      for (let i = 0; i < 16; i++) {
        const a = (i / 16) * Math.PI * 2, r = 0.22;
        add(s, Math.cos(a) * r, 0.12 + Math.sin(i * 1.7) * 0.03, Math.sin(a) * r * 0.9 - 0.03);
      }
      add(cap, 0, 0.05, -0.02, 1.05, 1.1, 1.05); break;
    }
    case 'hijab': {
      const hm = mat(o.hair, { roughness: 0.95 });
      // scarf frames the face: tilted back so the forehead edge sits above the eyes
      const shell = mesh(new THREE.SphereGeometry(0.29, 28, 20, 0, Math.PI * 2, 0, Math.PI * 0.6), hm, 0, 0.01, -0.025);
      shell.rotation.x = -0.95; head.add(shell);
      const band = mesh(new THREE.TorusGeometry(0.205, 0.035, 8, 28, Math.PI * 1.15), hm, 0, -0.02, 0.07); band.rotation.set(0.25, 0, Math.PI * 1.07); head.add(band); // wraps under the chin
      const drape = mesh(new THREE.CylinderGeometry(0.22, 0.33, 0.32, 18, 1, false), hm, 0, -0.27, -0.03); head.add(drape);
      break;
    }
    case 'ghutra': {
      const wm = mat('#f7f5ef', { roughness: 0.95 });
      const shell = mesh(new THREE.SphereGeometry(0.29, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.55), wm, 0, 0.0, -0.03); shell.rotation.x = -0.3; head.add(shell);
      const drape = mesh(new THREE.BoxGeometry(0.5, 0.42, 0.05), wm, 0, -0.18, -0.22); head.add(drape);
      const agal = mesh(new THREE.TorusGeometry(0.23, 0.025, 6, 20), mat('#1a1a1a'), 0, 0.15, -0.02); agal.rotation.x = Math.PI / 2 - 0.3; head.add(agal);
      break;
    }
  }
}

/** Animate a character. moving: 0..1 speed factor. */
export function animateCharacter(ch, dt, moving) {
  ch.t += dt * (4 + moving * 7);
  ch.walkAmt += (moving - ch.walkAmt) * Math.min(1, dt * 10);
  const w = ch.walkAmt;
  const s = Math.sin(ch.t);
  if (ch.pose === 'sit') {
    ch.hips.position.y = 0.48;
    ch.legs.forEach(l => { l.thigh.rotation.x = -1.5; l.shin.rotation.x = 1.45; });
    ch.arms.forEach((a, i) => { a.rotation.x = -0.5; a.rotation.z = (i ? 1 : -1) * 0.12; });
    ch.torso.rotation.x = 0.05;
    ch.torso.position.y = Math.sin(ch.t * 0.4) * 0.006;
  } else {
    ch.hips.position.y = 0.66 + Math.abs(Math.cos(ch.t)) * 0.045 * w + Math.sin(ch.t * 0.35) * 0.004 * (1 - w);
    ch.legs[0].thigh.rotation.x = s * 0.65 * w; ch.legs[1].thigh.rotation.x = -s * 0.65 * w;
    ch.legs[0].shin.rotation.x = Math.max(0, -s) * 0.8 * w; ch.legs[1].shin.rotation.x = Math.max(0, s) * 0.8 * w;
    ch.arms[0].rotation.x = -s * 0.6 * w; ch.arms[1].rotation.x = s * 0.6 * w;
    ch.arms[0].rotation.z = -0.08; ch.arms[1].rotation.z = 0.08;
    ch.torso.rotation.x = 0.06 * w;
    ch.torso.position.y = 0;
  }
  // gestures (override right arm)
  if (ch.wave > 0) {
    ch.wave -= dt;
    ch.arms[1].rotation.z = 2.6; ch.arms[1].rotation.x = Math.sin(ch.t * 2.2) * 0.3;
  } else if (ch.stamp > 0) {
    ch.stamp -= dt;
    ch.arms[1].rotation.x = -1.2 + Math.abs(Math.sin(ch.stamp * 9)) * -0.6;
  } else if (ch.talk > 0) {
    ch.talk -= dt;
    ch.arms[1].rotation.x = -0.6 + Math.sin(ch.t * 1.3) * 0.25;
    ch.head.rotation.y = Math.sin(ch.t * 0.6) * 0.15;
  } else {
    ch.head.rotation.y *= 0.9;
    if (ch.crossArms && ch.pose !== 'sit' && w < 0.15) { // grumpy folded arms when standing still
      ch.arms[0].rotation.x = -1.25; ch.arms[0].rotation.z = 0.9; ch.arms[1].rotation.x = -1.1; ch.arms[1].rotation.z = -0.9;
    }
  }
}

const charMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.78 });
const _c = new THREE.Color();
export function bakeGroup(group) {
  const parts = group.children.filter(c => c.isMesh);
  if (parts.length < 1) return;
  const geos = [];
  for (const m of parts) {
    m.updateMatrix();
    const g = m.geometry.index ? m.geometry.clone() : m.geometry.clone();
    g.applyMatrix4(m.matrix);
    _c.set(m.material.color);
    if (m.material.opacity < 1) _c.lerp(new THREE.Color('#e0ac86'), 0.5);
    const n = g.attributes.position.count, col = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { col[i * 3] = _c.r; col[i * 3 + 1] = _c.g; col[i * 3 + 2] = _c.b; }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'uv', 'color'].includes(k)) g.deleteAttribute(k);
    geos.push(g);
    group.remove(m);
  }
  const merged = mergeGeometries(geos, false);
  const mm = new THREE.Mesh(merged, charMat); mm.castShadow = true; mm.receiveShadow = true;
  group.add(mm);
}
