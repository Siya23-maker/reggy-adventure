import * as THREE from 'three';
import { buildWorld, P, ROOM, BUILDING, ZONES, drawLiveScreen } from './world.js';
import { makeCharacter, animateCharacter } from './characters.js';
import { buildGrid, findPath, resolveCircle, blocked, nearestWalkable } from './nav.js';
import { SCENARIOS, createState, scenarioOf, objective, missingDocs, MILESTONES, milestoneStatus, STEP_INFO } from './state.js';
import { renderPhone, phoneTabLabel, TIMES, SAMPLE_FILES } from './ui.js';
import { SIYA, NALEDI, STUDENTS, AMBIENT, seatName, replyWhenCalled, chatFor, GENERIC_NAMES, GENERIC_PROGRAMMES, GENERIC_LINES } from './students.js';
import { initAudio, sfx, setMuted, isMuted } from './audio.js';
import './style.css';

const $ = (s) => document.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ====================================================================
// Renderer / scene
// ====================================================================
const canvas = $('#c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: true });
// ?quality=low → for older expo PCs: no shadows, 1x pixel ratio
const LOW = new URLSearchParams(location.search).get('quality') === 'low';
renderer.setPixelRatio(LOW ? 1 : Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = !LOW;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.outputColorSpace = THREE.SRGBColorSpace;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(48, 1, 0.1, 300);
const world = buildWorld(scene);
buildGrid(0.4);

function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize); resize();

// ====================================================================
// Characters
// ====================================================================
const SKINS = ['#f1c7a5', '#e0ac86', '#c68b62', '#a8704b', '#8a5a3b', '#6b4430'];
const HAIRS = ['#2b1d16', '#4a2f1d', '#111111', '#7a4b2a', '#c9a15a', '#3a2418'];
const TOPS = ['#e5534b', '#f2a33a', '#4caf7a', '#7b61ff', '#ff7aa2', '#2f7fc1', '#ffd166', '#5fc4b8', '#ffffff', '#9b5de5'];
const BOTS = ['#2d3748', '#3b4a6b', '#5b4636', '#1f2937', '#6b7280', '#24609a'];
const STYLES = ['short', 'bun', 'long', 'curly', 'hijab', 'short', 'long', 'ghutra'];
let seed = 3;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const pick = (a) => a[Math.floor(rnd() * a.length)];
function randomLook(extra = {}) {
  const hs = pick(STYLES);
  const look = { skin: pick(SKINS), hair: hs === 'hijab' ? pick(['#0b2a4a', '#7b61ff', '#e5534b', '#f6e6c8', '#2f9e8f', '#111']) : pick(HAIRS), hairStyle: hs, top: pick(TOPS), bottom: pick(BOTS), shoes: pick(['#ffffff', '#222', '#e5534b', '#2f7fc1']), backpack: rnd() > 0.45 ? pick(['#0b2a4a', '#e5534b', '#2f9e8f', '#f2a33a', '#7b61ff']) : null };
  if (hs === 'ghutra') { look.robe = true; look.top = '#f7f5ef'; look.backpack = null; }
  return { ...look, ...extra };
}

const angLerp = (a, b, t) => { let d = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI; if (d < -Math.PI) d += Math.PI * 2; return a + d * t; };
const dist = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);

class Agent {
  constructor(name, look, x, z, rot = 0, opts = {}) {
    this.name = name; this.ch = makeCharacter(look); scene.add(this.ch.root);
    this.x = x; this.z = z; this.rot = rot; this.targetRot = rot; this.path = []; this.cb = null;
    this.speed = opts.speed || 1.5; this.paused = false; this.mode = opts.mode || 'idle';
    this.tag = opts.tag || null; this.home = { x, z, rot }; this.data = {};
    this.ch.root.traverse(o => { o.userData.agent = this; });
    this.sync();
  }
  goTo(x, z, cb = null, speed) {
    this.ch.pose = 'stand';
    this.path = findPath(this.x, this.z, x, z);
    if (!this.path.length) this.path = [{ x, z }];
    this.cb = cb; if (speed) this.speed = speed;
  }
  stop() { this.path = []; this.cb = null; }
  face(x, z) { this.targetRot = Math.atan2(x - this.x, z - this.z); }
  sit(x, z, rot) { this.stop(); this.x = x; this.z = z; this.rot = this.targetRot = rot; this.ch.pose = 'sit'; this.sync(); }
  place(x, z, rot) { this.stop(); this.x = x; this.z = z; this.rot = this.targetRot = rot; this.ch.pose = 'stand'; this.sync(); }
  get moving() { return this.path.length > 0 && !this.paused; }
  update(dt) {
    let moving = 0;
    if (this.path.length && !this.paused) {
      const p = this.path[0];
      const dx = p.x - this.x, dz = p.z - this.z, d = Math.hypot(dx, dz), step = this.speed * dt;
      if (d <= step) {
        this.x = p.x; this.z = p.z; this.path.shift();
        if (!this.path.length) { const cb = this.cb; this.cb = null; cb && cb(); }
      } else { this.x += (dx / d) * step; this.z += (dz / d) * step; this.targetRot = Math.atan2(dx, dz); }
      moving = Math.min(1, this.speed / 4);
    }
    this.rot = angLerp(this.rot, this.targetRot, Math.min(1, dt * 8));
    animateCharacter(this.ch, dt, moving);
    this.sync();
  }
  sync() { this.ch.root.position.set(this.x, 0, this.z); this.ch.root.rotation.y = this.rot; }
}

// --- player ---
const PLAYER_LOOK = SIYA.look; // Siya: lean, dark-skinned, orange hoodie so visitors spot him easily
const player = new Agent('player', PLAYER_LOOK, P.start.x, P.start.z, Math.PI, {});
player.sitting = false;

// --- staff ---
const STAFF = (look) => ({ bottom: '#1f2a3a', shoes: '#222', lanyard: '#16c7e8', backpack: null, ...look });
const people = {
  nadia: { name: 'Nadia', role: 'Reception', color: '#e39a2d', initial: 'N' },
  jess: { name: 'Jess', role: 'Runner · Advisor Services', color: '#16a9c4', initial: 'J' },
  naledi: { name: 'Naledi', role: 'Student Advisor', color: '#2f9e8f', initial: 'N' },
  layla: { name: 'Layla', role: 'Registration Officer', color: '#0d8fab', initial: 'L' },
  daniel: { name: 'Daniel', role: 'Finance Assistance', color: '#e8774f', initial: 'D' },
  sam: { name: 'Sam', role: 'Document Assistance', color: '#c99322', initial: 'S' },
  riley: { name: 'Riley', role: 'New student', color: '#8a63d2', initial: 'R' },
  reggy: { name: 'REGGY', role: 'Registration guide', color: '#0b2a4a', initial: 'R' },
};
const nadia = new Agent('nadia', STAFF({ skin: '#c68b62', hair: '#0b2a4a', hairStyle: 'hijab', top: '#0b2a4a' }), P.receptionist.x, P.receptionist.z, 0, { tag: 'Nadia · Reception' });
const jess = new Agent('jess', STAFF({ skin: '#b67b55', hair: '#3a2418', hairStyle: 'bun', top: '#16c7e8', bottom: '#0b2a4a', lanyard: '#0b2a4a' }), P.jessHome.x, P.jessHome.z, 0, { tag: 'Jess · Runner', speed: 2.2 });
const naledi = new Agent('naledi', STAFF(NALEDI.look), P.consultJessChair.x, P.consultJessChair.z, 0, { tag: 'Naledi · Student Advisor' });
naledi.sit(P.consultJessChair.x, P.consultJessChair.z, 0);
const layla = new Agent('layla', STAFF({ skin: '#e0ac86', hair: '#4a2f1d', hairStyle: 'long', top: '#0b2a4a' }), P.regOfficer.x, P.regOfficer.z, 0, { tag: 'Layla · Registration' });
const daniel = new Agent('daniel', STAFF({ skin: '#8a5a3b', hair: '#111', hairStyle: 'short', top: '#0b2a4a' }), P.financeOfficer.x, P.financeOfficer.z, -Math.PI / 2, { tag: 'Daniel · Finance' });
const sam = new Agent('sam', STAFF({ skin: '#f1c7a5', hair: '#c9a15a', hairStyle: 'short', top: '#0b2a4a' }), P.docStaff.x, P.docStaff.z, Math.PI / 2, { tag: 'Sam · Document Help' });
const clerks = [
  new Agent('clerk1', STAFF({ skin: '#a8704b', hair: '#111', hairStyle: 'ghutra', robe: true, top: '#f7f5ef' }), -5, -13.2, 0),
  new Agent('clerk2', STAFF({ skin: '#e0ac86', hair: '#7a4b2a', hairStyle: 'bun', top: '#0b2a4a' }), 5, -13.2, 0),
  new Agent('clerk3', STAFF({ skin: '#6b4430', hair: '#111', hairStyle: 'curly', top: '#0b2a4a' }), 18.6, 2, -Math.PI / 2),
];
const riley = new Agent('riley', { skin: '#f1c7a5', hair: '#c9a15a', hairStyle: 'long', top: '#7b61ff', bottom: '#2d3748', backpack: '#ffd166' }, P.lostStudent.x, P.lostStudent.z, 0.6, { tag: 'Riley · looks lost', speed: 1.7 });
const staffAgents = [nadia, jess, naledi, layla, daniel, sam, ...clerks];

// --- background students ---
const npcs = [];
const QUEUES = [
  { slots: [{ x: -5, z: -10.7 }, { x: -5, z: -9.8 }, { x: -5, z: -8.9 }, { x: -5, z: -8.0 }], members: [], target: 3, rot: Math.PI, timer: 6, clerk: 'clerk1' },
  { slots: [{ x: 5, z: -10.7 }, { x: 5, z: -9.8 }, { x: 5, z: -8.9 }], members: [], target: 2, rot: Math.PI, timer: 9, clerk: 'clerk2' },
  { slots: [{ x: 16.2, z: 1.6 }, { x: 15.2, z: 1.6 }], members: [], target: 1, rot: -Math.PI / 2 + Math.PI, timer: 12, clerk: 'clerk3' },
];
QUEUES[2].rot = Math.PI / 2; // facing +x toward finance clerk
const WAYPOINTS = [
  { x: -12, z: 4 }, { x: -6, z: -5 }, { x: 6, z: -5 }, { x: 12, z: 1 }, { x: -13, z: -8 }, { x: -2, z: 8 }, { x: -4, z: 13 }, { x: 12, z: 13 }, { x: 7, z: 5 },
  { x: -10, z: 27 }, { x: 10, z: 28 }, { x: -16, z: 23 }, { x: 16, z: 24 }, { x: 2, z: 32 }, { x: -2, z: 18.5 },
];
function makeNpc(mode) { const a = new Agent('npc' + npcs.length, randomLook(), 0, 0, 0, { mode, speed: 1.3 + rnd() * 0.5 }); a.data.name = GENERIC_NAMES[npcs.length % GENERIC_NAMES.length]; a.data.programme = pick(GENERIC_PROGRAMMES); npcs.push(a); return a; }
function setupNpcs() {
  // queues
  QUEUES.forEach(q => { q.members = []; for (let i = 0; i < q.target; i++) { const a = npcs.find(n => n.mode === 'pending') || makeNpc('queue'); a.mode = 'queue'; a.data.q = q; q.members.push(a); a.place(q.slots[i].x, q.slots[i].z, q.rot); } });
  // sitters (never the player's glowing seat)
  // at reception, chatting with Nadia
  { const a = makeNpc('chat'); a.place(-7.8, 11.4, Math.PI); a.data.talk = true; }
  // chatting pair outside
  { const a = makeNpc('chat'); a.place(-8.6, 22.4, 0.9); a.data.talk = true; const b = makeNpc('chat'); b.place(-7.6, 23.3, 0.9 + Math.PI); }
  // pair in lounge
  { const a = makeNpc('sit'); a.sit(-14.5, -13.5, 0); const b = makeNpc('chat'); b.place(-13.6, -11.9, Math.PI + 0.4); b.data.talk = true; }
  // walkers
  for (let i = 0; i < 7; i++) { const a = makeNpc('walk'); const w = WAYPOINTS[(i * 3) % WAYPOINTS.length]; a.place(w.x, w.z, 0); a.data.wait = rnd() * 3; }
}
setupNpcs();

// ---------------- named students (queue for the advisor) ----------------
const students = STUDENTS.map(d => {
  const a = new Agent(d.id, d.look, 0, 0, 0, { speed: d.id === 'antonio' ? 1.25 : 1.6 });
  a.student = { ...d };
  a.tagFn = () => `${d.first} · ${a.student.status === 'Done' ? 'Student' : a.student.status}`;
  return a;
});
const seatPos = (i) => world.seats[i];
const seatApproach = (i) => ({ x: world.seats[i].x, z: i < 6 ? 0.75 : 2.8 });
function resetStudents() {
  for (const a of students) {
    const d = STUDENTS.find(x => x.id === a.name), s = a.student = { ...d, status: '', timeOut: null, timeCalled: d.timeCalled || null };
    a.data = {}; a.stop(); a.paused = false;
    if (d.start === 'consult') { s.status = 'In consultation'; a.sit(P.consultStudentChair.x, P.consultStudentChair.z, Math.PI); a.data.consultEnd = 9; }
    else if (d.start === 'waiting') { s.status = 'Waiting'; const p = seatPos(d.seat); a.sit(p.x, p.z + 0.05, Math.PI); }
    else { s.status = 'Arriving'; a.place(-1.5, 31, Math.PI); a.data.arriveAt = 5; }
    a.data.ambient = 6 + rnd() * 10;
  }
}
resetStudents();

function updateNpcs(dt) {
  for (const q of QUEUES) {
    q.timer -= dt;
    if (q.timer <= 0 && q.members.length) {
      q.timer = 9 + rnd() * 6;
      const leaver = q.members.shift();
      leaver.mode = 'walk'; leaver.data.q = null; leaver.data.wait = 0;
      const w = pick(WAYPOINTS); leaver.goTo(w.x, w.z, () => { leaver.data.wait = 2 + rnd() * 4; });
      q.members.forEach((m, i) => m.goTo(q.slots[i].x, q.slots[i].z, () => { m.targetRot = q.rot; }));
    }
  }
  for (const a of npcs) {
    if (a.mode === 'walk') {
      // politely pause for the player
      a.paused = false;
      if (a.path.length) {
        const p = a.path[0], d = dist(a, player);
        if (d < 1.3) { const ax = p.x - a.x, az = p.z - a.z, px = player.x - a.x, pz = player.z - a.z; if (ax * px + az * pz > 0) a.paused = true; }
      } else {
        a.data.wait -= dt;
        if (a.data.wait <= 0) {
          const q = QUEUES.find(q => q.members.length < q.target) ;
          if (q && rnd() < 0.5) {
            a.mode = 'queue'; a.data.q = q; q.members.push(a); const i = q.members.length - 1;
            a.goTo(q.slots[i].x, q.slots[i].z, () => { a.targetRot = q.rot; });
          } else { const w = pick(WAYPOINTS); a.goTo(w.x, w.z, () => { a.data.wait = 2 + rnd() * 5; if (rnd() < 0.3) a.ch.talk = 1.5; }); }
        }
      }
    }
    if (a.data.talk && a.ch.talk <= 0 && rnd() < dt * 0.5) a.ch.talk = 1.5 + rnd() * 2;
    a.update(dt);
  }
  // clerks gesture to the person at the front of their queue
  for (const q of QUEUES) { const c = clerks.find(c => c.name === q.clerk); if (q.members[0] && !q.members[0].moving && c.ch.talk <= 0 && rnd() < dt * 0.4) c.ch.talk = 2; }
  if (nadia.ch.talk <= 0 && rnd() < dt * 0.25) nadia.ch.talk = 2;
}

// ====================================================================
// Game & UI state
// ====================================================================
let st = createState('new');
const ui = {
  started: false, paused: false, phoneOpen: false, flow: null, tab: 'next', dialog: null, busy: false,
  time: null, file: null, fileError: '', idValue: '', idError: '', pf: null, pfError: '', msg: null,
  overlay: 'start', visitStart: 0, guidePulse: 0, stepTime: 0, lastInput: performance.now(), idleCountdown: 0,
};
let simTime = 0;
// Campus clock: the visit starts at 10:05 and runs 6× faster, so a 5-minute demo spans ~30 minutes of queue times.
const clockMin = () => 605 + (simTime - (ui.visitStart || 0)) / 10;
const hhmm = (m) => m == null ? '—' : `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(Math.floor(m % 60)).padStart(2, '0')}`;
const runner = { job: false, cooldown: 6 };
let timers = [];
let gen = 0; // bumps on reset so stale callbacks die
function after(sec, fn) { const g = gen; timers.push({ t: simTime + sec, fn: () => g === gen && fn() }); }

// ====================================================================
// HUD helpers
// ====================================================================
let lastObj = '';
function updateHUD() {
  const { obj } = objective(st);
  const el = $('#objText');
  if (obj !== lastObj) { el.textContent = obj; el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); lastObj = obj; }
  const mi = MILESTONES.findIndex(m => m.id === STEP_INFO[st.step].m);
  $('#objStep').textContent = `Step ${mi + 1} of ${MILESTONES.length}`;
  $('#phoneTabNext').textContent = phoneTabLabel(st);
  $('#badge').textContent = st.unread; $('#badge').classList.toggle('hidden', !st.unread);
  $('#phStudent').textContent = st.student ? `${st.student.name} · ${st.student.id}` : 'Not signed in';
  renderPhoneDom();
  updateScreens();
  world.highlights.seat.material.opacity = st.step === 'goWaiting' ? 0.9 : 0;
}

function renderPhoneDom() {
  const phone = $('#phone');
  phone.classList.toggle('open', ui.phoneOpen); phone.classList.toggle('collapsed', !ui.phoneOpen);
  phone.classList.toggle('flow', !!ui.flow);
  $('#hud').classList.toggle('phone-open', ui.phoneOpen);
  if (!ui.phoneOpen) return;
  $('#phoneBody').innerHTML = renderPhone(st, ui);
  document.querySelectorAll('#phoneTabs button').forEach(b => b.classList.toggle('on', !ui.flow && b.dataset.arg === ui.tab));
  const idIn = $('#idInput');
  if (idIn) {
    idIn.addEventListener('input', () => { ui.idValue = idIn.value; });
    idIn.addEventListener('keydown', e => { if (e.key === 'Enter') act('submitId'); });
  }
  for (const id of ['nmPref', 'nmSay']) { const el = $('#' + id); if (el) el.addEventListener('input', () => { ui[id] = el.value; }); }
  const pfName = $('#pfName');
  if (pfName) {
    const sync = () => { ui.pf = { name: $('#pfName').value, prog: $('#pfProg').value }; };
    pfName.addEventListener('input', sync); $('#pfProg').addEventListener('change', sync);
    pfName.addEventListener('keydown', e => { if (e.key === 'Enter') act('createProfile'); });
  }
}

function openPhone(tab = null, flow = undefined) {
  ui.phoneOpen = true;
  if (flow !== undefined) ui.flow = flow;
  else if (!tab) ui.flow = defaultFlow();
  if (tab) { ui.tab = tab; ui.flow = null; }
  if (ui.tab === 'alerts' || (!ui.flow && ui.tab === 'alerts')) st.unread = 0;
  closeDialog();
  sfx.click();
  updateHUD();
}
function defaultFlow() {
  if (st.step === 'identify') return 'identify';
  if (st.step === 'book') return ui.time != null ? 'times' : 'advisor';
  if (st.step === 'feeUpload') return 'feeInfo';
  return null;
}
function closePhone() { ui.phoneOpen = false; ui.flow = null; if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); updateHUD(); }

function toast(title, body, opts = {}) {
  const el = document.createElement('div'); el.className = 'toast';
  el.innerHTML = `<b>${title}</b><span>${body}</span>${opts.button ? `<br><button class="tbtn" data-act="${opts.button.act}">${opts.button.label}</button>` : ''}`;
  el.addEventListener('click', (e) => { if (e.target.closest('.tbtn')) return; if (opts.openAlerts !== false) openPhone('alerts'); el.remove(); });
  $('#toasts').prepend(el);
  while ($('#toasts').children.length > 3) $('#toasts').lastChild.remove();
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 320); }, opts.ms || 6500);
}
function notify(title, body, opts = {}) {
  const now = new Date();
  st.notifications.push({ title, body, time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) });
  if (!(ui.phoneOpen && ui.tab === 'alerts' && !ui.flow)) st.unread++;
  toast(title, body, opts); sfx.chime(); updateHUD();
}
function banner(html, ms = 4200) {
  const b = $('#banner'); b.innerHTML = html; b.classList.remove('hidden');
  clearTimeout(banner.t); banner.t = setTimeout(() => b.classList.add('hidden'), ms);
}

// ---- dialog ----
function showDialog(who, text, choices = [], extraHtml = '') {
  const p = typeof who === 'string' ? people[who] : who;
  ui.dialog = { choices };
  const d = $('#dialog');
  d.innerHTML = `<div class="dl-portrait" style="background:${p.color}">${p.initial}</div>
    <div class="dl-main"><div><span class="dl-name">${p.name}</span><span class="dl-role">${p.role}</span></div>
    <div class="dl-text">${text}</div>${extraHtml}
    <div class="dl-choices">${choices.map((c, i) => `<button class="${c.primary ? 'primary' : ''}" data-act="choice" data-arg="${i}"><span class="n">${i + 1}</span>${c.label}</button>`).join('')}</div></div>`;
  d.classList.remove('hidden');
  if (ui.phoneOpen) { ui.phoneOpen = false; ui.flow = null; renderPhoneDom(); }
  for (let i = 0; i < 3; i++) setTimeout(() => sfx.talk(), i * 70);
}
function closeDialog() { ui.dialog = null; $('#dialog').classList.add('hidden'); if (!profileAgent) ui.camFocus = null; }
const bye = (label = 'Thanks!') => ({ label, fn: closeDialog });

// ---- world-anchored bubbles & tags ----
const bubbles = new Map();
function say(agent, text, sec = 3.5, who = '') {
  let b = bubbles.get(agent);
  if (!b) { const el = document.createElement('div'); el.className = 'bubble'; $('#worldui').appendChild(el); b = { el }; bubbles.set(agent, b); }
  b.el.innerHTML = (who ? `<b>${who}</b>` : '') + text; b.until = simTime + sec;
  b.el.style.animation = 'none'; void b.el.offsetWidth; b.el.style.animation = '';
  agent.ch.talk = Math.min(sec, 2.5);
}
const tags = new Map();
const tmpV = new THREE.Vector3();
function project(x, y, z) {
  tmpV.set(x, y, z).project(camera);
  return { x: (tmpV.x * 0.5 + 0.5) * window.innerWidth, y: (-tmpV.y * 0.5 + 0.5) * window.innerHeight, vis: tmpV.z < 1 && Math.abs(tmpV.x) < 1.2 && Math.abs(tmpV.y) < 1.2 };
}
function updateWorldUI() {
  for (const [agent, b] of bubbles) {
    if (simTime > b.until) { b.el.remove(); bubbles.delete(agent); continue; }
    const p = project(agent.x, agent.ch.pose === 'sit' ? 1.85 : 2.25, agent.z);
    b.el.style.display = p.vis ? '' : 'none'; b.el.style.left = p.x + 'px'; b.el.style.top = p.y + 'px';
  }
  const tagged = [...staffAgents, riley, ...students];
  for (const a of tagged) {
    if (!a.tag && !a.tagFn) continue;
    let el = tags.get(a);
    if (!el) { el = document.createElement('div'); el.className = 'tag'; $('#worldui').appendChild(el); tags.set(a, el); }
    const d = dist(a, player);
    const show = ui.started && d < 9 && !bubbles.has(a);
    if (!show) { el.style.display = 'none'; continue; }
    const [n, r] = (a.tagFn ? a.tagFn() : a.tag).split(' · ');
    el.innerHTML = `${n}<i>${r}</i>`;
    const p = project(a.x, 2.05, a.z);
    el.style.display = p.vis ? '' : 'none'; el.style.left = p.x + 'px'; el.style.top = p.y + 'px';
  }
  // "You" tag at the start of each visit
  let you = tags.get(player);
  if (!you) { you = document.createElement('div'); you.className = 'tag you'; you.textContent = 'You'; $('#worldui').appendChild(you); tags.set(player, you); }
  const showYou = ui.started && simTime - ui.visitStart < 12 && !bubbles.has(player);
  you.style.display = showYou ? '' : 'none';
  if (showYou) { const p = project(player.x, 2.1, player.z); you.style.left = p.x + 'px'; you.style.top = p.y + 'px'; }
}

// ====================================================================
// Live screens in the world reflect REGGY state
// ====================================================================
function updateScreens() {
  const first = st.student?.first || 'You';
  const a = st.appointment;
  // Advisor queue: name + how to say it, time in, and time out / status
  const rows = queueRows().map(q => ({
    a: `${q.first} · ${q.say1}`,
    b: q.out ? `In ${hhmm(q.in)} · Out ${hhmm(q.out)}` : q.in ? `In ${hhmm(q.in)} · ${q.status}` : q.status,
    hi: q.you, color: q.out ? '#7ff0b5' : q.status === 'Called' || q.status === 'In consultation' || q.status === 'In Progress' ? '#ffd166' : '#9fe3f3',
  }));
  if (st.step === 'complete') rows.unshift({ a: `🎉 Welcome to Emeris, ${first}!`, b: 'Registered', hi: true, color: '#7ff0b5' });
  drawLiveScreen(world.screens.live, { title: `Advisor queue · Runner: Jess · ${hhmm(clockMin())}`, rows, rowH: 52 });
  const reg = st.regStatus;
  drawLiveScreen(world.screens.reg, {
    title: 'Registration · Now serving',
    rows: [{ a: 'Counter 1 · R-31', b: 'Serving' }, { a: `Counter 2 · ${st.student ? first : 'R-32'}`, b: reg === 'Verified' ? 'Verified ✓' : st.step === 'registration' ? 'Ready for you' : 'Open', hi: st.step === 'registration' || reg === 'Verified', color: reg === 'Verified' ? '#7ff0b5' : '#16c7e8' }],
  });
}

// ====================================================================
// Journey / state transitions
// ====================================================================
function queueRows() {
  const rows = students.filter(a => a.student.timeIn != null).map(a => {
    const s = a.student;
    return { id: a.name, agent: a, first: s.first, name: s.name, say: s.say, say1: s.say.split(' ')[0], speak: s.speak, seat: s.seat != null ? seatName(s.seat) : '—', in: s.timeIn, called: s.timeCalled, out: s.timeOut, status: s.status, color: s.color };
  });
  if (st.appointment && st.student) {
    const pref = st.student.preferred || st.student.first, ap = st.appointment;
    rows.push({ id: 'siya', you: true, agent: player, first: `${pref} (you)`, name: st.student.name, say: st.student.say || pref, say1: (st.student.say || pref).split(' ')[0], speak: st.student.speak || st.student.say || pref, seat: 'B6', in: st.siyaIn ?? null, called: st.siyaCalled ?? null, out: st.siyaOut ?? null, status: ap.status === 'Completed' ? 'Done' : ap.status === 'Confirmed' ? 'Booked' : ap.status, color: '#f2a33a' });
  }
  const rank = (r) => (r.out ? 2 : 0) + (r.status === 'Booked' ? 1 : 0);
  return rows.sort((x, y) => rank(x) - rank(y) || (x.in ?? 9999) - (y.in ?? 9999));
}

function advance(step) {
  if (!st.steps.includes(step)) step = st.steps[st.steps.indexOf(step) + 1] || 'complete';
  st.step = step; st.optionalDest = null; ui.stepTime = simTime; $('.tb.guide').classList.remove('nudge');
  routeDirty = true;
  updateHUD();
}
function nextAfter(step) { const i = st.steps.indexOf(step); return st.steps[i + 1]; }

function startScan() {
  ui.busy = true; sfx.scan();
  player.face(P.qrStand.x, P.qrStand.z);
  player.ch.arms[1].rotation.x = -1.4; player.ch.stamp = 1.4;
  world.stand.beam.material.opacity = 0.35; world.stand.top.material.emissiveIntensity = 2;
  ui.phoneOpen = true; ui.flow = 'scanning'; renderPhoneDom(); updateHUD();
  after(1.8, () => {
    world.stand.beam.material.opacity = 0;
    world.stand.ring.material.color.set('#22b573');
    ui.busy = false; st.flags.scanned = true;
    advance('identify'); ui.flow = 'identify'; ui.phoneOpen = true; updateHUD();
    notify('Connected to REGGY', 'You scanned the check-in code. Let’s find your registration.');
  });
}

function identify(name, id, programme) {
  const sc = scenarioOf(st);
  st.identified = true;
  const isSiya = name === SIYA.full;
  st.student = { name, first: isSiya ? SIYA.first : name.split(' ')[0], id, programme: programme || sc.student.programme, type: sc.student.type,
    preferred: isSiya ? SIYA.first : name.split(' ')[0], say: isSiya ? SIYA.say : name.split(' ')[0], speak: isSiya ? SIYA.speak : name.split(' ')[0],
    surnameSay: isSiya ? SIYA.surnameSay : '', surnameTip: isSiya ? SIYA.surnameTip : '' };
  player.ch.lanyard.visible = true;
  ui.idError = '';
  sfx.success();
  notify('Profile found ✓', `Welcome, ${esc(st.student.first)}! Your visitor badge is ready — REGGY will guide every step.`);
  const nxt = nextAfter('identify');
  advance(nxt);
  if (nxt === 'book') { ui.flow = 'advisor'; }
  else { ui.flow = 'welcome'; }
  ui.phoneOpen = true; updateHUD();
}

function confirmBooking() {
  if (st.step !== 'book' || ui.time == null) return;
  const t = TIMES[ui.time].t.replace('Now · ', '');
  st.appointment = { advisor: 'Naledi', time: t, status: 'Confirmed', ref: 'A-12' };
  sfx.success();
  advance('goWaiting'); ui.flow = 'confirmed'; updateHUD();
  notify('Appointment confirmed', `Naledi · Student Advisor · today ${t}. Go to the waiting area — Jess, the runner, will collect you.`);
  jess.ch.wave = 2; say(jess, `Got you on my tablet, ${esc(st.student.preferred)}! 👋`, 3, 'Jess');
}

function checkInSeat() {
  if (st.step !== 'goWaiting') return;
  player.sitting = true; player.sit(P.waitSeat.x, P.waitSeat.z + 0.05, Math.PI);
  st.appointment.status = 'In Waiting Room';
  advance('waiting');
  st.siyaIn = clockMin(); ui.waitStart = simTime; updateScreens();
  notify('You’re checked in', `Status: In Waiting Room · in ${hhmm(st.siyaIn)}. Jess’s tablet now shows you in seat B6, with how to say your name.`);
}

function speakName(text) {
  if (isMuted() || !text || !('speechSynthesis' in window)) return;
  try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.rate = 0.8; u.lang = 'en-ZA'; speechSynthesis.speak(u); } catch { /* voice unavailable */ }
}
// Runner tablet bubble: who is next, which seat, how to say the name
function tabletBubble(first, seat, sayIt) {
  jess.targetRot = 0; jess.ch.talk = 2;
  say(jess, `📋 Next: <b>${esc(first)}</b> · Seat ${seat}<br>🔊 “${esc(sayIt)}”`, 3.2, 'Jess · runner tablet');
}
function jessCollect() {
  runner.job = true;
  const pref = st.student.preferred || st.student.first, sayIt = st.student.say || pref;
  tabletBubble(pref, 'B6', sayIt);
  after(0.4, () => speakName(st.student.speak || sayIt));
  after(2.2, () => jess.goTo(P.waitSeat.x - 0.2, 2.55, () => {
    jess.face(player.x, player.z); jess.ch.wave = 1.6;
    say(jess, `Hi ${esc(pref)}! Come with me and we’ll get you started.`, 4.5, 'Jess');
    st.appointment.status = 'In Progress'; st.siyaCalled = clockMin(); updateScreens();
    notify('Your appointment has started', `Status: In Progress · called ${hhmm(st.siyaCalled)}. Follow Jess, your runner, to Naledi’s room.`);
    after(1.6, () => {
      player.sitting = false; player.place(P.waitSeat.x, 2.95, Math.PI);
      advance('escort');
      jess.goTo(P.consultJessStand.x, P.consultJessStand.z, () => { jess.face(naledi.x, naledi.z); say(jess, `Naledi, this is ${esc(pref)}. Take a seat! 😊`, 3, 'Jess'); ui.jessSeated = true; }, 2.0);
    });
  }, 2.3));
}

// ---------------- runner loop: Jess calls named students by name, logs time in/out ----------------
const roomBusy = () => students.some(a => ['Called', 'In consultation'].includes(a.student.status)) || ['escort', 'consult', 'leaveRoom'].includes(st.step);
const siyaInQueue = () => ['goWaiting', 'waiting', 'escort', 'consult'].includes(st.step);
function runnerUpdate(dt) {
  runner.cooldown -= dt;
  if (runner.job || jess.moving || dist(jess, P.jessHome) > 0.6) return;
  if (st.step === 'waiting' && !runner.siyaCalled && !roomBusy() && simTime - (ui.waitStart || 0) > 2.5) { runner.siyaCalled = true; jessCollect(); return; }
  if (siyaInQueue() || roomBusy() || runner.cooldown > 0) return; // booked appointments get priority
  const next = students.filter(a => a.student.status === 'Waiting').sort((x, y) => x.student.timeIn - y.student.timeIn)[0];
  if (next) callStudent(next);
}
function callStudent(a) {
  const s = a.student; runner.job = true;
  tabletBubble(s.first, seatName(s.seat), s.say.split(' ')[0]);
  after(0.4, () => { if (dist(player, jess) < 14) speakName(s.speak); });
  after(2.2, () => {
    const ap = seatApproach(s.seat);
    jess.goTo(ap.x - 0.5, ap.z, () => {
      jess.face(a.x, a.z); jess.ch.wave = 1.2;
      say(jess, `${esc(s.first)}? <i>(${esc(s.say.split(' ')[0])})</i> Hi! Come with me — Naledi is ready for you.`, 3.5, 'Jess');
      s.status = 'Called'; s.timeCalled = clockMin(); updateScreens();
      after(1.4, () => {
        say(a, replyWhenCalled(a.name), 3); a.place(ap.x, ap.z, Math.PI);
        after(0.8, () => {
          jess.goTo(P.consultJessStand.x, P.consultJessStand.z, () => {
            jess.face(naledi.x, naledi.z); say(jess, `Naledi, this is ${esc(s.first)}.`, 2.5, 'Jess');
            after(1.6, () => jess.goTo(P.jessHome.x, P.jessHome.z, () => { jess.targetRot = 0; runner.job = false; runner.cooldown = 14; }, 2.2));
          }, 2.0);
          after(0.7, () => a.goTo(P.consultStudentChair.x, P.consultStudentChair.z, () => {
            a.sit(P.consultStudentChair.x, P.consultStudentChair.z, Math.PI); s.status = 'In consultation'; a.data.consultEnd = 7; naledi.ch.talk = 3; updateScreens();
          }, 1.9));
        });
      });
    }, 2.3);
  });
}
function updateStudents(dt) {
  for (const a of students) {
    const s = a.student;
    if (ui.started) {
      if (s.status === 'Arriving' && a.data.arriveAt != null && (a.data.arriveAt -= dt) <= 0) {
        // Alex walks in, scans the REGGY stand, then checks in at his seat
        a.data.arriveAt = null;
        a.goTo(P.qrApproach.x - 1.3, P.qrApproach.z + 0.6, () => {
          a.face(P.qrStand.x, P.qrStand.z); say(a, '📱 Scanning REGGY… beep!', 2.2);
          after(2.4, () => {
            s.timeIn = clockMin(); s.status = 'Checked in'; updateScreens();
            const ap = seatApproach(s.seat);
            a.goTo(ap.x, ap.z, () => { const p = seatPos(s.seat); a.sit(p.x, p.z + 0.05, Math.PI); s.status = 'Waiting'; updateScreens(); });
          });
        });
      }
      if (s.status === 'In consultation' && a.data.consultEnd != null && st.step === 'waiting') a.data.consultEnd = Math.min(a.data.consultEnd, 1.5); // Siya is waiting: wrap up
      if (s.status === 'In consultation' && a.data.consultEnd != null && (a.data.consultEnd -= dt) <= 0) {
        a.data.consultEnd = null; s.status = 'Done'; s.timeOut = clockMin(); updateScreens();
        a.place(P.consultApproach.x, P.consultApproach.z, -Math.PI / 2); naledi.ch.wave = 1;
        a.goTo(s.doneSpot.x, s.doneSpot.z, () => { a.targetRot = s.doneSpot.rot; a.data.talk = true; });
      }
      if ((a.data.ambient -= dt) <= 0) {
        a.data.ambient = 14 + rnd() * 14;
        const lines = AMBIENT[a.name];
        if (lines && (s.status === 'Waiting' || a.name === 'faatimaah') && dist(a, player) < 9 && !bubbles.has(a) && !ui.dialog) say(a, pick(lines), 3.5, s.first);
      }
    }
    if (a.data.talk && a.ch.talk <= 0 && rnd() < dt * 0.3) a.ch.talk = 1.5;
    a.update(dt);
  }
}

function startConsult() {
  if (st.step !== 'escort') return;
  if (!ui.jessSeated) { say(jess, 'Almost there — one moment! 🙂', 2.5, 'Jess'); return; }
  ui.busy = true; player.sitting = true; player.sit(P.consultStudentChair.x, P.consultStudentChair.z, Math.PI);
  advance('consult');
  // Jess hands over and returns to the waiting room for the next student
  jess.goTo(P.jessHome.x, P.jessHome.z, () => { jess.targetRot = 0; runner.job = false; runner.cooldown = 8; }, 2.2);
  const first = esc(st.student.first);
  const lines = [
    ['naledi', `Welcome, ${esc(st.student.preferred || first)}! I’m Naledi. You’ve applied for the <b>${esc(st.student.programme)}</b> — great choice.`],
    [{ name: first, role: 'You', color: '#f2a33a', initial: first[0] }, 'Thanks! Honestly, I don’t know where to start.'],
    ['naledi', 'That’s what REGGY is for. You’ll need three documents: your <b>ID</b>, your <b>qualification</b> and <b>proof of residence</b>.'],
    ['naledi', 'Registration verifies them, then Finance checks your fee payment. REGGY will show you each step!'],
  ];
  lines.forEach(([w, t], i) => after(i * 1.35, () => {
    showDialog(w, t, [], `<div class="progressbar"><div style="width:${((i + 1) / lines.length) * 100}%"></div></div><span class="ph-small">Consultation in progress · ${['about 5 seconds', 'course check', 'requirements', 'next steps'][i]}</span>`);
    if (w === 'naledi') naledi.ch.talk = 1.3; else player.ch.talk = 1.2;
  }));
  after(5.4, () => {
    closeDialog();
    st.appointment.status = 'Completed'; st.flags.advisorDone = true; st.siyaOut = clockMin(); updateScreens();
    player.sitting = false; player.place(P.consultApproach.x, P.consultApproach.z, Math.PI * 1.5);
    ui.busy = false;
    advance('leaveRoom');
    say(naledi, 'Good luck! REGGY has your next step.', 3.5, 'Naledi');
    toast('Appointment completed', 'Status: Completed. Head back out of the room.', { openAlerts: false });
  });
}

function onLeftRoom() {
  advance('docs');
  notify('Advisor meeting complete', 'Here’s your next step: your document checklist.');
  ui.jessSeated = false;
  ui.msg = docsChecklistMsg();
  openPhone(null, 'message');
}
function docsChecklistMsg() {
  const miss = missingDocs(st);
  const phone = miss.find(d => d.how === 'phone');
  return {
    title: 'Advisor meeting complete. Here’s your next step.',
    html: `<div class="alert">⚠️ ${phone ? `Your <b>${phone.name.toLowerCase()}</b> is missing. Upload it before registration verification.` : 'A document still needs attention.'}</div>
      <div class="ph-card">${st.documents.map(d => `<div class="ph-row"><span>${d.status === 'Missing' ? '❗' : '📤'}</span><div class="grow"><b>${d.name}</b></div><span class="chip ${d.status}">${d.status}</span></div>`).join('')}</div>`,
    buttons: [{ label: 'Open My documents', act: 'tab', arg: 'docs' }, { label: 'I need help — Document Assistance', act: 'goDocHelp' }],
  };
}

function finishUpload(kind) {
  if (kind === 'qual') {
    const d = st.documents.find(d => d.id === ui.uploadDoc) || st.documents.find(d => d.how === 'phone' && d.status === 'Missing');
    if (!d || st.step !== 'docs') return;
    d.status = 'Uploaded'; st.flags.uploaded = (st.flags.uploaded || []).concat(d.name);
    paperPop(player);
    notify('Document uploaded', `Your ${d.name.toLowerCase()} is now <b>Uploaded</b>. Staff will verify it at Registration.`);
    afterDocChange(d);
  } else {
    if (st.step !== 'feeUpload') return;
    st.payment.status = 'Uploaded'; paperPop(player);
    advance('finance');
    notify('Proof of payment uploaded', 'Next: Finance Assistance will review it.');
    ui.msg = { check: true, title: 'Proof of payment uploaded', changed: 'REGGY has your fictional proof of payment. Status: <b>Uploaded</b> (not yet verified).', next: 'Visit <b>Finance Assistance</b> on the right-hand side of the hall. A staff member will review it.', buttons: [{ label: 'Show me the way →', act: 'showWay' }] };
    ui.flow = 'message'; updateHUD();
  }
}
function afterDocChange(d) {
  const miss = missingDocs(st);
  if (!miss.length) {
    advance('registration');
    ui.msg = { check: true, title: 'All documents uploaded!', changed: `Your ${d.name.toLowerCase()} is now <b>Uploaded</b>. Uploaded means REGGY has it — <b>Verified</b> means a staff member has checked it.`, next: 'Go to <b>Registration, Counter 2</b> at the back of the hall. The officer will verify your documents.', buttons: [{ label: 'Show me the way →', act: 'showWay' }, { label: 'View my documents', act: 'tab', arg: 'docs' }] };
  } else {
    const nx = miss[0];
    ui.msg = { check: true, title: `${d.name} uploaded`, changed: `${d.name} is now <b>Uploaded</b>.`, next: nx.how === 'desk' ? `One more: your <b>${nx.name.toLowerCase()}</b> must be certified in person. Visit <b>Document Assistance</b> on the left side of the hall.` : `One more: upload your <b>${nx.name.toLowerCase()}</b>.`, buttons: nx.how === 'desk' ? [{ label: 'Show me the way →', act: 'showWay' }] : [{ label: `Upload ${nx.name.toLowerCase()}`, act: 'startUpload', arg: nx.id }] };
  }
  ui.flow = 'message'; ui.phoneOpen = ui.phoneOpen || !ui.dialog; updateHUD();
}

// --- registration officer ---
function talkLayla() {
  layla.face(player.x, player.z); layla.ch.talk = 2;
  const s = st.step;
  if (s === 'arrive' || s === 'identify') return showDialog('layla', 'Hi there! Before I can help, please check in with <b>REGGY</b> — the stand is just outside the main entrance. It will tell you exactly what you need.', [{ label: 'Show me the way', fn: () => { closeDialog(); guide(true); } }, bye('Okay, thanks!')]);
  if (['book', 'goWaiting', 'waiting', 'escort', 'consult', 'leaveRoom'].includes(s)) {
    reggyReminder('Not yet: meet your student advisor', 'Registration comes after your advisor meeting. REGGY will tell you when it’s time.');
    return showDialog('layla', 'Nice to meet you! You’ll need to see a <b>student advisor</b> before registration — they make sure you’re on the right course. REGGY has the details.', [bye('Got it')]);
  }
  if (s === 'docs') {
    const miss = missingDocs(st);
    reggyReminder('Still to do before Registration', `Missing: ${miss.map(d => d.name.toLowerCase()).join(', ')}.`);
    return showDialog('layla', `Almost! Your <b>${miss.map(d => d.name.toLowerCase()).join('</b> and <b>')}</b> ${miss.length > 1 ? 'are' : 'is'} still missing. Please upload ${miss.length > 1 ? 'them' : 'it'} in REGGY — or Document Assistance can help you. Then come back to me.`, [
      { label: 'Open My documents', primary: true, fn: () => openPhone('docs') }, bye('Okay'),
    ]);
  }
  if (s === 'registration') {
    const returning = st.scenario === 'returning';
    return showDialog('layla', returning ? `Welcome back, ${esc(st.student.first)}! Let’s confirm your Year 2 registration.` : `Hello ${esc(st.student.first)}! REGGY says your documents are ready. May I see them?`, [
      { label: returning ? 'Show my documents & confirm modules' : 'Show my documents', primary: true, fn: verifyDocuments },
      { label: 'What happens here?', fn: () => showDialog('layla', 'I compare your uploaded files with your originals. Once I confirm them, they change from <b>Uploaded</b> to <b>Verified</b> in REGGY.', [{ label: 'Show my documents', primary: true, fn: verifyDocuments }, bye('Maybe later')]) },
      bye('Not yet'),
    ]);
  }
  if (s === 'complete') return showDialog('layla', `Congratulations, ${esc(st.student.first)} — you’re fully registered! Enjoy your first semester.`, [bye('Thank you!')]);
  return showDialog('layla', `You’re verified with me! ${st.step === 'feeUpload' || st.step === 'finance' ? 'Finance is your next stop — REGGY will guide you.' : ''}`, [bye()]);
}
function verifyDocuments() {
  if (st.step !== 'registration') return;
  ui.busy = true; layla.ch.stamp = 3;
  const docs = st.documents;
  const render = (n) => showDialog('layla', 'Checking your documents against the originals…', [], `<ul class="checklist">${docs.map((d, i) => `<li class="${i < n ? 'ok' : i === n ? 'wait' : ''}"><span class="ic">${i < n ? '✓' : ''}</span>${d.name}<span class="chip ${i < n ? 'Verified' : d.status}" style="margin-left:auto">${i < n ? 'Verified' : d.status}</span></li>`).join('')}</ul>`);
  render(0);
  const paper = paperOnCounter(0, -11.75);
  docs.forEach((d, i) => after(0.8 * (i + 1), () => { render(i + 1); sfx.click(); paper.position.z -= 0.15; }));
  after(0.8 * docs.length + 0.6, () => {
    scene.remove(paper);
    docs.forEach(d => d.status = 'Verified');
    st.regStatus = 'Verified'; ui.busy = false; st.flags.regDone = true;
    sfx.success();
    const nxt = nextAfter('registration');
    if (nxt === 'feeUpload') {
      advance('feeUpload');
      notify('Registration verified ✓', 'All your documents are now <b>Verified</b>. Next step: fee verification.');
      showDialog('layla', 'All verified! ✅ One last thing: as a new student, <b>Finance</b> needs to check your fee payment. REGGY will show you how.', [{ label: 'Open REGGY', primary: true, fn: () => openPhone(null, 'feeInfo') }]);
    } else {
      notify('Registration verified ✓', 'Your Year 2 modules are confirmed. No fee verification is needed for you this year.');
      showDialog('layla', `All done, ${esc(st.student.first)}! Your Year 2 modules are confirmed and you don’t need fee verification this year.`, [{ label: 'Finish registration 🎉', primary: true, fn: () => { closeDialog(); completeRegistration(); } }]);
    }
  });
}

// --- finance ---
function talkDaniel() {
  daniel.face(player.x, player.z); daniel.ch.talk = 2;
  const s = st.step;
  if (!scenarioOf(st).fee && st.identified) return showDialog('daniel', 'Hi! REGGY shows you’re a returning student with no fee verification this year — nothing needed here. 🙂', [bye()]);
  if (s === 'feeUpload') {
    reggyReminder('Add your proof of payment first', 'Open REGGY to attach your fictional proof of payment.');
    return showDialog('daniel', 'Hello! Please add your <b>proof of payment</b> in REGGY first — then I can review it for you.', [{ label: 'Open REGGY', primary: true, fn: () => openPhone(null, 'feeInfo') }, bye('Okay')]);
  }
  if (s === 'finance') return showDialog('daniel', `Hi ${esc(st.student.first)}! I can see your proof of payment in REGGY. Shall I review it now?`, [{ label: 'Show proof of payment', primary: true, fn: verifyPayment }, bye('Not yet')]);
  if (s === 'complete') return showDialog('daniel', 'All settled — enjoy your studies at Emeris!', [bye('Thanks!')]);
  return showDialog('daniel', 'Hello! Fee verification happens after <b>Registration</b> has verified your documents. REGGY will tell you when it’s time to see me.', [bye('Got it')]);
}
function verifyPayment() {
  if (st.step !== 'finance') return;
  ui.busy = true; daniel.ch.stamp = 2.6;
  const checks = ['Student number matches', 'Amount matches registration fee', 'Reference is valid'];
  const render = (n) => showDialog('daniel', 'Reviewing your proof of payment… (simulated — no real money involved)', [], `<ul class="checklist">${checks.map((c, i) => `<li class="${i < n ? 'ok' : i === n ? 'wait' : ''}"><span class="ic">${i < n ? '✓' : ''}</span>${c}</li>`).join('')}</ul>`);
  render(0);
  const paper = paperOnCounter(16.95, 4, true);
  checks.forEach((c, i) => after(0.8 * (i + 1), () => { render(i + 1); sfx.click(); }));
  after(0.8 * checks.length + 0.6, () => {
    scene.remove(paper);
    st.payment.status = 'Verified'; ui.busy = false; st.flags.feeDone = true;
    world.highlights.financeLight.material.color.set('#22b573'); world.highlights.financeLight.material.emissive.set('#22b573');
    sfx.success();
    notify('Fee verification complete ✓', 'Your proof of payment is <b>Verified</b>. That was your final step!');
    showDialog('daniel', 'Perfect — your payment is verified. ✅ That was your final step!', [{ label: 'Finish registration 🎉', primary: true, fn: () => { closeDialog(); completeRegistration(); } }]);
  });
}

// --- document assistance ---
function talkSam() {
  sam.face(player.x, player.z); sam.ch.talk = 2;
  if (st.step === 'docs') {
    const miss = missingDocs(st);
    const desk = miss.find(d => d.how === 'desk'), ph = miss.find(d => d.how === 'phone');
    if (desk) return showDialog('sam', `Hi ${esc(st.student.first)}! I can certify a copy of your ID right here — it only takes a moment.`, [{ label: 'Yes, please certify it', primary: true, fn: () => deskScan(desk, 'Certifying your ID copy…') }, bye('Later')]);
    if (ph) return showDialog('sam', `Hi ${esc(st.student.first)}! Having trouble with your ${ph.name.toLowerCase()}? I can scan your paper copy and upload it to REGGY for you.`, [{ label: 'Yes, scan it for me', primary: true, fn: () => deskScan(ph, 'Scanning your certificate…') }, { label: 'I’ll do it on my phone', fn: () => { closeDialog(); act('startUpload', ph.id); } }, bye('No thanks')]);
  }
  return showDialog('sam', 'Hi! If you ever have trouble with a document, I can scan or certify it for you. Remember: <b>Uploaded</b> means REGGY has your file; <b>Verified</b> means staff have checked it.', [bye()]);
}
function deskScan(doc, label) {
  ui.busy = true; sam.ch.stamp = 2;
  showDialog('sam', label, [], '<div class="progressbar"><div id="scanbar" style="width:0"></div></div>');
  world.highlights.scanner.material.opacity = 0.9;
  for (let i = 1; i <= 10; i++) after(i * 0.2, () => { const b = $('#scanbar'); if (b) b.style.width = i * 10 + '%'; });
  after(2.2, () => {
    world.highlights.scanner.material.opacity = 0.2; ui.busy = false;
    doc.status = 'Uploaded'; st.flags.uploaded = (st.flags.uploaded || []).concat(doc.name + ' (via Document Assistance)');
    sfx.success();
    notify('Document uploaded', `${doc.name} uploaded by Document Assistance. Status: <b>Uploaded</b>.`);
    closeDialog();
    afterDocChange(doc);
    ui.phoneOpen = true; updateHUD();
  });
}

// --- reception & Riley ---
function talkNadia() {
  nadia.face(player.x, player.z); nadia.ch.talk = 2;
  const choices = [
    { label: 'How does REGGY work?', fn: () => showDialog('nadia', 'REGGY is your registration guide. Scan the code at the stand outside, and it shows your next step, books appointments and tracks your documents. Just follow the glowing path!', [bye('Makes sense!')]) },
    { label: 'Where is Registration?', fn: () => showDialog('nadia', 'Straight ahead at the back of the hall, past the waiting area. Counter 2 is in the middle.', [bye()]) },
  ];
  if (st.step === 'identify') choices.unshift({ label: 'I don’t have my ID with me', primary: true, fn: () => showDialog('nadia', 'No problem! I’ve found your profile with your name and date of birth, and sent a REGGY link to your phone. 📲', [{ label: 'Open REGGY', primary: true, fn: () => { closeDialog(); const sc = scenarioOf(st); identify(sc.student.name, sc.demoId); } }]) });
  if (st.step === 'arrive') choices.unshift({ label: 'Where do I start?', primary: true, fn: () => showDialog('nadia', 'Welcome to Emeris! Start at the <b>REGGY stand</b> just outside the entrance — scan the code and REGGY will guide you step by step.', [{ label: 'Show me the way', primary: true, fn: () => { closeDialog(); guide(true); } }]) });
  showDialog('nadia', st.step === 'complete' ? `Congratulations, ${esc(st.student.first)}! Welcome to the Emeris family. 🎓` : 'Welcome to Emeris University! How can I help?', [...choices, bye('That’s all, thanks')]);
}
function talkRiley() {
  if (riley.data.helped) return showDialog('riley', 'Thanks again for the directions! 😊', [bye('Good luck!')]);
  riley.face(player.x, player.z);
  showDialog('riley', 'Hi! Sorry — do you know where <b>Reception</b> is? It’s my first day…', [
    { label: 'Inside, on the left', primary: true, fn: () => { riley.data.helped = true; showDialog('riley', 'Thank you so much! See you around. 👋', [bye('Good luck!')]); riley.tag = 'Riley · New student'; after(0.8, () => riley.goTo(-10.3, 11.6, () => { riley.targetRot = Math.PI; riley.data.talk = true; })); } },
    { label: 'Try asking REGGY!', fn: () => { riley.data.helped = true; showDialog('riley', 'Good idea — I’ll scan the stand too! 📱', [bye()]); riley.tag = 'Riley · New student'; after(0.8, () => riley.goTo(P.qrApproach.x - 1.2, P.qrApproach.z + 0.6, () => { riley.face(P.qrStand.x, P.qrStand.z); after(2.5, () => riley.goTo(-10.3, 11.6, () => { riley.targetRot = Math.PI; })); })); } },
    bye('Sorry, no idea'),
  ]);
}
function talkJess() {
  jess.face(player.x, player.z); jess.ch.talk = 2;
  const s = st.step, me = esc(st.student?.preferred || 'there');
  const more = [
    { label: 'What does a runner do?', fn: () => showDialog('jess', 'I look after the advisor waiting room. My tablet shows who has checked in, their seat, and how to say their name. I greet each student properly and walk them to their advisor, and REGGY logs their time in and time out. The advisors can stay focused on advising.', [{ label: '📋 Show me your tablet', primary: true, fn: () => { closeDialog(); openRunnerPanel(); } }, bye('Makes sense!')]) },
    { label: 'How do you say names right?', fn: () => showDialog('jess', 'At check-in, REGGY asks every student how their name is said — a sounds-like spelling, and they can record their voice. I tap 🔊 and practise before I call them, then walk to their seat instead of shouting across the room.', [{ label: '📋 Show me your tablet', primary: true, fn: () => { closeDialog(); openRunnerPanel(); } }, bye('Clever!')]) },
    { label: '📋 Show me your tablet', fn: () => { closeDialog(); openRunnerPanel(); } },
  ];
  if (s === 'arrive' || s === 'identify' || s === 'book') return showDialog('jess', `Hi${st.student ? ' ' + me : ''}! I’m Jess, the <b>runner</b> for Advisor Services. Book a time with <b>Naledi</b>, our student advisor, in REGGY — and I’ll collect you from the waiting area.`, [...(s === 'book' ? [{ label: 'Book in REGGY', primary: true, fn: () => openPhone(null, 'advisor') }] : []), ...more, bye('Thanks!')]);
  if (s === 'goWaiting') return showDialog('jess', `You’re on my tablet, ${me}! Take a seat in the waiting area — your seat is glowing — and I’ll come and get you.`, [...more, bye('On my way')]);
  if (s === 'complete') return showDialog('jess', `You did it, ${me}! 🎉 Come and see us any time during the semester.`, [...more, bye('Thanks, Jess!')]);
  return showDialog('jess', `Hi again, ${me}! Keep following REGGY — you’re doing great.`, [...more, bye()]);
}
function talkNaledi() {
  naledi.ch.talk = 2;
  if (['escort'].includes(st.step)) return showDialog('naledi', 'Hello! Please take the seat across from me and we’ll begin.', [bye('Okay')]);
  const inRoom = students.find(a => a.student.status === 'In consultation');
  if (inRoom) return showDialog('naledi', `I’m with ${esc(inRoom.student.first)} right now — Jess will bring you in when it’s your turn. 🙂`, [bye('No problem')]);
  showDialog('naledi', st.flags.advisorDone ? `Good to see you again, ${esc(st.student.preferred)}! Any questions about your course, just book through REGGY.` : 'Hi, I’m Naledi, a student advisor. Jess, our runner, brings each student to me — so I can spend my time advising, not searching the waiting room.', [bye('Thanks!')]);
}
const PROFILE_INFO = {
  jess: 'Runner — manages the advisor waiting room. Her tablet shows who checked in, which seat, and how to pronounce each name. She greets students correctly, walks them to their advisor and logs time in and out.',
  naledi: 'Student Advisor — meets students in the consultation room to check course choices and explain registration requirements.',
  nadia: 'Receptionist — welcomes visitors, helps people without ID, and explains how REGGY works.',
  layla: 'Registration Officer — compares uploaded documents with the originals and marks them Verified.',
  daniel: 'Finance Assistance — reviews proof of payment for fee verification.',
  sam: 'Document Assistance — scans, certifies and uploads documents for students who need help.',
  clerk1: 'Registration clerk — serving the Counter 1 queue.', clerk2: 'Registration clerk — serving the Counter 3 queue.', clerk3: 'Finance clerk — helping with fee questions.',
  riley: 'A new student on their first day — looking a bit lost.',
};
const studentWho = (a) => ({ name: a.student.first, role: `Student · ${a.student.programme}`, color: a.student.color, initial: a.student.first[0] });
function chatWith(a) {
  closeProfile();
  const talkers = { nadia: talkNadia, jess: talkJess, naledi: talkNaledi, layla: talkLayla, daniel: talkDaniel, sam: talkSam, riley: talkRiley };
  if (talkers[a.name]) return talkers[a.name]();
  if (a.name.startsWith('clerk')) return showDialog({ name: 'Clerk', role: 'Emeris staff', color: '#0b2a4a', initial: 'C' }, 'Hi! I’m helping the students in my queue right now — Layla at Counter 2 is the one to see for your registration.', [bye()]);
  if (a.student) {
    const s = a.student, me = esc(st.student?.preferred || SIYA.first), tree = chatFor(s, { me });
    if (a.ch.pose !== 'sit') a.face(player.x, player.z);
    a.ch.talk = 2;
    if (['Called', 'In consultation'].includes(s.status) && s.id !== 'faatimaah') return showDialog(studentWho(a), `Sorry ${me}, I’m with the advisor right now — catch you after! 👋`, [bye('Good luck!')]);
    if (['Called', 'In consultation'].includes(s.status)) return showDialog(studentWho(a), tree.greet, [bye('Good luck!')]);
    ui.camFocus = a;
    const asked = new Set();
    const menu = (text) => showDialog(studentWho(a), text, [
      ...tree.topics.filter(([q]) => !asked.has(q)).slice(0, 3).map(([q, ans]) => ({ label: q, fn: () => { asked.add(q); a.ch.talk = 2.5; if (/say your name/i.test(q)) speakName(s.speak); menu(ans); } })),
      { label: 'See you around! 👋', fn: () => { closeDialog(); a.ch.wave = 1.2; } },
    ]);
    return menu(tree.greet);
  }
  // background students: short general chat
  const n = a.data.name || 'Student';
  a.face(player.x, player.z); a.ch.talk = 2;
  const who = { name: n, role: `Student · ${a.data.programme || 'Emeris'}`, color: '#5b6b80', initial: n[0] };
  ui.camFocus = a;
  showDialog(who, pick(GENERIC_LINES), [
    { label: 'How are you finding REGGY?', fn: () => showDialog(who, 'Honestly? Life-saver. I always know what’s next, and the runner actually says my name right. 😄', [bye('Same here!')]) },
    bye('Good luck! 👋'),
  ]);
}

// ---------------- click a character → profile card ----------------
let profileAgent = null;
function allAgents() { return [player, ...staffAgents, riley, ...students, ...npcs]; }
function pickAgentAt(cx, cy) {
  const v = new THREE.Vector2((cx / window.innerWidth) * 2 - 1, -(cy / window.innerHeight) * 2 + 1);
  ray.setFromCamera(v, camera); ray.far = 200;
  const hit = ray.intersectObjects(allAgents().map(a => a.ch.root), true)[0];
  return hit ? hit.object.userData.agent : null;
}
function showProfile(a) {
  profileAgent = a; sfx.click();
  const el = $('#profile');
  const d = dist(a, player), near = d < 3.6;
  let html = '';
  const timeRow = (i, c, o) => `<div class="pf-times"><div><span>Time in</span><b>${hhmm(i)}</b></div><div><span>Called</span><b>${hhmm(c)}</b></div><div><span>Time out</span><b>${hhmm(o)}</b></div></div>`;
  if (a === player) {
    const stu = st.student;
    html = `<div class="pf-head"><div class="pf-av" style="background:#f2a33a">${(stu?.preferred || SIYA.first)[0]}</div><div><div class="pf-name">${esc(stu?.name || SIYA.full)} <span class="pf-you">You</span></div><div class="pf-role">${esc(stu?.programme || 'New student')}</div></div></div>
      <div class="pf-say">🗣️ Call me <b>${esc(stu?.preferred || SIYA.first)}</b> · “${esc(stu?.say || SIYA.say)}” <button class="mini-btn" data-act="speak" data-arg="siya">🔊</button></div>
      <div class="pf-say small">Surname: ${esc(SIYA.surnameSay)} — ${esc(SIYA.surnameTip)}</div>
      ${st.appointment ? timeRow(st.siyaIn, st.siyaCalled, st.siyaOut) : ''}
      <div class="pf-line">Now: ${esc(objective(st).obj)}</div>`;
  } else if (a.student) {
    const s = a.student;
    html = `<div class="pf-head"><div class="pf-av" style="background:${s.color}">${s.first[0]}</div><div><div class="pf-name">${esc(s.name)}</div><div class="pf-role">${esc(s.programme)} · from ${esc(s.from)}</div></div></div>
      <div class="pf-say">🗣️ Say it: <b>${esc(s.say)}</b> <button class="mini-btn" data-act="speak" data-arg="${a.name}">🔊</button></div>
      <div class="pf-status"><span class="chip info">${esc(s.status === 'Done' ? s.doneLabel : s.status)}</span>${s.seat != null && s.status === 'Waiting' ? ` <span class="chip info">Seat ${seatName(s.seat)}</span>` : ''}</div>
      ${timeRow(s.timeIn, s.timeCalled, s.timeOut)}`;
  } else if (PROFILE_INFO[a.name]) {
    const p = people[a.name] || { name: a.name[0].toUpperCase() + a.name.slice(1), role: 'Emeris staff', color: '#0b2a4a' };
    const nm = a.name === 'naledi' ? NALEDI.name : p.name;
    html = `<div class="pf-head"><div class="pf-av" style="background:${p.color}">${nm[0]}</div><div><div class="pf-name">${esc(nm)}</div><div class="pf-role">${esc(p.role)}</div></div></div>
      ${a.name === 'naledi' ? `<div class="pf-say">🗣️ Say it: <b>${NALEDI.say}</b> <button class="mini-btn" data-act="speak" data-arg="naledi">🔊</button></div>` : ''}
      <div class="pf-line">${PROFILE_INFO[a.name]}</div>
      ${a.name === 'jess' ? '<button class="ph-btn" data-act="runnerPanel">📋 Open Jess’s runner tablet</button>' : ''}`;
  } else {
    const n = a.data.name || 'Student';
    html = `<div class="pf-head"><div class="pf-av" style="background:#5b6b80">${n[0]}</div><div><div class="pf-name">${esc(n)}</div><div class="pf-role">Student · ${esc(a.data.programme || 'Emeris')}</div></div></div>
      <div class="pf-line">${a.mode === 'queue' ? 'Queueing at a counter.' : a.ch.pose === 'sit' ? 'Taking a break.' : 'Exploring campus.'}</div>`;
  }
  if (a !== player) html += near ? `<button class="ph-btn" data-act="chatProfile">💬 Chat</button>` : `<button class="ph-btn sec" data-act="walkTo">🧭 Walk over to chat (${Math.round(d)} m)</button>`;
  html += `<button class="pf-close" data-act="profileClose" title="Close">✕</button>`;
  el.innerHTML = html; el.classList.remove('hidden');
  if (a !== player && a !== jess) ui.camFocus = a; // swing round to see their face
}
function closeProfile() { profileAgent = null; $('#profile').classList.add('hidden'); if (!ui.dialog) ui.camFocus = null; }

// ---------------- Jess's runner tablet ----------------
function openRunnerPanel() { closeProfile(); ui.runnerOpen = true; renderRunnerPanel(); $('#runnerPanel').classList.remove('hidden'); sfx.click(); }
function renderRunnerPanel() {
  if (!ui.runnerOpen) return;
  const rows = queueRows();
  $('#runnerBody').innerHTML = `
    <div class="rt-clock">🕒 ${hhmm(clockMin())} · ${rows.filter(r => r.status === 'Waiting' || r.status === 'In Waiting Room').length} waiting · room ${roomBusy() ? '<b style="color:#b26b00">busy</b>' : '<b style="color:#13824f">free</b>'}</div>
    <table class="rt"><thead><tr><th>Student & how to say it</th><th>Seat</th><th>In</th><th>Called</th><th>Out</th><th>Status</th></tr></thead><tbody>
    ${rows.map(r => `<tr class="${r.you ? 'you' : ''}"><td><span class="rt-dot" style="background:${r.color}"></span><b>${esc(r.first)}</b><div class="rt-say">“${esc(r.say)}” <button class="mini-btn" data-act="speak" data-arg="${r.id}">🔊</button></div></td><td>${r.seat}</td><td>${hhmm(r.in)}</td><td>${hhmm(r.called)}</td><td>${hhmm(r.out)}</td><td><span class="chip ${r.out ? 'Verified' : r.status === 'Called' || r.status === 'In consultation' || r.status === 'In Progress' ? 'Uploaded' : 'info'}">${esc(r.out ? 'Done' : r.status)}</span></td></tr>`).join('')}
    </tbody></table>
    <p class="ph-small">Pronunciations come from each student at check-in in REGGY (sounds-like spelling + optional voice). Jess walks to the seat and greets the student by their preferred name — no shouting across the room.</p>`;
}

function reggyReminder(title, body) {
  notify(title, body, { button: { label: 'Open REGGY', act: 'phoneOpenDefault' } });
}

// ====================================================================
// Completion
// ====================================================================
function completeRegistration() {
  if (st.step === 'complete') return;
  advance('complete'); sfx.fanfare(); confetti();
  banner(`Registration complete.<br>Welcome to Emeris University!<small>Well done, ${esc(st.student.first)} 🎓</small>`, 5000);
  notify('Registration complete 🎓', 'Welcome to Emeris University! Your registration is confirmed.');
  const sc = scenarioOf(st);
  const secs = Math.round(simTime - ui.visitStart);
  const items = [
    ['Checked in with REGGY by scanning the QR code', true],
    [`Identified as ${esc(st.student.name)} (${esc(st.student.id)})`, true],
    [sc.advisor ? 'Booked and met student advisor Jess' : sc.advisorDoneEarlier ? 'Advisor meeting (done earlier)' : 'No advisor meeting needed', sc.advisor || sc.advisorDoneEarlier],
    [st.flags.uploaded?.length ? `Uploaded: ${st.flags.uploaded.map(esc).join(', ')}` : 'Documents already on file', true],
    ['Documents verified at Registration', true],
    [sc.fee ? 'Fee payment verified at Finance' : 'Fee verification not needed this year', sc.fee],
  ];
  $('#doneList').innerHTML = items.map(([t, ok]) => `<li class="${ok ? '' : 'skip'}">${t}</li>`).join('') + `<li class="skip" style="color:#5b6b80">Time taken: ${Math.floor(secs / 60)} min ${secs % 60} s</li>`;
  after(2.2, () => { $('#complete').classList.remove('hidden'); ui.overlay = 'complete'; });
}

let confettiMesh = null, confettiData = null;
function confetti() {
  if (confettiMesh) scene.remove(confettiMesh);
  const n = 220;
  confettiMesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.12, 0.2), new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }), n);
  const cols = ['#16c7e8', '#0b2a4a', '#ffffff', '#ffd166', '#22b573', '#ff7aa2'].map(c => new THREE.Color(c));
  confettiData = [];
  for (let i = 0; i < n; i++) {
    confettiMesh.setColorAt(i, cols[i % cols.length]);
    const a = rnd() * Math.PI * 2, r = rnd() * 1.2;
    confettiData.push({ x: player.x + Math.cos(a) * r, y: 2 + rnd(), z: player.z + Math.sin(a) * r, vx: Math.cos(a) * (1 + rnd() * 3), vy: 4 + rnd() * 4, vz: Math.sin(a) * (1 + rnd() * 3), rx: rnd() * 6, ry: rnd() * 6, life: 5 + rnd() * 2 });
  }
  confettiMesh.frustumCulled = false; scene.add(confettiMesh);
}
const dummy = new THREE.Object3D();
function updateConfetti(dt) {
  if (!confettiMesh) return;
  let alive = 0;
  confettiData.forEach((p, i) => {
    p.life -= dt;
    if (p.y > 0.02) { p.vy -= 6 * dt; p.vx *= 0.985; p.vz *= 0.985; p.x += p.vx * dt; p.y = Math.max(0.02, p.y + p.vy * dt); p.z += p.vz * dt; p.rx += dt * 5; p.ry += dt * 4; }
    if (p.life > 0) alive++;
    dummy.position.set(p.x, p.y, p.z); dummy.rotation.set(p.rx, p.ry, 0); dummy.scale.setScalar(p.life > 0 ? 1 : 0); dummy.updateMatrix();
    confettiMesh.setMatrixAt(i, dummy.matrix);
  });
  confettiMesh.instanceMatrix.needsUpdate = true;
  if (!alive) { scene.remove(confettiMesh); confettiMesh = null; }
}
const paperGeo = new THREE.BoxGeometry(0.3, 0.02, 0.4), paperMat = new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: '#16c7e8', emissiveIntensity: 0.15 });
function paperOnCounter(x, z, rotate = false) { const m = new THREE.Mesh(paperGeo, paperMat); m.position.set(x, 1.11, z); if (rotate) m.rotation.y = Math.PI / 2; m.castShadow = true; scene.add(m); return m; }
function paperPop(agent) {
  const m = new THREE.Mesh(paperGeo, paperMat); m.rotation.x = Math.PI / 2; scene.add(m);
  const t0 = simTime; floaters.push({ m, t0, agent });
}
const floaters = [];
function updateFloaters() {
  for (let i = floaters.length - 1; i >= 0; i--) {
    const f = floaters[i], k = simTime - f.t0;
    f.m.position.set(f.agent.x, 2 + k * 1.2, f.agent.z); f.m.rotation.y = k * 4; f.m.material.opacity = 1;
    if (k > 1.6) { scene.remove(f.m); floaters.splice(i, 1); }
  }
}

// ====================================================================
// Interactables
// ====================================================================
const interactables = [
  { id: 'qr', pos: P.qrApproach, at: P.qrStand, r: 2.3, label: () => st.step === 'arrive' ? 'Press E to scan' : 'Open REGGY', run: () => st.step === 'arrive' ? startScan() : openPhone() },
  { id: 'seat', pos: P.waitApproach, at: P.waitSeat, r: 1.6, when: () => st.step === 'goWaiting', label: () => 'Check in & sit down', run: checkInSeat },
  { id: 'consult', pos: P.consultApproach, at: P.consultStudentChair, r: 1.8, when: () => st.step === 'escort', label: () => ui.jessSeated ? 'Sit down with Naledi' : 'Wait for Jess…', run: startConsult },
  { id: 'layla', pos: P.registration, at: P.regOfficer, r: 2.1, label: () => 'Talk to Layla · Registration', run: talkLayla },
  { id: 'daniel', pos: P.finance, at: P.financeOfficer, r: 2.1, label: () => 'Talk to Daniel · Finance', run: talkDaniel },
  { id: 'sam', pos: P.docAssist, at: P.docStaff, r: 2.1, label: () => 'Talk to Sam · Document Help', run: talkSam },
  { id: 'nadia', pos: P.reception, at: P.receptionist, r: 2.1, label: () => 'Talk to Nadia · Reception', run: talkNadia },
  { id: 'jess', pos: P.advisorDesk, at: P.jessHome, r: 2.1, when: () => dist(jess, P.jessHome) < 0.5, label: () => 'Talk to Jess · Runner', run: talkJess },
  { id: 'riley', get pos() { return riley; }, at: null, r: 1.8, label: () => 'Talk to Riley', run: talkRiley, when: () => !riley.moving },
  { id: 'naledi', pos: { x: 16, z: -7.6 }, at: { x: 16, z: -11.4 }, r: 1.6, when: () => st.step !== 'escort' && st.step !== 'consult', label: () => 'Talk to Naledi · Advisor', run: talkNaledi },
  ...students.map(a => ({ id: 'stu-' + a.name, get pos() { return a; }, at: null, r: 1.9, when: () => !a.moving && !['Called', 'In consultation'].includes(a.student.status), label: () => `Chat with ${a.student.first}`, run: () => chatWith(a) })),
];
let currentInteract = null;
function updateInteract() {
  let best = null, bd = 1e9;
  if (canMove()) for (const it of interactables) {
    if (it.when && !it.when()) continue;
    const d = dist(player, it.pos) - (it.id === 'seat' || it.id === 'consult' ? 1 : 0); // journey steps beat chatting
    if (d < it.r && d < bd) { best = it; bd = d; }
  }
  if (best !== currentInteract) {
    currentInteract = best;
    $('#prompt').classList.toggle('hidden', !best);
  }
  if (best) { const l = best.label(); $('#promptText').textContent = l; $('#promptBtn').textContent = l.startsWith('Press E') ? 'Scan' : best.id === 'seat' ? 'Sit' : 'Go'; }
}
function interact() {
  if (!currentInteract || !canMove()) return;
  const it = currentInteract; sfx.click();
  if (it.at) player.face(it.at.x, it.at.z);
  it.run();
}

// ====================================================================
// Route guidance
// ====================================================================
const DEST = {
  qrStand: { route: P.qrApproach, mark: P.qrStand, name: 'REGGY stand', dir: 'The REGGY stand is just in front of the main entrance, on the right of the path.' },
  waitSeat: { route: P.waitApproach, mark: P.waitSeat, name: 'Your seat · Waiting area', dir: 'The waiting area is in the middle of the main hall, with blue seats. Your seat is glowing.' },
  consultApproach: { route: P.consultApproach, mark: P.consultStudentChair, name: 'Consultation room', dir: 'The consultation room is at the back right of the hall. Go through the wooden door.' },
  roomExit: { route: P.roomExit, mark: P.roomExit, name: 'Room exit', dir: 'Walk out through the door on the left side of the room.' },
  registration: { route: P.registration, mark: P.regOfficer, name: 'Registration · Counter 2', dir: 'Registration is at the back of the main hall, behind the waiting area. Go to Counter 2 in the middle.' },
  finance: { route: P.finance, mark: P.financeOfficer, name: 'Finance Assistance', dir: 'Finance Assistance is on the right-hand side of the main hall.' },
  docAssist: { route: P.docAssist, mark: P.docStaff, name: 'Document Assistance', dir: 'Document Assistance is on the left-hand side of the main hall.' },
  reception: { route: P.reception, mark: P.receptionist, name: 'Reception', dir: 'Reception is just inside the main entrance, on the left.' },
};
let routeDirty = true, routeTimer = 0, routePts = [], routeLast = { x: 1e9, z: 1e9 };
function currentDest() {
  if (ui.follow) { // "Walk over" to a person the visitor clicked
    const f = ui.follow;
    if (dist(player, f) < 2.4 || simTime - ui.followSince > 45) { ui.follow = null; routeDirty = true; }
    else return { route: { x: f.x, z: f.z }, mark: f, name: ui.followName, dir: `${ui.followName} is marked with the cyan diamond.` };
  }
  const { dest } = objective(st); return dest ? DEST[dest] : null;
}
function updateRoute(dt) {
  const d = currentDest();
  const dots = world.routeDots, mk = world.marker;
  if (!d || !ui.started || st.step === 'waiting' || st.step === 'consult') { dots.count = 0; mk.group.visible = false; routePts = []; return; }
  mk.group.visible = true; mk.group.position.set(d.mark.x, 0, d.mark.z);
  mk.diamond.rotation.y += dt * 2; mk.diamond.position.y = 2.7 + Math.sin(simTime * 3) * 0.12;
  const s = 1 + Math.sin(simTime * 4) * 0.12; mk.ring.scale.set(s, s, s);
  routeTimer -= dt;
  if (routeDirty || (routeTimer <= 0 && (Math.hypot(player.x - routeLast.x, player.z - routeLast.z) > 0.6))) {
    routePts = [{ x: player.x, z: player.z }, ...findPath(player.x, player.z, d.route.x, d.route.z)];
    routeLast = { x: player.x, z: player.z }; routeTimer = 0.3; routeDirty = false;
  }
  if (routePts.length) routePts[0] = { x: player.x, z: player.z };
  // place animated dots along polyline
  const spacing = 0.75, phase = (simTime * 1.6) % spacing;
  let count = 0, carry = spacing - phase + 0.6;
  const pulse = ui.guidePulse > 0 ? 1.6 : 1;
  for (let i = 0; i < routePts.length - 1 && count < 400; i++) {
    const a = routePts[i], b = routePts[i + 1];
    const L = Math.hypot(b.x - a.x, b.z - a.z);
    let t = carry;
    while (t < L && count < 400) {
      const f = t / L;
      dummy.position.set(a.x + (b.x - a.x) * f, 0.05, a.z + (b.z - a.z) * f);
      dummy.rotation.set(-Math.PI / 2, 0, 0);
      const fade = Math.min(1, count / 3);
      dummy.scale.setScalar(pulse * (0.6 + 0.4 * fade)); dummy.updateMatrix();
      dots.setMatrixAt(count++, dummy.matrix);
      t += spacing;
    }
    carry = t - L;
  }
  dots.count = count; dots.instanceMatrix.needsUpdate = true;
  dots.material.opacity = 0.65 + Math.sin(simTime * 5) * 0.2;
}

function guide(force = false) {
  ui.lastInput = performance.now();
  const d = currentDest();
  if (!ui.started) return;
  if (!d) {
    if (st.step === 'waiting') return toast('Hang tight!', 'Jess is on her way to collect you from the waiting area.', { openAlerts: false });
    if (st.step === 'consult') return toast('Consultation in progress', 'Listen to Jess — it only takes a few seconds.', { openAlerts: false });
    if (st.step === 'complete') return toast('All done! 🎓', 'Explore the campus or press Pause › Restart for the next visitor.', { openAlerts: false });
    openPhone();
    return toast('Your next step is in REGGY', 'Follow the instructions on your REGGY phone.', { openAlerts: false });
  }
  closePhone(); closeDialog();
  ui.guidePulse = 4; routeDirty = true;
  // turn the camera to look along the route
  const path = findPath(player.x, player.z, d.route.x, d.route.z);
  const tgt = path.length ? path[Math.min(1, path.length - 1)] : d.route;
  const dx = tgt.x - player.x, dz = tgt.z - player.z;
  if (Math.hypot(dx, dz) > 0.5) cam.yawTarget = Math.atan2(-dx, -dz);
  toast(`🧭 ${d.name}`, d.dir + ' Follow the glowing path.', { button: dist(player, d.route) > 4 ? { label: 'Take me there', act: 'teleport' } : null, openAlerts: false, ms: 8000 });
  sfx.chime();
}
function teleport() {
  const d = currentDest(); if (!d || !canMoveIgnoringPhone()) return;
  const path = findPath(player.x, player.z, d.route.x, d.route.z);
  let tgt = d.route;
  if (path.length >= 2) { const a = path[path.length - 2], b = path[path.length - 1]; const L = Math.hypot(b.x - a.x, b.z - a.z) || 1; const k = Math.min(1.6, L) / L; tgt = { x: b.x - (b.x - a.x) * k, z: b.z - (b.z - a.z) * k }; }
  $('#fade').classList.add('on');
  setTimeout(() => {
    const p = nearestWalkable(tgt.x, tgt.z); player.place(p.x, p.z, 0); player.face(d.mark.x, d.mark.z); player.rot = player.targetRot;
    if (st.step === 'escort' && !ui.jessSeated) { jess.place(P.consultJessStand.x, P.consultJessStand.z, Math.PI / 2); jess.face(naledi.x, naledi.z); ui.jessSeated = true; }
    cam.snap = true; routeDirty = true;
    $('#fade').classList.remove('on');
  }, 380);
}
function unstick() {
  const p = nearestWalkable(player.x, player.z);
  if (blocked(player.x, player.z, 0.3) || Math.hypot(p.x - player.x, p.z - player.z) > 0.01) player.place(p.x, p.z, player.rot);
  else { const q = nearestWalkable(P.plaza.x, P.plaza.z); player.place(q.x, q.z, Math.PI); }
  cam.snap = true;
  toast('Moved you to a clear spot', 'Use 🧭 Guide me to find your next destination.', { openAlerts: false });
}

// ====================================================================
// Minimap
// ====================================================================
const mm = $('#minimap'), mg = mm.getContext('2d');
const MM = { minX: -26, maxX: 26, minZ: -18, maxZ: 36 };
const mmS = Math.min(mm.width / (MM.maxX - MM.minX), mm.height / (MM.maxZ - MM.minZ));
const mmOx = (mm.width - (MM.maxX - MM.minX) * mmS) / 2;
const mx = (x) => mmOx + (x - MM.minX) * mmS, mz = (z) => (z - MM.minZ) * mmS;
function drawMinimap() {
  mg.clearRect(0, 0, mm.width, mm.height);
  mg.fillStyle = '#9dd07f'; mg.fillRect(0, 0, mm.width, mm.height);
  mg.fillStyle = '#e6dac4'; mg.fillRect(mx(-10), mz(16), 20 * mmS, 22 * mmS); mg.fillRect(mx(-24), mz(16.1), 48 * mmS, 3 * mmS);
  mg.fillStyle = '#f7f0e2'; mg.fillRect(mx(BUILDING.minX), mz(BUILDING.minZ), 40 * mmS, 32 * mmS);
  mg.strokeStyle = '#0b2a4a'; mg.lineWidth = 2.5; mg.strokeRect(mx(BUILDING.minX), mz(BUILDING.minZ), 40 * mmS, 32 * mmS);
  mg.fillStyle = '#f7f0e2'; mg.fillRect(mx(-3), mz(15.5), 6 * mmS, 1.2 * mmS);
  mg.strokeStyle = '#0b2a4a'; mg.lineWidth = 1.5; mg.beginPath(); mg.moveTo(mx(11), mz(-16)); mg.lineTo(mx(11), mz(-9)); mg.moveTo(mx(11), mz(-7)); mg.lineTo(mx(11), mz(-4)); mg.lineTo(mx(20), mz(-4)); mg.stroke();
  mg.font = '700 9px Segoe UI, Arial'; mg.textAlign = 'center'; mg.textBaseline = 'middle';
  for (const zn of ZONES) {
    mg.fillStyle = zn.color + '88'; mg.fillRect(mx(zn.x - zn.w / 2), mz(zn.z - zn.d / 2), zn.w * mmS, zn.d * mmS);
    mg.fillStyle = '#0b2a4a'; mg.fillText(zn.name, mx(zn.x), mz(zn.z));
  }
  // route
  if (routePts.length > 1) {
    mg.strokeStyle = '#16c7e8'; mg.lineWidth = 3; mg.setLineDash([5, 4]); mg.lineDashOffset = -simTime * 20; mg.beginPath();
    routePts.forEach((p, i) => i ? mg.lineTo(mx(p.x), mz(p.z)) : mg.moveTo(mx(p.x), mz(p.z))); mg.stroke(); mg.setLineDash([]);
  }
  const d = currentDest();
  if (d && ui.started) { const r = 5 + Math.sin(simTime * 5) * 2; mg.strokeStyle = '#16c7e8'; mg.lineWidth = 3; mg.beginPath(); mg.arc(mx(d.mark.x), mz(d.mark.z), r + 3, 0, Math.PI * 2); mg.stroke(); mg.fillStyle = '#0b2a4a'; mg.beginPath(); mg.arc(mx(d.mark.x), mz(d.mark.z), 3.5, 0, Math.PI * 2); mg.fill(); }
  mg.fillStyle = 'rgba(40,50,70,.45)'; for (const a of npcs) { mg.beginPath(); mg.arc(mx(a.x), mz(a.z), 1.8, 0, Math.PI * 2); mg.fill(); }
  for (const a of students) { mg.fillStyle = a.student.color; mg.beginPath(); mg.arc(mx(a.x), mz(a.z), 2.6, 0, Math.PI * 2); mg.fill(); }
  mg.fillStyle = '#16a9c4'; mg.beginPath(); mg.arc(mx(jess.x), mz(jess.z), 3, 0, Math.PI * 2); mg.fill();
  // player arrow
  mg.save(); mg.translate(mx(player.x), mz(player.z)); mg.rotate(-player.rot + Math.PI);
  mg.fillStyle = '#f2a33a'; mg.strokeStyle = '#0b2a4a'; mg.lineWidth = 1.5;
  mg.beginPath(); mg.moveTo(0, -7); mg.lineTo(5, 5); mg.lineTo(0, 2.5); mg.lineTo(-5, 5); mg.closePath(); mg.fill(); mg.stroke(); mg.restore();
  // camera view direction hint
  mg.fillStyle = '#0b2a4a'; mg.font = '800 10px Segoe UI, Arial'; mg.fillText('N ▲', mm.width - 16, 10);
}

// ====================================================================
// Camera & input
// ====================================================================
const cam = { yaw: 0, yawTarget: 0, pitch: 0.62, dist: 14, tx: P.start.x, tz: P.start.z, snap: true };
function camReset() { cam.yawTarget = 0; cam.pitch = 0.62; cam.dist = 14; }
const keys = new Set();
const MOVE_KEYS = { KeyW: 'f', ArrowUp: 'f', KeyS: 'b', ArrowDown: 'b', KeyA: 'l', ArrowLeft: 'l', KeyD: 'r', ArrowRight: 'r' };
const typing = () => { const a = document.activeElement; return a && (a.tagName === 'INPUT' || a.tagName === 'SELECT' || a.tagName === 'TEXTAREA'); };

function canMoveIgnoringPhone() { return ui.started && !ui.paused && !ui.dialog && !ui.busy && !player.sitting && !['controls', 'controls-from-pause', 'pause', 'scenarios', 'idle', 'start', 'complete'].includes(ui.overlay); }
function canMove() { return canMoveIgnoringPhone() && !ui.phoneOpen; }

window.addEventListener('keydown', (e) => {
  ui.lastInput = performance.now();
  if (typing()) { if (e.key === 'Escape') document.activeElement.blur(); return; }
  if (MOVE_KEYS[e.code]) {
    e.preventDefault();
    keys.add(e.code);
    if (ui.dialog && ui.dialog.choices.length && !ui.busy) closeDialog();
    if (profileAgent) closeProfile();
    if (ui.phoneOpen && !ui.flow && canMoveIgnoringPhone()) closePhone();
    return;
  }
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') { keys.add('Shift'); return; }
  if (!ui.started) { if (e.code === 'Enter' && ui.overlay === 'start') act('start', 'new'); return; }
  if (ui.overlay === 'controls' && (e.code === 'Enter' || e.code === 'Space' || e.code === 'KeyE')) return act('closeControls');
  if (ui.dialog && /^Digit[1-9]$/.test(e.code)) { const i = +e.code.slice(5) - 1; if (ui.dialog.choices[i]) { e.preventDefault(); return act('choice', i); } }
  switch (e.code) {
    case 'KeyE': case 'Enter': case 'Space': if (currentInteract) { e.preventDefault(); interact(); } break;
    case 'KeyR': if (canMoveIgnoringPhone()) { ui.phoneOpen ? closePhone() : openPhone(); } break;
    case 'KeyG': act('guide'); break;
    case 'KeyC': camReset(); break;
    case 'KeyM': act('toggleSound'); break;
    case 'KeyF': act('fullscreen'); break;
    case 'KeyP': case 'Escape':
      if (ui.overlay === 'pause') act('resume');
      else if (ui.overlay === 'scenarios') act('closeScenarios');
      else if (ui.dialog && ui.dialog.choices.length && !ui.busy) closeDialog();
      else if (ui.runnerOpen) act('runnerClose');
      else if (profileAgent) closeProfile();
      else if (ui.phoneOpen) closePhone();
      else if (!ui.overlay || ui.overlay === 'complete') act('pause');
      break;
  }
});
window.addEventListener('keyup', (e) => { keys.delete(e.code); if (e.code.startsWith('Shift')) keys.delete('Shift'); });
window.addEventListener('blur', () => keys.clear());
document.addEventListener('focusin', () => { if (typing()) keys.clear(); });

let drag = null;
canvas.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, y: e.clientY }; clickStart = { x: e.clientX, y: e.clientY, t: performance.now() }; canvas.classList.add('dragging'); canvas.setPointerCapture(e.pointerId); ui.lastInput = performance.now(); });
canvas.addEventListener('pointermove', (e) => {
  if (!drag) return;
  const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag = { x: e.clientX, y: e.clientY };
  cam.yawTarget -= dx * 0.006; cam.pitch = Math.max(0.28, Math.min(1.25, cam.pitch + dy * 0.004));
  ui.lastInput = performance.now();
});
let clickStart = null;
canvas.addEventListener('pointerup', (e) => {
  drag = null; canvas.classList.remove('dragging');
  if (clickStart && Math.hypot(e.clientX - clickStart.x, e.clientY - clickStart.y) < 6 && performance.now() - clickStart.t < 500 && ui.started && !ui.overlay) {
    const a = pickAgentAt(e.clientX, e.clientY);
    if (a) showProfile(a); else if (profileAgent) closeProfile();
  }
  clickStart = null;
});
canvas.addEventListener('wheel', (e) => { cam.dist = Math.max(6, Math.min(20, cam.dist + e.deltaY * 0.01)); ui.lastInput = performance.now(); }, { passive: true });
canvas.addEventListener('contextmenu', (e) => e.preventDefault());
document.addEventListener('pointerdown', () => { ui.lastInput = performance.now(); }, true);

// ====================================================================
// Action dispatcher — every button routes through here
// ====================================================================
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (!b || b.disabled) return;
  initAudio();
  act(b.dataset.act, b.dataset.arg, b);
});

function act(name, arg) {
  ui.lastInput = performance.now();
  switch (name) {
    case 'start': startGame(arg || 'new'); break;
    case 'closeControls':
      $('#controls').classList.add('hidden');
      if (ui.overlay === 'controls-from-pause') { $('#pause').classList.remove('hidden'); ui.overlay = 'pause'; break; }
      ui.overlay = null;
      if (!ui.welcomed) { ui.welcomed = true; banner('Welcome to Emeris University.<small>Let REGGY guide your registration.</small>', 5000); sfx.chime(); }
      break;
    case 'showControls': $('#pause').classList.add('hidden'); $('#controls').classList.remove('hidden'); ui.overlay = 'controls-from-pause'; break;
    case 'pause': if (!ui.started) break; ui.paused = true; ui.overlay = 'pause'; $('#pause').classList.remove('hidden'); $('#complete').classList.add('hidden'); keys.clear(); break;
    case 'resume': ui.paused = false; ui.overlay = st.step === 'complete' && !ui.exploring ? 'complete' : null; $('#pause').classList.add('hidden'); if (ui.overlay === 'complete') $('#complete').classList.remove('hidden'); break;
    case 'newVisitor': resetToStart(); break;
    case 'playAgain': startGame(st.scenario, { skipControls: true }); break;
    case 'explore': $('#complete').classList.add('hidden'); ui.overlay = null; ui.exploring = true; break;
    case 'scenarioMenu': showScenarioMenu(); break;
    case 'closeScenarios': $('#scenarios').classList.add('hidden'); ui.overlay = ui.started ? (ui.paused ? 'pause' : null) : 'start'; if (ui.overlay === 'pause') $('#pause').classList.remove('hidden'); if (!ui.started) $('#start').classList.remove('hidden'); break;
    case 'pickScenario': $('#scenarios').classList.add('hidden'); startGame(arg); break;
    case 'unstick': act('resume'); unstick(); break;
    case 'fullscreen':
      if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => toast('Full screen unavailable', 'Press F11 in your browser instead.', { openAlerts: false }));
      else document.exitFullscreen?.();
      break;
    case 'toggleSound': initAudio(); setMuted(!isMuted()); $('#soundBtn').textContent = isMuted() ? '🔇' : '🔊'; break;
    case 'camReset': camReset(); break;
    case 'guide': guide(); break;
    case 'teleport': teleport(); break;
    case 'interact': interact(); break;
    case 'idleStay': ui.idleCountdown = 0; $('#idle').classList.add('hidden'); ui.overlay = ui.prevOverlay || null; break;
    case 'choice': { const c = ui.dialog?.choices[+arg]; if (c) { sfx.click(); c.fn(); } break; }

    // ---- phone ----
    case 'speak': {
      initAudio();
      const id = arg;
      if (id === 'siya') speakName(st.student?.speak || SIYA.speak);
      else if (id === 'naledi') speakName(NALEDI.speak);
      else { const a = students.find(x => x.name === id); if (a) speakName(a.student.speak); }
      if (isMuted()) toast('Sound is off', 'Turn sound on (🔊) to hear names spoken.', { openAlerts: false });
      break;
    }
    case 'chatProfile': if (profileAgent && canMoveIgnoringPhone()) { closePhone(); const a = profileAgent; if (a.ch.pose !== 'sit' && a !== player) player.face(a.x, a.z); chatWith(a); } break;
    case 'walkTo': if (profileAgent) { ui.follow = profileAgent; ui.followSince = simTime; ui.followName = profileAgent.student?.first || people[profileAgent.name]?.name || profileAgent.data.name || 'them'; closeProfile(); closePhone(); routeDirty = true; toast(`🧭 Walking to ${ui.followName}`, 'Follow the glowing path — you can chat when you get there.', { openAlerts: false }); } break;
    case 'profileClose': closeProfile(); break;
    case 'runnerPanel': openRunnerPanel(); break;
    case 'runnerClose': ui.runnerOpen = false; $('#runnerPanel').classList.add('hidden'); break;
    case 'nameListen': initAudio(); speakName(($('#nmSay')?.value || st.student?.say || '').replace(/-/g, ' ')); if (isMuted()) toast('Sound is off', 'Turn sound on (🔊) to hear your name.', { openAlerts: false }); break;
    case 'nameRecord': if (ui.nmRecording || ui.nmRecorded) break; ui.nmPref = $('#nmPref')?.value; ui.nmSay = $('#nmSay')?.value; ui.nmRecording = true; updateHUD(); after(1.6, () => { ui.nmRecording = false; ui.nmRecorded = true; sfx.success(); updateHUD(); }); break;
    case 'nameSave': {
      if (st.step !== 'book' || !st.student) break;
      const pref = ($('#nmPref')?.value || '').trim() || st.student.first, sayIt = ($('#nmSay')?.value || '').trim() || pref;
      st.student.preferred = pref; st.student.say = sayIt; st.student.speak = sayIt.replace(/-/g, ' ');
      ui.nmPref = ui.nmSay = undefined;
      toast('Name saved ✓', `Staff will greet you as “${esc(pref)}” · ${esc(sayIt)}`, { openAlerts: false });
      ui.flow = 'times'; updateHUD(); break;
    }
    case 'phoneToggle': if (!ui.started) break; ui.phoneOpen ? closePhone() : openPhone(); break;
    case 'phoneOpenDefault': openPhone(); break;
    case 'phoneClose': closePhone(); break;
    case 'tab': ui.flow = null; ui.tab = arg; ui.phoneOpen = true; if (arg === 'alerts') st.unread = 0; sfx.click(); updateHUD(); break;
    case 'flow':
      if ((arg === 'times' || arg === 'nameSay') && st.step !== 'book') break;
      if (arg === 'advisor' && st.step !== 'book') { ui.flow = null; ui.tab = 'appts'; updateHUD(); break; }
      if (arg === 'payUpload' && st.step !== 'feeUpload') break;
      if (arg === 'feeInfo' && st.step !== 'feeUpload') { ui.flow = null; ui.tab = 'next'; updateHUD(); break; }
      if (['identify', 'profile', 'noid'].includes(arg) && st.identified) break;
      ui.flow = arg; ui.file = null; ui.fileError = ''; ui.idError = ''; ui.pfError = ''; ui.phoneOpen = true; sfx.click(); updateHUD(); break;
    case 'useDemoId': {
      if (st.step !== 'identify') break;
      const sc = scenarioOf(st); ui.idValue = sc.demoId; ui.flow = 'identify'; updateHUD();
      after(0.45, () => { if (st.step === 'identify') identify(sc.student.name, sc.demoId); });
      break;
    }
    case 'submitId': {
      if (st.step !== 'identify') break;
      const v = (ui.idValue || '').trim().toUpperCase();
      const sc = scenarioOf(st);
      if (!v) ui.idError = 'Please type your ID number, or tap “Use demo ID”.';
      else if (v === sc.demoId) { identify(sc.student.name, sc.demoId); break; }
      else if (Object.values(SCENARIOS).some(s => s.demoId === v)) ui.idError = 'That demo ID belongs to another scenario. Use the demo ID shown below.';
      else ui.idError = 'We couldn’t find that ID. Check it and try again — or use the demo ID.';
      sfx.error(); updateHUD(); break;
    }
    case 'createProfile': {
      if (st.step !== 'identify') break;
      const name = ($('#pfName')?.value || '').trim(), prog = $('#pfProg')?.value, intake = $('#pfIntake')?.value;
      if (!/^[A-Za-zÀ-ÿ' -]{2,18}$/.test(name)) { ui.pf = { name, prog }; ui.pfError = 'Please enter a first name (letters only, 2–18 characters).'; sfx.error(); updateHUD(); break; }
      if (st.scenario !== 'new') { const keep = { notifications: st.notifications, unread: st.unread, flags: st.flags }; st = Object.assign(createState('new'), keep); st.step = 'identify'; }
      const id = 'EMR-2026-' + String(1000 + Math.floor(Math.random() * 8999));
      identify(name.charAt(0).toUpperCase() + name.slice(1), id, prog);
      st.student.intake = intake;
      break;
    }
    case 'routeReception': st.optionalDest = 'reception'; closePhone(); routeDirty = true; toast('🧭 Reception', DEST.reception.dir, { openAlerts: false }); updateHUD(); break;
    case 'pickTime': { const t = TIMES[+arg]; if (t && t.free) { ui.time = +arg; sfx.click(); updateHUD(); } break; }
    case 'confirmBooking': confirmBooking(); break;
    case 'showWay': closePhone(); guide(true); break;
    case 'startUpload': {
      if (st.step !== 'docs') break;
      const d = st.documents.find(x => x.id === arg && x.status === 'Missing');
      if (!d) break;
      if (d.how === 'desk') { act('goDocHelp'); break; }
      ui.uploadDoc = d.id; ui.file = null; ui.fileError = ''; ui.flow = 'upload'; ui.phoneOpen = true; updateHUD(); break;
    }
    case 'pickFile': ui.file = arg; ui.fileError = ''; sfx.click(); updateHUD(); break;
    case 'doUpload': {
      const kind = arg; const f = SAMPLE_FILES[kind].find(f => f.id === ui.file);
      if (!f) break;
      if (kind === 'qual' && st.step !== 'docs') break;
      if (kind === 'pay' && st.step !== 'feeUpload') break;
      if (!f.ok) { ui.fileError = kind === 'pay' ? 'Hmm, that doesn’t look like a proof of payment. Try the bank slip.' : 'Hmm, that doesn’t look like a qualification certificate. Try the certificate file.'; sfx.error(); updateHUD(); break; }
      ui.flow = 'uploading'; ui.fileName = f.name; ui.fileIcon = f.icon; ui.busy = true; updateHUD(); sfx.upload();
      for (let i = 1; i <= 10; i++) after(i * 0.15, () => { const b = $('#upbar'); if (b) b.style.width = i * 10 + '%'; const t = $('#uptext'); if (t && i === 10) t.textContent = 'Upload complete'; });
      after(1.75, () => { ui.busy = false; finishUpload(kind); });
      break;
    }
    case 'goDocHelp': if (st.step === 'docs') { st.optionalDest = 'docAssist'; routeDirty = true; } closePhone(); guide(true); break;
  }
}

// ====================================================================
// Scenario menu, start, reset
// ====================================================================
function showScenarioMenu() {
  const icons = { new: '🎒', missing: '📄', returning: '🔁' };
  $('#scenarioList').innerHTML = Object.values(SCENARIOS).map(s => `<button class="scen" data-act="pickScenario" data-arg="${s.id}"><div class="em">${icons[s.id]}</div><h4>${s.title}</h4><p>${s.blurb}</p></button>`).join('');
  ['#pause', '#complete', '#start'].forEach(s => $(s).classList.add('hidden'));
  $('#scenarios').classList.remove('hidden'); ui.overlay = 'scenarios';
}

function resetWorld(scenarioId) {
  gen++; timers = []; simTime = simTime; // keep clock, kill callbacks
  st = createState(scenarioId);
  Object.assign(ui, { paused: false, phoneOpen: false, flow: null, tab: 'next', dialog: null, busy: false, time: null, file: null, fileError: '', idValue: '', idError: '', pf: null, pfError: '', msg: null, jessSeated: false, exploring: false, guidePulse: 0, stepTime: simTime, visitStart: simTime, welcomed: false });
  closeDialog();
  ['#pause', '#complete', '#scenarios', '#idle', '#controls'].forEach(s => $(s).classList.add('hidden'));
  $('#toasts').innerHTML = ''; $('#banner').classList.add('hidden');
  for (const [, b] of bubbles) b.el.remove(); bubbles.clear();
  player.sitting = false; player.place(P.start.x, P.start.z, Math.PI); player.ch.lanyard.visible = false;
  jess.place(P.jessHome.x, P.jessHome.z, 0); naledi.sit(P.consultJessChair.x, P.consultJessChair.z, 0);
  resetStudents(); Object.assign(runner, { job: false, cooldown: 6, siyaCalled: false });
  closeProfile(); ui.camFocus = null; ui.runnerOpen = false; $('#runnerPanel').classList.add('hidden'); ui.follow = null; ui.nmRecorded = false; ui.nmRecording = false; ui.nmPref = ui.nmSay = undefined;
  try { window.speechSynthesis?.cancel(); } catch { /* ignore */ }
  riley.place(P.lostStudent.x, P.lostStudent.z, 0.6); riley.data = {}; riley.tag = 'Riley · looks lost';
  world.stand.ring.material.color.set('#16c7e8'); world.stand.beam.material.opacity = 0;
  world.highlights.financeLight.material.color.set('#ff9f80'); world.highlights.financeLight.material.emissive.set('#ff9f80');
  if (confettiMesh) { scene.remove(confettiMesh); confettiMesh = null; }
  floaters.splice(0).forEach(f => scene.remove(f.m));
  camReset(); cam.yaw = 0; cam.snap = true; keys.clear(); routeDirty = true; lastObj = '';
  updateHUD();
}
function startGame(scenarioId, opts = {}) {
  initAudio();
  resetWorld(scenarioId);
  ui.started = true;
  $('#start').classList.add('hidden'); $('#hud').classList.remove('hidden');
  if (opts.skipControls) { ui.overlay = null; ui.welcomed = true; banner('Welcome to Emeris University.<small>Let REGGY guide your registration.</small>', 4500); }
  else { ui.overlay = 'controls'; $('#controls').classList.remove('hidden'); }
  if (scenarioId !== 'new') toast(`Scenario: ${SCENARIOS[scenarioId].title}`, SCENARIOS[scenarioId].blurb, { openAlerts: false });
}
function resetToStart() {
  resetWorld('new');
  ui.started = false; ui.overlay = 'start';
  $('#hud').classList.add('hidden'); $('#start').classList.remove('hidden');
  $('#prompt').classList.add('hidden'); currentInteract = null;
}

// ====================================================================
// Main loop
// ====================================================================
const ray = new THREE.Raycaster();
let solidMeshes = null;
let footT = 0;
function updatePlayer(dt) {
  let fx = 0, fz = 0;
  if (canMove()) {
    const has = (k) => [...keys].some(c => MOVE_KEYS[c] === k);
    const f = (has('f') ? 1 : 0) - (has('b') ? 1 : 0), r = (has('r') ? 1 : 0) - (has('l') ? 1 : 0);
    if (f || r) {
      const sy = Math.sin(cam.yaw), cy = Math.cos(cam.yaw);
      fx = -sy * f + cy * r; fz = -cy * f - sy * r;
      const l = Math.hypot(fx, fz); fx /= l; fz /= l;
    }
  }
  const speed = keys.has('Shift') ? 6.2 : 4.2;
  let moving = 0;
  if (fx || fz) {
    let nx = player.x + fx * speed * dt, nz = player.z + fz * speed * dt;
    ({ x: nx, z: nz } = resolveCircle(nx, nz, 0.36));
    // soft collision with people
    for (const a of [...npcs, ...staffAgents, riley, ...students]) {
      const dx = nx - a.x, dz = nz - a.z, d = Math.hypot(dx, dz);
      if (d < 0.68 && d > 1e-4) { nx = a.x + (dx / d) * 0.68; nz = a.z + (dz / d) * 0.68; }
    }
    ({ x: nx, z: nz } = resolveCircle(nx, nz, 0.36));
    const moved = Math.hypot(nx - player.x, nz - player.z);
    player.x = nx; player.z = nz;
    player.targetRot = Math.atan2(fx, fz);
    moving = Math.min(1, (moved / dt) / 4.2);
    footT -= dt; if (footT <= 0 && moved > 0.001) { sfx.step(); footT = keys.has('Shift') ? 0.22 : 0.3; }
  }
  player.rot = angLerp(player.rot, player.targetRot, Math.min(1, dt * 12));
  animateCharacter(player.ch, dt, moving);
  player.sync();
}

function updateCamera(dt) {
  cam.yaw = angLerp(cam.yaw, cam.yawTarget, Math.min(1, dt * 6));
  const k = cam.snap ? 1 : Math.min(1, dt * 5);
  const intro = !ui.started;
  const foc = ui.camFocus; // close-up on someone you clicked or are chatting with, from the front
  const fx = intro ? 0 : foc ? foc.x : player.x, fz = intro ? 8 : foc ? foc.z : player.z;
  cam.tx += (fx - cam.tx) * k; cam.tz += (fz - cam.tz) * k; cam.snap = false;
  if (foc) cam.focusYaw = angLerp(cam.focusYaw ?? cam.yaw, foc.rot + 0.35, Math.min(1, dt * 3));
  const yaw = foc ? cam.focusYaw : cam.yaw;
  const inRoom = player.x > ROOM.minX && player.z < ROOM.maxZ && player.z > ROOM.minZ;
  const d = intro ? 44 : foc ? 4.6 : inRoom ? Math.min(cam.dist, 11) : cam.dist;
  const pitch = intro ? 0.72 : foc ? 0.32 : cam.pitch;
  cam.d = (cam.d ?? d) + (d - (cam.d ?? d)) * Math.min(1, dt * 4); cam.p = (cam.p ?? pitch) + (pitch - (cam.p ?? pitch)) * Math.min(1, dt * 4);
  const cx = cam.tx + Math.sin(yaw) * Math.cos(cam.p) * cam.d;
  const cz = cam.tz + Math.cos(yaw) * Math.cos(cam.p) * cam.d;
  const cy = 1 + Math.sin(cam.p) * cam.d;
  camera.position.set(cx, cy, cz);
  const lookY = foc ? (foc.ch.pose === 'sit' ? 1.0 : 1.35) : 1.1;
  if (foc) { // keep the close-up camera out of screens, counters and props
    if (!solidMeshes) { solidMeshes = []; scene.traverse(o => { if (o.isMesh && !o.isInstancedMesh && !o.userData.agent && !o.userData.fadeGroup && !(o.material && o.material.transparent)) solidMeshes.push(o); }); }
    const from = new THREE.Vector3(cam.tx, lookY, cam.tz), dir = camera.position.clone().sub(from), len = dir.length(); dir.normalize();
    ray.set(from, dir); ray.far = len;
    const hit = ray.intersectObjects(solidMeshes, false)[0];
    if (hit) camera.position.copy(from).addScaledVector(dir, Math.max(0.8, hit.distance - 0.25));
  }
  camera.lookAt(cam.tx, lookY, cam.tz);
  if (!foc) cam.focusYaw = null;
  // fade walls between camera and player so rooms stay readable
  const head = new THREE.Vector3(foc ? foc.x : player.x, 1.2, foc ? foc.z : player.z);
  const dir = head.clone().sub(camera.position); const len = dir.length(); dir.normalize();
  ray.set(camera.position, dir); ray.far = len;
  const hitGroups = new Set();
  for (const h of ray.intersectObjects(world.fadeMeshes, false)) hitGroups.add(h.object.userData.fadeGroup);
  const inside = player.z < 16.2 && player.z > -16 && player.x > -20 && player.x < 20;
  if (inside || !ui.started) hitGroups.add('front');
  if (inRoom) { hitGroups.add('roomS'); hitGroups.add('room'); }
  // also check the four corners around the player for wide occluders
  for (const m of world.fadeMeshes) {
    const target = hitGroups.has(m.userData.fadeGroup) ? (m.userData.fadeGroup === 'front' ? 0.04 : 0.14) : 1;
    const o = m.material.opacity + (target - m.material.opacity) * Math.min(1, dt * 8);
    m.material.opacity = o; m.material.depthWrite = o > 0.95;
  }
}

function updateDoors(dt) {
  const movers = [player, jess, riley, ...students, ...npcs];
  for (const d of world.doors) {
    let near = false;
    for (const a of movers) if (Math.hypot(a.x - d.cx, a.z - d.cz) < d.r) { near = true; break; }
    d.t += ((near ? 1 : 0) - d.t) * Math.min(1, dt * 5);
    d.mesh.position[d.axis] = d.closed + (d.open - d.closed) * d.t;
  }
}

function updateJourney(dt) {
  if (!ui.started) return;
  // escort: Jess waits for the player if they fall behind
  if (st.step === 'escort' && jess.path.length) {
    const far = dist(player, jess) > 6.5;
    jess.paused = far;
    if (far) { jess.face(player.x, player.z); if (!bubbles.has(jess)) say(jess, 'This way! 👋', 2.5, 'Jess'); }
  } else jess.paused = false;
  if (st.step === 'leaveRoom' && player.x < ROOM.minX - 0.6) onLeftRoom();
  // nudge the Guide button if someone seems stuck on a walking step
  if (currentDest() && simTime - ui.stepTime > 35) $('.tb.guide').classList.add('nudge');
  if (ui.guidePulse > 0) ui.guidePulse -= dt;
  // stuck inside geometry safety net
  if (!player.sitting && blocked(player.x, player.z, 0.05)) { const p = nearestWalkable(player.x, player.z); player.place(p.x, p.z, player.rot); }
}

let hudTimer = 0, slowTimer = 0;
function updateObjectiveDistance() {
  const d = currentDest();
  const el = $('#objDest');
  if (!d || !ui.started) { el.textContent = ''; return; }
  const m = Math.round(dist(player, d.route));
  el.textContent = m < 2 ? `📍 You’ve arrived at ${d.name}` : `📍 ${d.name} · ${m} m away — follow the glowing path`;
}

function updateIdle() {
  if (!ui.started) return;
  const idleFor = (performance.now() - ui.lastInput) / 1000;
  if (ui.overlay === 'idle') {
    const left = Math.max(0, Math.ceil(20 - (idleFor - 150)));
    $('#idleCount').textContent = left;
    if (left <= 0) resetToStart();
    return;
  }
  if (idleFor > 150) { ui.prevOverlay = ui.overlay; ui.overlay = 'idle'; $('#idle').classList.remove('hidden'); }
}

const clock = new THREE.Clock();
function frame() {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, clock.getDelta());
  if (window.__reggyManual) return; // automated tests drive the clock via __reggy.sim()
  tick(dt);
  renderer.render(scene, camera);
}
function tick(dt) {
  const running = !ui.paused && ui.overlay !== 'idle';
  if (running) {
    simTime += dt;
    for (let i = timers.length - 1; i >= 0; i--) if (simTime >= timers[i].t) { const t = timers.splice(i, 1)[0]; t.fn(); }
    updatePlayer(dt);
    for (const a of [...staffAgents, riley]) a.update(dt);
    updateNpcs(dt);
    updateStudents(dt);
    if (ui.started) runnerUpdate(dt);
    updateJourney(dt);
    updateDoors(dt);
    updateConfetti(dt); updateFloaters();
    world.animated.forEach(f => f(simTime));
    // fade floating signs that come too close to the camera so they never block the view
    for (const l of Object.values(world.labels)) { const d = camera.position.distanceTo(l.position); l.material.opacity = Math.max(0, Math.min(1, (d - 8) / 5)); l.visible = l.material.opacity > 0.02; }
    const sr = world.stand.ring; sr.scale.setScalar(1 + Math.sin(simTime * 3) * 0.05);
    if (world.highlights.seat.material.opacity > 0) world.highlights.seat.scale.setScalar(1 + Math.sin(simTime * 4) * 0.1);
  }
  if (!ui.started) { cam.yawTarget = Math.sin(performance.now() / 9000) * 0.6; } // gentle orbit behind the start screen
  updateCamera(dt);
  updateRoute(running ? dt : 0);
  updateInteract();
  updateWorldUI();
  hudTimer -= dt; if (hudTimer <= 0) { hudTimer = 0.25; updateObjectiveDistance(); drawMinimap(); updateIdle(); }
  slowTimer -= dt; if (slowTimer <= 0) { slowTimer = 1; updateScreens(); renderRunnerPanel(); if (profileAgent && profileAgent !== player) { const near = dist(profileAgent, player) < 3.6; if (near !== ui.profileNear) { ui.profileNear = near; showProfile(profileAgent); } } }
}
updateHUD();
frame();

// test/debug hook for automated walkthroughs (harmless in production)
window.__reggy = { get st() { return st; }, get ui() { return ui; }, player, jess, act, interact, teleport, P, get dest() { return currentDest(); }, get prompt() { return currentInteract?.id || null; }, get simTime() { return simTime; }, keys, students, naledi, runner, showProfile, pickAgentAt, chatWith, camera,
  // fast-forward the simulation (used by automated tests on slow software-rendered machines)
  sim(sec, dt = 1 / 30) { for (let t = 0; t < sec; t += dt) tick(dt); },
  render() { renderer.render(scene, camera); },
  get info() { return renderer.info.render; } };
