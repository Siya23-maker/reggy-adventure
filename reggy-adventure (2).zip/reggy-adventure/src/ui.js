// REGGY phone screens. Pure render functions: (state, ui) -> HTML string.
// Buttons carry data-act / data-arg and are handled by the central action dispatcher in main.js.
import { MILESTONES, milestoneStatus, scenarioOf, missingDocs, objective, STEP_INFO } from './state.js';

export const ADVISOR = { name: 'Naledi Mokoena', short: 'Naledi', role: 'Student Advisor', color: '#2f9e8f' };
export const TIMES = [
  { t: '09:30', free: false }, { t: 'Now · 10:15', free: true }, { t: '10:45', free: true }, { t: '11:30', free: true }, { t: '13:00', free: false }, { t: '14:15', free: true },
];
export const SAMPLE_FILES = {
  qual: [
    { id: 'cert_pdf', icon: '📄', name: 'Grade12_Certificate_DEMO.pdf', meta: 'PDF · 412 KB · fictional sample', ok: true },
    { id: 'cert_jpg', icon: '🖼️', name: 'Certificate_photo_DEMO.jpg', meta: 'Photo · 1.2 MB · fictional sample', ok: true },
    { id: 'selfie', icon: '🤳', name: 'Holiday_selfie_DEMO.jpg', meta: 'Photo · 2.0 MB · fictional sample', ok: false },
  ],
  pay: [
    { id: 'pop', icon: '🧾', name: 'Proof_of_payment_DEMO.pdf', meta: 'PDF · 88 KB · fictional bank slip', ok: true },
    { id: 'menu', icon: '🍕', name: 'Cafeteria_menu_DEMO.pdf', meta: 'PDF · 140 KB · fictional sample', ok: false },
  ],
};

export function jessSVG(size = 78) {
  return `<svg viewBox="0 0 80 80" width="${size}" height="${size}" aria-label="Portrait of Naledi, student advisor">
  <circle cx="40" cy="40" r="40" fill="#d8f5fb"/>
  <path d="M12 80 C14 60 26 54 40 54 C54 54 66 60 68 80Z" fill="#2f9e8f"/>
  <path d="M33 54 L40 64 L47 54Z" fill="#fff"/>
  <circle cx="40" cy="36" r="17" fill="#7a4a2e"/>
  <path d="M22 36 C21 18 33 14 40 14 C49 14 59 19 58 36 C55 26 48 22 40 22 C32 22 25 27 22 36Z" fill="#3a2418"/>
  <circle cx="40" cy="12" r="7" fill="#3a2418"/>
  <circle cx="33.5" cy="37" r="2.2" fill="#1b1b24"/><circle cx="46.5" cy="37" r="2.2" fill="#1b1b24"/>
  <path d="M34 44 Q40 49 46 44" stroke="#1b1b24" stroke-width="2" fill="none" stroke-linecap="round"/>
  <circle cx="29" cy="42" r="2.6" fill="#f19a8f" opacity=".6"/><circle cx="51" cy="42" r="2.6" fill="#f19a8f" opacity=".6"/>
  <rect x="45" y="62" width="9" height="11" rx="2" fill="#fff"/><rect x="45" y="62" width="9" height="3" fill="#0b2a4a"/>
</svg>`;
}

const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export function renderPhone(st, ui) {
  if (ui.flow) return renderFlow(st, ui);
  switch (ui.tab) {
    case 'progress': return tabProgress(st);
    case 'docs': return tabDocs(st);
    case 'appts': return tabAppts(st);
    case 'alerts': return tabAlerts(st);
    case 'help': return tabHelp(st);
    default: return tabNext(st);
  }
}

// ---------------- flows ----------------
function renderFlow(st, ui) {
  const sc = scenarioOf(st);
  switch (ui.flow) {
    case 'scanning': return `
      <div class="ph-h">Scanning…</div>
      <div class="scanview"><div class="qr"></div><div class="corners"></div><div class="laser"></div></div>
      <p class="ph-p" style="text-align:center">Hold steady — connecting to <b>REGGY</b> at Emeris University.</p>`;
    case 'identify': return `
      <div class="ph-h">Welcome! 👋</div>
      <p class="ph-p">Enter your ID number to find your registration progress.</p>
      <label class="ph-label" for="idInput">Student ID number</label>
      <input id="idInput" class="ph-input" placeholder="e.g. EMR-2026-0000" autocomplete="off" value="${esc(ui.idValue || '')}" />
      ${ui.idError ? `<div class="alert">${esc(ui.idError)}</div>` : ''}
      <div class="demo-id">🎟️ <b>Demo ID: ${sc.demoId}</b><br><span class="ph-small">Fictional ID for this expo demo.</span></div>
      <button class="ph-btn" data-act="useDemoId">Use demo ID</button>
      <button class="ph-btn navy" data-act="submitId">Find my progress</button>
      <button class="ph-btn sec" data-act="flow" data-arg="profile">I’m new — create a profile</button>
      <button class="ph-btn sec" data-act="flow" data-arg="noid">I don’t have my ID with me</button>`;
    case 'profile': return `
      <div class="ph-h">Create your profile</div>
      <p class="ph-p">Just a few details to get started. Use any made-up name — this is a demo.</p>
      <label class="ph-label" for="pfName">First name</label>
      <input id="pfName" class="ph-input" maxlength="18" placeholder="e.g. Alex" value="${esc(ui.pf?.name || '')}" autocomplete="off"/>
      <label class="ph-label" for="pfProg">Programme you applied for</label>
      <select id="pfProg" class="ph-input">
        ${['Bachelor of Business Administration', 'Diploma in Information Technology', 'Bachelor of Science in Engineering', 'Bachelor of Arts in Media'].map(p => `<option ${ui.pf?.prog === p ? 'selected' : ''}>${p}</option>`).join('')}
      </select>
      <label class="ph-label" for="pfIntake">Intake</label>
      <select id="pfIntake" class="ph-input"><option>January 2027</option><option>September 2026</option></select>
      ${ui.pfError ? `<div class="alert">${esc(ui.pfError)}</div>` : ''}
      <button class="ph-btn" data-act="createProfile">Create profile</button>
      <button class="ph-btn sec" data-act="flow" data-arg="identify">Back</button>
      <p class="ph-small">🔒 No real personal information is needed or stored.</p>`;
    case 'noid': return `
      <div class="ph-h">No ID with you? No problem.</div>
      <p class="ph-p">In real life, the friendly team at <b>Reception</b> can find your profile using your name and date of birth, then send you a REGGY link.</p>
      <div class="note"><b>Where is Reception?</b><div>Just inside the main entrance, on the left.</div></div>
      <button class="ph-btn" data-act="useDemoId">Continue with the demo ID</button>
      <button class="ph-btn sec" data-act="routeReception">Show me the way to Reception</button>
      <button class="ph-btn sec" data-act="flow" data-arg="identify">Back</button>`;
    case 'welcome': return renderWelcome(st);
    case 'advisor': return `
      <div class="ph-h">Hi ${esc(st.student.first)}! Your first step is to meet a student advisor.</div>
      <div class="ph-card">
        <div class="advisor">${jessSVG()}<div><div class="nm">${ADVISOR.name}</div><div class="rl">Student Advisor</div><div class="ph-small">Available today · Consultation room</div></div></div>
        <p class="ph-p">Naledi will check your course choice, explain what you need for registration, and answer any questions. It takes about 10 minutes.</p>
        <div class="note"><b>🏃 Jess, our runner, will collect you</b><div>Wait in the waiting area — Jess walks you to Naledi’s room, so you never have to listen for your name being shouted.</div></div>
        <button class="ph-btn" data-act="flow" data-arg="nameSay">📅 Book appointment</button>
      </div>`;
    case 'nameSay': return `
      <div class="ph-h">How do we say your name? 🔊</div>
      <p class="ph-p">So staff greet you correctly. Jess, the runner, sees this on her tablet before she calls you.</p>
      <div class="ph-card"><div class="ph-small">Full name on record</div><div style="font-size:18px;font-weight:800;color:#0b2a4a">${esc(st.student.name)}</div>
        ${st.student.surnameSay ? `<div class="ph-small" style="margin-top:6px">Surname: <b>${esc(st.student.surnameSay)}</b> — ${esc(st.student.surnameTip)}</div>` : ''}</div>
      <label class="ph-label" for="nmPref">What should we call you?</label>
      <input id="nmPref" class="ph-input" maxlength="20" value="${esc(ui.nmPref ?? st.student.preferred ?? st.student.first)}" autocomplete="off"/>
      <label class="ph-label" for="nmSay">Say it like… (sounds-like spelling)</label>
      <input id="nmSay" class="ph-input" maxlength="30" value="${esc(ui.nmSay ?? st.student.say ?? st.student.first)}" autocomplete="off"/>
      <div style="display:flex;gap:8px;margin:8px 0">
        <button class="ph-btn sec" style="margin:0" data-act="nameListen">🔊 Listen</button>
        <button class="ph-btn sec" style="margin:0" data-act="nameRecord">${ui.nmRecorded ? '✅ Voice saved' : ui.nmRecording ? '🎙️ Recording…' : '🎙️ Record my voice'}</button>
      </div>
      <p class="ph-small">Demo: “Record” is simulated — nothing is captured.</p>
      <button class="ph-btn" data-act="nameSave">Save & choose a time</button>
      <button class="ph-btn sec" data-act="flow" data-arg="advisor">Back</button>`;
    case 'times': return `
      <div class="ph-h">Choose a time with Naledi</div>
      <p class="ph-small">Today · Advisor desk · Emeris University</p>
      <div class="slots">${TIMES.map((t, i) => `<button class="slot ${ui.time === i ? 'on' : ''}" ${t.free ? '' : 'disabled'} data-act="pickTime" data-arg="${i}">${t.t}${t.free ? '' : '<br><small>Full</small>'}</button>`).join('')}</div>
      <button class="ph-btn" data-act="confirmBooking" ${ui.time == null ? 'disabled' : ''}>Confirm appointment</button>
      <button class="ph-btn sec" data-act="flow" data-arg="advisor">Back</button>`;
    case 'confirmed': return `
      <div class="big-check">✓</div>
      <div class="ph-h" style="text-align:center">Appointment confirmed.<br>Go to the waiting area.</div>
      <div class="ph-card">${apptCard(st)}</div>
      <p class="ph-p">Your seat is <b>glowing blue</b> in the waiting area. Check in there and <b>Jess, the runner,</b> will greet you as <b>“${esc(st.student.preferred || st.student.first)}”</b> and walk you to Naledi.</p>
      <button class="ph-btn" data-act="showWay">Show me the way →</button>`;
    case 'upload': return renderUpload(st, ui, 'qual');
    case 'payUpload': return renderUpload(st, ui, 'pay');
    case 'uploading': return `
      <div class="ph-h">Uploading…</div>
      <div class="ph-card"><div class="ph-row"><span style="font-size:28px">${ui.fileIcon || '📄'}</span><div class="grow"><b>${esc(ui.fileName || '')}</b><div class="progressbar"><div id="upbar"></div></div><span class="ph-small" id="uptext">Encrypting & sending…</span></div></div></div>`;
    case 'message': return renderMessage(ui.msg);
    case 'feeInfo': return `
      <div class="ph-h">Next: fee verification 💳</div>
      <div class="good">✓ Registration verified your documents.</div>
      <p class="ph-p"><b>Why this step?</b> New students confirm their first registration payment so Emeris can secure your place in your programme.</p>
      <div class="note"><b>How it works</b><div>1. Add your proof of payment here.<br>2. Visit Finance Assistance — a staff member reviews it.<br>3. REGGY marks it Verified.</div></div>
      <p class="ph-small">Demo only — no real payment is made or processed.</p>
      <button class="ph-btn" data-act="flow" data-arg="payUpload">Add proof of payment</button>`;
    default: return `<p class="ph-p">…</p>`;
  }
}

function renderWelcome(st) {
  const sc = scenarioOf(st);
  if (st.scenario === 'missing') return `
    <div class="ph-h">Welcome back, ${esc(st.student.first)}!</div>
    <div class="good">✓ Advisor meeting — completed yesterday with Naledi.</div>
    <div class="alert">⚠️ Two documents are still missing before Registration can verify you.</div>
    <div class="ph-card">${docRows(st, false)}</div>
    <button class="ph-btn" data-act="tab" data-arg="docs">Open My documents</button>`;
  if (st.scenario === 'returning') return `
    <div class="ph-h">Welcome back, ${esc(st.student.first)}! 🎉</div>
    <p class="ph-p">You're a <b>${esc(sc.student.type)}</b>. Your documents are already on file and verified.</p>
    <div class="good">✓ No advisor meeting needed<br>✓ Documents verified last year<br>✓ No fee verification needed this year</div>
    <p class="ph-p"><b>Your next step:</b> confirm your Year 2 modules at <b>Registration</b>, at the back of the main hall.</p>
    <button class="ph-btn" data-act="showWay">Show me the way →</button>`;
  return '';
}

function renderUpload(st, ui, kind) {
  const files = SAMPLE_FILES[kind];
  const title = kind === 'pay' ? 'Add proof of payment' : 'Upload your qualification certificate';
  return `
    <div class="ph-h">${title}</div>
    <p class="ph-small">Choose a file from your phone (fictional samples).</p>
    <div class="files">${files.map(f => `<button class="file ${ui.file === f.id ? 'on' : ''}" data-act="pickFile" data-arg="${f.id}"><span class="fi">${f.icon}</span><span><b>${f.name}</b><small>${f.meta}</small></span></button>`).join('')}</div>
    ${ui.fileError ? `<div class="alert">${esc(ui.fileError)}</div>` : ''}
    <button class="ph-btn" data-act="doUpload" data-arg="${kind}" ${ui.file ? '' : 'disabled'}>Upload</button>
    ${kind === 'qual' ? `<button class="ph-btn sec" data-act="goDocHelp">I need help — Document Assistance</button>` : ''}
    <button class="ph-btn sec" data-act="tab" data-arg="${kind === 'pay' ? 'next' : 'docs'}">Cancel</button>`;
}

function renderMessage(m) {
  if (!m) return '';
  return `
    ${m.check ? '<div class="big-check">✓</div>' : ''}
    <div class="ph-h" ${m.check ? 'style="text-align:center"' : ''}>${m.title}</div>
    ${m.changed ? `<div class="note"><b>What changed</b><div>${m.changed}</div></div>` : ''}
    ${m.next ? `<div class="note"><b>What to do next</b><div>${m.next}</div></div>` : ''}
    ${m.html || ''}
    ${(m.buttons || []).map((b, i) => `<button class="ph-btn ${i ? 'sec' : ''}" data-act="${b.act}" ${b.arg != null ? `data-arg="${b.arg}"` : ''}>${b.label}</button>`).join('')}`;
}

// ---------------- tabs ----------------
function tabNext(st) {
  if (!st.identified) return `
    <div class="ph-h">Next step</div>
    <p class="ph-p">Scan the REGGY code at the check-in stand outside the main entrance to start.</p>
    <button class="ph-btn" data-act="showWay">Show me the way →</button>`;
  const { obj, dest } = objective(st);
  const extra = {
    goWaiting: 'Your seat in the waiting area is glowing blue.',
    waiting: 'Sit back — Jess, the runner, will walk over and greet you by name.',
    escort: 'Jess is walking you to Naledi’s consultation room on the right of the hall. Follow her!',
    leaveRoom: 'Walk out through the door to continue.',
    registration: 'Registration will check your documents and change them from Uploaded to Verified.',
    finance: 'Finance Assistance will review your proof of payment.',
    complete: 'You did it! Feel free to explore the campus and meet people.',
    docs: 'Uploaded documents still need staff verification at Registration.',
    feeUpload: 'Add a proof-of-payment document so Finance can review it.',
  }[st.step] || '';
  const actions = {
    docs: `<button class="ph-btn" data-act="tab" data-arg="docs">Open My documents</button>`,
    feeUpload: `<button class="ph-btn" data-act="flow" data-arg="feeInfo">Add proof of payment</button>`,
    book: `<button class="ph-btn" data-act="flow" data-arg="advisor">Book advisor appointment</button>`,
  }[st.step] || (dest ? `<button class="ph-btn" data-act="showWay">Show me the way →</button>` : '');
  return `
    <div class="ph-h">Next step</div>
    <div class="ph-card"><div style="font-size:18px;font-weight:800;color:#0b2a4a">${obj}</div><p class="ph-small" style="margin:6px 0 0">${extra}</p></div>
    ${actions}
    <button class="ph-btn sec" data-act="tab" data-arg="progress">See my full progress</button>`;
}

function tabProgress(st) {
  const lbl = { done: 'Done', current: 'In progress — you are here', todo: 'Coming up', skipped: 'Not needed for you', 'done-earlier': 'Already done' };
  return `
    <div class="ph-h">My progress</div>
    ${st.student ? `<p class="ph-small">${esc(st.student.name)} · ${esc(st.student.id)}<br>${esc(st.student.programme)}</p>` : ''}
    <div class="ph-card">${MILESTONES.map((m, i) => {
      const s = st.identified || i === 0 ? milestoneStatus(st, m.id) : (i === 0 ? 'current' : 'todo');
      return `<div class="mstone ${s}"><div class="dot">${s === 'done' || s === 'done-earlier' ? '✓' : s === 'skipped' ? '–' : i + 1}</div><div><div class="lbl">${m.label}</div><div class="st">${lbl[s]}</div></div></div>`;
    }).join('')}</div>`;
}

function docRows(st, actions = true) {
  return st.documents.map(d => {
    let act = '';
    if (actions && d.status === 'Missing' && st.step === 'docs') {
      act = d.how === 'phone' ? `<button class="mini-btn" data-act="startUpload" data-arg="${d.id}">Upload</button>` : `<button class="mini-btn sec" data-act="goDocHelp">Get help</button>`;
    }
    return `<div class="ph-row"><span>${d.status === 'Verified' ? '✅' : d.status === 'Uploaded' ? '📤' : '❗'}</span><div class="grow"><b>${d.name}</b>${d.how === 'desk' && d.status === 'Missing' ? '<div class="ph-small">Needs certifying at Document Assistance</div>' : ''}</div><span class="chip ${d.status}">${d.status}</span>${act}</div>`;
  }).join('') + (st.payment ? `<div class="ph-row"><span>${st.payment.status === 'Verified' ? '✅' : st.payment.status === 'Uploaded' ? '📤' : '⏳'}</span><div class="grow"><b>Proof of payment</b><div class="ph-small">Needed for fee verification</div></div><span class="chip ${st.payment.status === 'Not uploaded' ? 'info' : st.payment.status}">${st.payment.status === 'Not uploaded' ? 'Later' : st.payment.status}</span></div>` : '');
}

function tabDocs(st) {
  const miss = missingDocs(st);
  const phoneMiss = miss.find(d => d.how === 'phone');
  return `
    <div class="ph-h">My documents</div>
    ${miss.length && st.identified ? `<div class="alert">⚠️ ${miss.map(d => `Your <b>${d.name.toLowerCase()}</b> is missing.`).join(' ')} ${st.step === 'docs' ? 'Upload it before registration verification.' : ''}</div>` : ''}
    <div class="ph-card">${st.identified ? docRows(st) : '<p class="ph-small">Scan the REGGY code to see your documents.</p>'}</div>
    ${phoneMiss && st.step === 'docs' ? `<button class="ph-btn" data-act="startUpload" data-arg="${phoneMiss.id}">Upload ${phoneMiss.name.toLowerCase()}</button>` : ''}
    <div class="note"><b>📤 Uploaded</b><div>REGGY has received your file, but nobody has checked it yet.</div></div>
    <div class="note"><b>✅ Verified</b><div>A staff member has checked the original and confirmed it. Registration does this for you.</div></div>
    ${st.step === 'docs' ? `<button class="ph-btn sec" data-act="goDocHelp">Need help? Go to Document Assistance</button>` : ''}`;
}

export const APPT_STEPS = ['Confirmed', 'In Waiting Room', 'In Progress', 'Completed'];
function apptCard(st) {
  const a = st.appointment; if (!a) return '';
  const ci = APPT_STEPS.indexOf(a.status);
  return `<div class="advisor">${jessSVG(56)}<div><div class="nm" style="font-size:17px">${a.advisor} · Student Advisor</div><div class="ph-small">Today ${a.time} · Ref ${a.ref}</div></div></div>
    <div class="appt-steps">${APPT_STEPS.map((s, i) => `<div class="${i < ci || a.status === 'Completed' ? 'done' : i === ci ? 'cur' : ''}">${s}</div>`).join('')}</div>`;
}
function tabAppts(st) {
  const sc = scenarioOf(st);
  return `
    <div class="ph-h">My appointments</div>
    ${st.appointment ? `<div class="ph-card">${apptCard(st)}</div>` :
      sc.advisorDoneEarlier ? `<div class="ph-card"><b>Naledi · Student Advisor</b><div class="ph-small">Yesterday · Completed</div></div>` :
      st.step === 'book' ? `<p class="ph-p">No appointments yet.</p><button class="ph-btn" data-act="flow" data-arg="advisor">Book with a student advisor</button>` :
      `<p class="ph-p">No appointments ${sc.advisor ? 'yet' : 'needed for your registration'}.</p>`}`;
}
function tabAlerts(st) {
  if (!st.notifications.length) return `<div class="ph-h">Notifications</div><p class="ph-p">Nothing yet. REGGY will let you know when something changes.</p>`;
  return `<div class="ph-h">Notifications</div><div class="ph-card">${st.notifications.slice().reverse().map(n => `<div class="notif"><b>${n.title}</b><div>${n.body}</div><time>${n.time}</time></div>`).join('')}</div>`;
}
function tabHelp() {
  const qa = [
    ['What is REGGY?', 'REGGY is Emeris University’s registration guide. It shows you one step at a time, books appointments, tracks your documents and tells you where to go next.'],
    ['I’m lost on campus', 'Press <b>🧭 Guide me</b> at the top of the screen. Follow the glowing cyan path on the floor to your next destination.'],
    ['What’s the difference between Uploaded and Verified?', 'Uploaded means REGGY has your file. Verified means a staff member has checked it. Registration verifies your documents.'],
    ['Can I talk to a person?', 'Yes! Reception (left of the entrance), Document Assistance (left side of the hall) and the advisors are always happy to help.'],
    ['Is this real?', 'This is an expo demo. All names, IDs, documents and payments are fictional.'],
  ];
  return `<div class="ph-h">Help</div>${qa.map(([q, a]) => `<details class="help"><summary>${q}</summary><p>${a}</p></details>`).join('')}
    <button class="ph-btn sec" data-act="guide">🧭 Guide me to my next step</button>`;
}

export function phoneTabLabel(st) {
  if (!st.identified && st.step === 'arrive') return 'Scan the code at the stand';
  return objective(st).obj.replace(/\.$/, '');
}
export { STEP_INFO };
