#!/bin/bash
# macOS: double-click to open the REGGY Registration Adventure full-screen in Chrome (Alt+F4 / Cmd+Q to exit).
DIR="$(cd "$(dirname "$0")" && pwd)"
open -na "Google Chrome" --args --kiosk "file://$DIR/dist/index.html" || open "$DIR/dist/index.html"
